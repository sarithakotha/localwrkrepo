﻿using PurchaseRequisition.Interface;
using PurchaseRequisition.Models;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Text.Json;

namespace PurchaseRequisition.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IHttpContextAccessor _iHttpContextAccessor { get; set; }
        private IServices _iServices { get; set; }
        private string _releaseStage { get; set; }
        private string _releaseName { get; set; }
        private string _releaseVersion { get; set; }
        private string _releaseDate { get; set; }

        public HomeController(ILogger<HomeController> logger, IServices iServices, IHttpContextAccessor iHttpContextAccessor)
        {
            _logger = logger;
            _iHttpContextAccessor = iHttpContextAccessor;
            _iServices = iServices;

        }

        public IActionResult Index()
        {
            return View();
        }
        
        public IActionResult MainPage()
        {
            var EmployeeNumber = _iHttpContextAccessor.HttpContext.Session.GetString("EmployeeNumber");
            string homepage = Url.Action("Index", "Home");
            if (string.IsNullOrEmpty(EmployeeNumber))
                return Redirect(homepage);

            ViewBag.EmpId = EmployeeNumber;





            return View();
        }

    }
}