﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PurchaseRequisition.Interface;
using PurchaseRequisition.ViewModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseRequisition.Controllers
{
    public class RequisitionController : Controller
    {
        private IHttpContextAccessor _iHttpContextAccessor { get; set; }
        private IServices _iServices { get; set; }

        public RequisitionController(IServices iServices, IHttpContextAccessor iHttpContextAccessor)
        {
            _iHttpContextAccessor = iHttpContextAccessor;
            _iServices = iServices;
        }

        public IActionResult Index()
        {
            
            ViewBag.PurchGRPMRO = _iServices.GetPurchGRPMRO();
            ViewBag.CostCenter = _iServices.GetCostCenter();
            ViewBag.Vendor = _iServices.GetVendor();
            ViewBag.GLAccount = _iServices.GetGLAccount();
            ViewBag.CPFRNO = _iServices.GetCPFRNO();
            ViewBag.CPFRNOJSON = JsonConvert.SerializeObject(ViewBag.CPFRNO);
            ViewBag.GLAccountJSON = JsonConvert.SerializeObject(ViewBag.GLAccount);
         //   ViewBag.CostCenterJSON = JsonConvert.SerializeObject(ViewBag.CostCenter);

            return View();
        }

        public IActionResult CreatePurchaseRequisition()
        {

            return View();
        }

        [HttpPost]
        public AjaxResponse SubmitPurchaseRequisition([FromBody]PurchaseRequistionViewModel purchaseRequistionViewModel)
        {
            return _iServices.AddPurchaseRequisition(purchaseRequistionViewModel);

        }

        public IActionResult History()
        {
            return View();
        }

        [HttpPost]
        public AjaxResponse PurchaseRequisitionHistory(HistoryViewModel historyViewModel)
        {
            return _iServices.PurchaseRequisitionHistory(historyViewModel);

        }

    }
}
