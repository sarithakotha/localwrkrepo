﻿using PurchaseRequisition.Interface;
using PurchaseRequisition.Models;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using PurchaseRequisition.ViewModel;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace PurchaseRequisition.BusinessLogic
{
    public class Services : IServices
    {
        private IConfiguration _configuration { get; set; }
        private string _connectionString { get; set; }
        private IHttpContextAccessor _httpContextAccessor { get; set; }
        private AjaxResponse _ajaxResponse { get; set; }

        public Services(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, AjaxResponse ajaxResponse)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetValue<string>("ConnectionStrings:DefaultConnection");
            _httpContextAccessor = httpContextAccessor;
            _ajaxResponse = ajaxResponse;
        }

        public AjaxResponse AddPurchaseRequisition(PurchaseRequistionViewModel purchaseRequistionViewModel)
        {
            int retStatus = 0;
            string FQDN = _httpContextAccessor.HttpContext?.User.Identity?.Name;
            //System.Web.HttpContext.Current.Request.LogonUserIdentity.Name;
            // FQDN = "YMMCDOM\TESTNAME12345"
            // https://stackoverflow.com/questions/1056487/httpcontext-current-user-identity-name-is-always-string-empty
            string usrnm = string.Empty;
            string email = string.Empty;
            if(!string.IsNullOrEmpty(FQDN))
            {
                usrnm = FQDN.Remove(0, 8);
                if (!string.IsNullOrEmpty(usrnm))
                    email = usrnm + "@ymmc.yamaha-motor.com";
            }

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = conn;
                    int seqkey = 0, seqkeyIndex = 1, seqline;
                    try
                    {
                        conn.Open();
                        cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc";
                        seqkey = Convert.ToInt32(cmd.ExecuteScalar());
                        decimal UnitPrice = 0;
                        string UnitPriceStr = string.Empty;
                        seqline = 10 * seqkeyIndex;
                        DateTime dlvdate;
                        string dlvdateStr = string.Empty;
                        string Status = "1";

                        foreach (var item in purchaseRequistionViewModel.purchaseRequistionLineItems)
                        {
                            UnitPriceStr = string.Empty;
                            PurchaseRequistionLineItem purchaseRequistion = (PurchaseRequistionLineItem)JsonConvert.DeserializeObject(item);
                            UnitPrice = Convert.ToDecimal(purchaseRequistion.UnitPrice);
                            UnitPriceStr = UnitPrice.ToString("0.00");
                            if (!string.IsNullOrEmpty(purchaseRequistion.DeliveryDate))
                            {
                                dlvdate = Convert.ToDateTime(purchaseRequistion.DeliveryDate);
                                dlvdateStr = dlvdate.ToString("yyyyMMdd");
                            }

                            string query = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) " +
                               "VALUES ('" + Convert.ToString(seqkey + seqkeyIndex) + "', '" + purchaseRequistionViewModel.Vendor + "', " +
                               "'" + purchaseRequistionViewModel.CostCenter + "', '" + purchaseRequistionViewModel.CPFRNO + "', " +
                               "'" + purchaseRequistionViewModel.PurchaseGroup + "', '" + Convert.ToString(seqline) + "', " +
                               "'" + purchaseRequistion.LineItem + "', '" + purchaseRequistion.Description + "', '" + purchaseRequistion.Quantity + "', " +
                               "'" + UnitPriceStr + "', '" + purchaseRequistion.UOM + "', '" + purchaseRequistion.Taxable + "', '" + dlvdateStr + "', " +
                               "'" + DateTime.Now.ToString("yyyyMMdd") + "', '" + Status + "', '" + purchaseRequistionViewModel.AcctCat +"', " +
                               "'" + purchaseRequistionViewModel.HeaderText + "', '" + usrnm + "', '" + email + "', '" + purchaseRequistion.GLAccount + "', " +
                               "'" + purchaseRequistion.VendorMaterial + "', '" + purchaseRequistion.TrackingNumber + "')";
                            cmd.CommandText = query;
                            cmd.ExecuteNonQuery();
                        }

                        conn.Close();
                    }
                    catch (Exception Ex)
                    { 
                        if(conn != null && conn.State == ConnectionState.Open)
                            conn.Close();
                    }
                }
            }

            return _ajaxResponse;
        }

        public AjaxResponse PurchaseRequisitionHistory(HistoryViewModel historyViewModel)
        {
            string HTMLStr = string.Empty;
            DataTable dataTable = new DataTable();
            string sCriteria = string.Empty;
            string FQDN = _httpContextAccessor.HttpContext?.User.Identity?.Name;
            string usrnm = string.Empty;
            if (!string.IsNullOrEmpty(FQDN))
            {
                usrnm = FQDN.Remove(0, 8);
            }

            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.PurchaseRequistion))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " purgroup ='"+ historyViewModel.PurchaseRequistion + "' ";
            }
            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.RequistionFromDate))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " dlvdate >='" + historyViewModel.RequistionFromDate + "' ";
            }
            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.RequistionToDate))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " dlvdate <='" + historyViewModel.RequistionToDate + "' ";
            }
            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.VendorNumber))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " VENITEM ='" + historyViewModel.VendorNumber + "' ";
            }
            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.Requistioner))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " REQUSER ='" + historyViewModel.Requistioner + "' ";
            }
            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.CostCenter))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " ccenter ='" + historyViewModel.CostCenter + "' ";
            }
            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.CPFR))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " cpfr ='" + historyViewModel.CPFR + "' ";
            }
            if (historyViewModel != null && !string.IsNullOrEmpty(historyViewModel.TrackingNumber))
            {
                if (!string.IsNullOrEmpty(sCriteria))
                    sCriteria += " AND ";
                sCriteria += " REFPART ='" + historyViewModel.TrackingNumber + "' ";
            }


            if (!string.IsNullOrEmpty(sCriteria))
            {
                string query = "select * from SAPPRGROUP WHERE " + sCriteria;

                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        try
                        {
                            conn.Open();
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            da.Fill(dataTable);
                            if(dataTable != null && dataTable.Rows != null && dataTable.Rows.Count > 0)
                            {
                                _ajaxResponse.status = "1";
                                foreach(DataRow item in dataTable.Rows)
                                {
                                    HTMLStr += @"<tr>
                                                    <td><label name='LineItemText'/>"+item["shorttext"] + @"</td>
                                                    <td><label name='Description' value=''/>" + item["longtext"] + @"</td>
                                                    <td><label name='GLAccount' value=''/>" + item["GLACCT"] + @"</td>
                                                    <td><label name='Status' value=''/>" + item["STATUS"] + @"</td>
                                                    <td><label name='QTY' value=''/>" + item["unitqty"] + @"</td>
                                                    <td><label name='UnitPrice' value=''/>" + item["unitprc"] + @"</td>
                                                    <td><label name='UOM' value=''/>" + item["uom"] + @"</td>
                                                    <td><label name='Total' value=''/></td>
                                                    <td><label name='Taxable' value=''/>" + item["taxflag"] + @"</td>
                                                    <td><label name='DeliveryDate' value=''/>" + item["dlvdate"] + @"</td>
                                                    <td><label name='VendorMaterial' value='' />" + item["VENITEM"] + @"</td>
                                                    <td><label name='TrackingNumber' value=''/>" + item["REFPART"] + @"</td>
                                                </tr>";
                                }
                            }
                            else
                            {
                                _ajaxResponse.status = "-1";
                                HTMLStr += @"<tr>
                                    <td colspan='12'>No Requisitions found</td>
                                </tr>";
                            }
                            conn.Close();
                            da.Dispose();
                        }
                        catch (Exception Ex)
                        { }
                    }
                }

            }
            else
            {
                _ajaxResponse.status = "-2";
                HTMLStr = "Please enter criteria";
            }
            _ajaxResponse.message = HTMLStr;
            return _ajaxResponse;
        }

        public DataTable GetPurchGRPMRO()
        {
            DataTable dataTable = new DataTable();
            string query = "select PURGROUP, PURGROUP + ' - ' + PURGROUPDS as 'purgrful' from SAPPRGROUP where PURGROUP='io1' or PURGROUP='io2' or PURGROUP='io3' or PURGROUP='io4'";

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dataTable);
                        conn.Close();
                        da.Dispose();
                    }
                    catch(Exception Ex)
                    { }
                }
            }
            return dataTable;
        //    return defaultData_GetPurchGRPMRO();
        }

        public DataTable GetCPFRNO(string PurchGRPMRO = "")
        {
            DataTable dataTable = new DataTable();
            string query = "SELECT CPFRNO, PURGROUP FROM [SAPCPFR]";
            if (!string.IsNullOrEmpty(PurchGRPMRO))
                query += " WHERE [PURGROUP] = " + PurchGRPMRO;
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dataTable);
                        conn.Close();
                        da.Dispose();
                    }
                    catch(Exception Ex)
                    { }
                }
            }
             return dataTable;
         //   return defaultData();

        }

        public DataTable GetCostCenter()
        {
            DataTable dataTable = new DataTable();
            string query = "SELECT CCNUMBER, CCNUMBER + ' : ' + CCNAME as 'ccfull' FROM SAPCOSTCTR";
            //if (!string.IsNullOrEmpty(PurchGRPMRO))
            //    query += " WHERE [PURGROUP] = " + PurchGRPMRO;
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dataTable);
                        conn.Close();
                        da.Dispose();
                    }
                    catch(Exception Ex)
                    { }
                }
            }
            return dataTable;
        }

        public DataTable GetVendor(string SUPPSTS = "A")
        {
            DataTable dataTable = new DataTable();
            string query = "SELECT SUPPCD, SUPPNAME + ' : ' +SUPPCD  AS NAMENUMBER FROM [SAPVENDORS]";
            if (!string.IsNullOrEmpty(SUPPSTS))
                query += " WHERE [SUPPSTS] = " + SUPPSTS;
            query += " ORDER BY [SUPPNAME]";
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dataTable);
                        conn.Close();
                        da.Dispose();
                    }
                    catch(Exception Ex)
                    { }
                }
            }
            return dataTable;
        }

        public DataTable GetGLAccount()
        {
            DataTable dataTable = new DataTable();
            string query = "SELECT GLACCT, GLACCT + GLDESC AS 'Concat', GLACCTCAT FROM SAPGLACCT";
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        da.Fill(dataTable);
                        conn.Close();
                        da.Dispose();
                    }
                    catch (Exception Ex)
                    { }
                }
            }
            return dataTable;
        //    return defaultGLAccountData();
        }



        public DataTable defaultData()
        {
            DataTable dt = new DataTable();
            DataColumn dc = new DataColumn("col1", typeof(String));
            dt.Columns.Add(dc);

            dc = new DataColumn("col2", typeof(String));
            dt.Columns.Add(dc);

            dc = new DataColumn("col3", typeof(String));
            dt.Columns.Add(dc);

            dc = new DataColumn("col4", typeof(String));
            dt.Columns.Add(dc);

            DataRow dr = dt.NewRow();

            dr[0] = "coldata1";
            dr[1] = "coldata2";
            dr[2] = "coldata3";
            dr[3] = "coldata4";

            dt.Rows.Add(dr);//this will add the row at the end of the datatable

            return dt;
        }

        public DataTable defaultGLAccountData()
        {
            DataTable dt = new DataTable();
            DataColumn dc = new DataColumn("GLACCT", typeof(String));
            dt.Columns.Add(dc);

            dc = new DataColumn("Concat", typeof(String));
            dt.Columns.Add(dc);

            dc = new DataColumn("GLACCTCAT", typeof(String));
            dt.Columns.Add(dc);


            DataRow dr = dt.NewRow();
            dr[0] = "1";
            dr[1] = "K1";
            dr[2] = "k";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "2";
            dr[1] = "K2";
            dr[2] = "k";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "5";
            dr[1] = "K5";
            dr[2] = "k";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "3";
            dr[1] = "F3";
            dr[2] = "f";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "4";
            dr[1] = "F4";
            dr[2] = "f";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "6";
            dr[1] = "H6";
            dr[2] = "h";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "9";
            dr[1] = "H9";
            dr[2] = "h";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "10";
            dr[1] = "I10";
            dr[2] = "i";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "7";
            dr[1] = "I7";
            dr[2] = "i";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "8";
            dr[1] = "J8";
            dr[2] = "j";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "11";
            dr[1] = "J11";
            dr[2] = "j";
            dt.Rows.Add(dr);

            return dt;
        }

        public DataTable defaultData_GetPurchGRPMRO()
        {
            DataTable dt = new DataTable();
            DataColumn dc = new DataColumn("PURGROUP", typeof(String));
            dt.Columns.Add(dc);

            dc = new DataColumn("purgrful", typeof(String));
            dt.Columns.Add(dc);

            DataRow dr = dt.NewRow();
            dr[0] = "REW";
            dr[1] = "REW-Rework";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "MRO";
            dr[1] = "MRO-MRO Cost Center";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "IO6";
            dr[1] = "IO6-RET PK Proto";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "IO5";
            dr[1] = "IO5-RET PK Exp";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "IO4";
            dr[1] = "IO4-RET PK Exp";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "IO3";
            dr[1] = "IO3-RET PK Exp";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "IO2";
            dr[1] = "IO2-RET PK Exp";
            dt.Rows.Add(dr);
            dr = dt.NewRow();
            dr[0] = "IO1";
            dr[1] = "IO1-RET PK Exp";
            dt.Rows.Add(dr);

            return dt;
        }


        //  public string GetUser(string UserNumber)
        //  {
        //      string username = String.Empty;

        //      using (SqlConnection con = new SqlConnection(_connectionString))
        //      {
        //          string sqlQuery = "Select top 1 EMP_lastname from sapscaleusers WHERE emp_number = '@EmpNumber'";
        //          using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
        //          {
        //              try
        //              {
        //                  cmd.Parameters.AddWithValue("@EmpNumber", UserNumber);
        //                  con.Open();
        //                  SqlDataReader rdr = cmd.ExecuteReader();
        //                  if (rdr.HasRows)
        //                  {
        //                      username = UserNumber;
        //                  }
        //                  else
        //                  {
        //                      username = "Bad";
        //                  }
        //                  con.Close();
        //              }
        //              catch (Exception Ex)
        //              {
        //                  if (con != null && con.State == ConnectionState.Open)
        //                      con.Close();
        //              }
        //              finally
        //              {
        //                  if (con != null && con.State == ConnectionState.Open)
        //                      con.Close();
        //              }
        //          }
        //      }
        //      return username;
        //  }

        //  public bool ValidateEndUnitPartNumber(string EndUnitPartNumber)
        //  {
        //      bool IsEndUnitPartNumberValid = false;
        //      if (EndUnitPartNumber.Contains("~"))
        //      {
        //          IsEndUnitPartNumberValid = true;
        //      }
        //      return IsEndUnitPartNumberValid;
        //  }

        //  public string GetDataWV(string sEndUnitPartNumber, string sItemPartNumber, string sCardNumber, string sEmpNumber)
        //  {
        //      string returnString = string.Empty;

        //      string CurTime = string.Empty;
        //      string MOWorkstation = string.Empty;
        //      string MO = string.Empty;
        //      string WorkStation = string.Empty;
        //      string Engine = string.Empty;
        //      int SerialNo_Position = 0;
        //      string StartDate = string.Empty;
        //      string EndUnitSerialNumber = string.Empty;
        //      string EndUnitPartNumber = string.Empty;
        //      string PrevEndUnitSerialNumber = string.Empty;
        //      string PrevEndUnitPartNumber = string.Empty;
        //      string StartEUSerialNumber = string.Empty;
        //      string EngineNo = string.Empty;
        //      string End_Unit = string.Empty;
        //      string PartNumber = string.Empty;
        //      string MOWorkStationString = string.Empty;
        //      string EUPartNumberString = string.Empty;
        //      string PrevEUPartNumberString = string.Empty;
        //      string Nakago = string.Empty;
        //      bool IsNakago = false;
        //      string PrevEUPN = string.Empty;


        //      try
        //      {

        //          CurTime = DateTime.Now.ToString("M/d/yyyy HH:mm:ss");
        //          EUPartNumberString = sEndUnitPartNumber;
        //          PrevEUPartNumberString = sEmpNumber;
        //          EndUnitPartNumber = EUPartNumberString.Split("~")[0];
        //          EndUnitSerialNumber = EUPartNumberString.Split("~")[1];
        //          PrevEndUnitPartNumber = PrevEUPartNumberString.Split("~")[0];
        //          PrevEndUnitSerialNumber = PrevEUPartNumberString.Split("~")[1];
        //          PartNumber = sItemPartNumber;
        //          MOWorkStationString = sCardNumber;

        //          if (PartNumber.Length != 0)
        //          {
        //              Nakago = PartNumber.Substring(3, 5);
        //          }

        //          if (MOWorkStationString.Length != 0)
        //          {
        //              MOWorkstation = GetMOWorkStationData("ZPWM_VALIDATE_CARD", MOWorkStationString, "", "", "");
        //              if (MOWorkstation.Split("|").Length > 3)
        //              {
        //                  MO = MOWorkstation.Split("|")[3];
        //                  WorkStation = MOWorkstation.Split("|")[2];
        //              }
        //              Console.WriteLine(MO);
        //          }

        //          using (SqlConnection con = new SqlConnection(_connectionString))
        //          {
        //              string sqlQuery = "select nakago from Nakago where nakago = '@Nakago'";
        //              using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
        //              {
        //                  try
        //                  {
        //                      cmd.Parameters.AddWithValue("@Nakago", Nakago);
        //                      con.Open();
        //                      SqlDataReader rdr = cmd.ExecuteReader();
        //                      if (rdr.HasRows)
        //                      {
        //                          IsNakago = true;
        //                      }
        //                      else
        //                      {
        //                          IsNakago = false;
        //                      }
        //                      con.Close();
        //                  }
        //                  catch (Exception Ex)
        //                  {
        //                      if (con != null && con.State == ConnectionState.Open)
        //                          con.Close();
        //                  }
        //                  finally
        //                  {
        //                      if (con != null && con.State == ConnectionState.Open)
        //                          con.Close();
        //                  }
        //              }
        //          }

        //          using (SqlConnection con = new SqlConnection(_connectionString))
        //          {
        //              string sqlQuery = "Select top 1 SERIALNO_POS from VIC_INT_BDBSASSYPL_ENDSN WHERE PART_NO = '@EndUnitPartNumber'";
        //              using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
        //              {
        //                  try
        //                  {
        //                      cmd.Parameters.AddWithValue("@EndUnitPartNumber", EndUnitPartNumber);
        //                      con.Open();
        //                      SqlDataReader rdr = cmd.ExecuteReader();
        //                      if (rdr.HasRows)
        //                      {
        //                          while (rdr.Read())
        //                          {
        //                              SerialNo_Position = rdr.GetInt32(0);
        //                          }
        //                          StartEUSerialNumber = EndUnitSerialNumber.Substring(SerialNo_Position - 1);
        //                          StartEUSerialNumber = StartEUSerialNumber.Replace("*", "");
        //                      }
        //                      else
        //                      {
        //                          IsNakago = false;
        //                      }
        //                      con.Close();
        //                  }
        //                  catch (Exception Ex)
        //                  {
        //                      if (con != null && con.State == ConnectionState.Open)
        //                          con.Close();
        //                  }
        //                  finally
        //                  {
        //                      if (con != null && con.State == ConnectionState.Open)
        //                          con.Close();
        //                  }
        //              }
        //          }


        //          if (sItemPartNumber.Substring(0, 1).ToLower() == "P" && sItemPartNumber.Length == 15)
        //              PartNumber = sItemPartNumber.Substring(1, 14);

        //          if (sItemPartNumber.Substring(0, 2) == "35")
        //          {
        //              string leftside = sItemPartNumber.Substring(2, 3);
        //              string rightside = sItemPartNumber.Substring(7, 7);
        //              string StampKey = string.Empty;
        //              StampKey = leftside + "  " + rightside;
        //              OracleConnection dbEngine = new OracleConnection("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=pdvicdb3)(PORT=12102)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=PDVICS01)));User Id=PYMAC3_YMMC_PUB2;Password=Z2kt74!;");
        //              dbEngine.Open();
        //              OracleCommand oraCommandEngine = new OracleCommand("Select ENGINE_NO from VIC_INT_PARTS_ITEM WHERE (STAMP_KEY = '" + StampKey + "') ", dbEngine);
        //              oraCommandEngine.BindByName = true;
        //              OracleDataReader oraReaderEngine = oraCommandEngine.ExecuteReader();
        //              if (oraReaderEngine.HasRows)
        //              {
        //                  while (oraReaderEngine.Read())
        //                  {
        //                      EngineNo = oraReaderEngine.GetString(0);
        //                  }
        //              }
        //              oraReaderEngine.Close();
        //              dbEngine.Close();
        //              dbEngine.Dispose();
        //              PartNumber = EngineNo.Trim() + "0080";
        //          }

        //          using (SqlConnection dbStartDate = new SqlConnection(_connectionString))
        //          {
        //              string sqlQuery = "Select Start_date from VIC_INT_BDBSASSYPL_ENDSN WHERE PART_NO = '" + EndUnitPartNumber + " 'AND START_SERIALNO <= '" + StartEUSerialNumber + "' AND END_SN >= '" + StartEUSerialNumber + "' ORDER BY START_DATE DESC";
        //              using (SqlCommand sqlCommandStartDate = new SqlCommand(sqlQuery, dbStartDate))
        //              {
        //                  try
        //                  {
        //                      dbStartDate.Open();
        //                      SqlDataReader sqlReaderStartDate = sqlCommandStartDate.ExecuteReader();
        //                      if (sqlReaderStartDate.HasRows)
        //                      {
        //                          while (sqlReaderStartDate.Read())
        //                          {
        //                              StartDate = sqlReaderStartDate.GetString(0);
        //                          }
        //                      }

        //                      dbStartDate.Close();
        //                  }
        //                  catch (Exception Ex)
        //                  {
        //                      if (dbStartDate != null && dbStartDate.State == ConnectionState.Open)
        //                          dbStartDate.Close();
        //                  }
        //                  finally
        //                  {
        //                      if (dbStartDate != null && dbStartDate.State == ConnectionState.Open)
        //                          dbStartDate.Close();
        //                  }
        //              }
        //          }




        //          using (OracleConnection dbEndUnit = new OracleConnection("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=pdymmc03.ymus.yamaha-motor.com)(PORT=9010)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=PDPYSAP12)));User Id=YMMC_LINVAL_01;Password=Trx7kqp65;"))
        //          {
        //              dbEndUnit.Open();
        //              using (OracleCommand oraCommandEndUnit = new OracleCommand("Select END_UNIT from PYBOM WHERE (substr(item_no,2,10) = '"+ PartNumber.Substring(0, 10) +"' or substr(item_no,1,10) = '"+ PartNumber.Substring(0, 10) +"') and END_UNIT = '"+ EndUnitPartNumber +"' and Start_Date ='"+StartDate+"'", dbEndUnit))
        //              {
        //                  oraCommandEndUnit.BindByName = true;
        //                  OracleDataReader oraReaderEndUnit = oraCommandEndUnit.ExecuteReader();
        //                  if (oraReaderEndUnit.HasRows)
        //                  {
        //                      while (oraReaderEndUnit.Read())
        //                      {
        //                          End_Unit = oraReaderEndUnit.GetString(0);
        //                      }
        //                  }
        //                  oraReaderEndUnit.Close();
        //              }
        //              dbEndUnit.Close();
        //          }

        //          End_Unit = End_Unit.Replace(" ", "");


        //          using (SqlConnection con = new SqlConnection(_connectionString))
        //          {
        //              using (SqlCommand cmd = new SqlCommand())
        //              {
        //                  if (End_Unit == EndUnitPartNumber)
        //                  {
        //                      if (IsNakago) {
        //                          con.Open();
        //                          cmd.Connection = con;
        //                          cmd.CommandText = "Insert into LinesideValidationLog ([User], [DateTime], [EUPN], [PYIN], [MSG], [Workstation], [MO_Number],[Nakago],[Scanned],[PrevEUPN]) values ('" + sEmpNumber + "', '" +CurTime + "', '" + EUPartNumberString +"', '" +PartNumber +"', 'Good','"+ WorkStation +"','"+ MO +"',1,1,'"+ PrevEUPartNumberString +"')";
        //                          cmd.ExecuteNonQuery();
        //                          con.Close();
        //                          return $"Good" + "|" + CurTime + "|" + WorkStation;
        //                      }
        //                      else
        //                      {
        //                          con.Open();
        //                          cmd.Connection = con;
        //                          cmd.CommandText = "Insert into LinesideValidationLog ([User], [DateTime], [EUPN], [PYIN], [MSG], [Workstation], [MO_Number],[Nakago],[Scanned],[PrevEUPN]) values ('" + sEmpNumber + "', '" + CurTime + "', '"+ EUPartNumberString + "', '" + PartNumber + "', 'Good','" + WorkStation +"','" + MO + "',0,1,'" + PrevEUPartNumberString +"')";
        //                          cmd.ExecuteNonQuery();
        //                          con.Close();
        //                          return "Bad" + "|" + CurTime + "|" + "None";
        //                      }
        //                  }
        //                  else
        //                  {
        //                      con.Open();
        //                      cmd.Connection = con;
        //                      cmd.CommandText = "Insert into LinesideValidationLog ([User], [DateTime], [EUPN], [PYIN], [MSG], [Workstation], [MO_Number],[Nakago],[Scanned],[PrevEUPN]) values ('" + sEmpNumber + "', '" + CurTime + "', '" + EUPartNumberString + "', '" + PartNumber + "', 'Bad','" + WorkStation + "','" + MO + "',0,0,'" + PrevEUPartNumberString + "')";
        //                      cmd.ExecuteNonQuery();
        //                      con.Close();
        //                      return "Bad" + "|" + CurTime + "|" + "None";
        //                  }
        //              }
        //          }

        //      }
        //      catch (Exception Ex)
        //      {
        //          using (SqlConnection con = new SqlConnection(_connectionString))
        //          {
        //              using (SqlCommand cmd = new SqlCommand())
        //              {
        //                  con.Open();
        //                  cmd.Connection = con;
        //                  cmd.CommandText = "Insert into LinesideValidationLog ([User], [DateTime], [EUPN], [PYIN], [MSG], [Workstation], [MO_Number]) values ('" + sEmpNumber + "', '" +CurTime + "', '" + EUPartNumberString + "', '" + PartNumber+ "', 'Bad','" + WorkStation + "','" +MO +"',0,0,'" + PrevEUPartNumberString +"')";
        //                  cmd.ExecuteNonQuery();
        //                  con.Close();
        //                  return "Bad" + "|" + CurTime + "|" + "None";
        //              }
        //          }


        //      }

        //      return returnString;
        //  }

        //  public string GetMOWorkStationData(string rfcname, string value1, string value2, string value3, string value4) {
        ////      SapNCo sapinfo = new SapNCo();
        //      string SAPReturnValue = String.Empty;
        // //     bool issap = sapinfo.InitSap();
        //      // 'If issap Then  for some strange reason does net dispose the object like c# does 
        //      if (rfcname.Contains("ZPWM_VALIDATE_CARD"))
        //      {
        //  //        SAPReturnValue = sapinfo.GetCardDataWithMOWorkStation(value1);
        //      }
        //      return SAPReturnValue;
        //  }

    }
}
