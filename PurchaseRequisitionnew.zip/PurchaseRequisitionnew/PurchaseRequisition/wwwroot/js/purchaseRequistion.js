﻿$(document).ready(function () {

    $("#CPFRNO_wrapper").hide();
    $("input[custAttr=numberonly]").keypress(function (e) {
        if (e.which != 13 && e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57))
            return false;
    });

    function buildGLAccountOptions(GLACCTCAT="k") {
        var options = `<option value="" required>Select Account</option>`
        $.each(GLAccount_OBJ, function (i) {
            if(GLAccount_OBJ[i].GLACCTCAT == GLACCTCAT)
                options += `<option value="`+ GLAccount_OBJ[i].GLACCT+`">`+GLAccount_OBJ[i].Concat+`</option>`
        });
        return options;
    }

    $("#AddItemBtn").click(function () {

        var noItemsAvailable = $("#LineItems").find(".noItemsAvailable");
        if (noItemsAvailable != null)
            noItemsAvailable.remove();
        var itemHTML = `<tr>
                                    <td><input name="LineItemText" value="" /></td>
                                    <td><input name="Description" value="" style="width:150px" /></td>
                                    <td>
                                        <select class="GLAccount">
                                            `+ buildGLAccountOptions() +`
                                        </select>
                                    </td>
                                    <td><input name="QTY" value="" style="width:50px" /></td>
                                    <td><input name="UnitPrice" value="" style="width:50px" /></td>
                                    <td>
                                        <select name="UOM">
                                            <option value="EA">EA</option>
                                        </select>
                                    </td>
                                    <td><input name="Total" value="" style="width:80px" /></td>
                                    <td>
                                        <select name="Taxable">
                                            <option value="YES">YES</option>
                                            <option value="NO">NO</option>
                                        </select>
                                    </td>
                                    <td><input name="DeliveryDate" value="" style="width:80px" /></td>
                                    <td><input name="VendorMaterial" value="" style="width:80px" /></td>
                                    <td><input name="TrackingNumber" value="" style="width:80px" /></td>
                                    <td>
                                     <!--   <i class="fa fa-edit itemEditBtn"></i> -->
                                        <i class="fa fa-trash itemDeleteBtn"></i>
                                    </td>
                                </tr>`;
        $(itemHTML).appendTo("#LineItems")

    });

    $(document).on("click", ".itemDeleteBtn", function () {
        $(this).closest("tr").remove();
        if ($("#LineItems").children().length == 0) {
            var itemHTML = `<tr class="noItemsAvailable"><td colspan="12">
                No line items available
            </td></tr>`;
            $(itemHTML).appendTo("#LineItems")
        }
    })

    function BuildCFRNumberDDList(PURGROUP = "") {
        var options = `<option value="" required>Select CPFRNO</option>`
        $.each(CPFRNO_OBJ, function (i) {
            if (CPFRNO_OBJ[i].PURGROUP == PURGROUP || PURGROUP == "")
                options += `<option value="` + CPFRNO_OBJ[i].CPFRNO + `">` + CPFRNO_OBJ[i].PURGROUP + `</option>`
        });
        $("#CPFRNODDlist").html(options)
    }

    $("#PurchaseGroupDDlist").change(function () {
        var PurchGRPMRO = $(this).val();
        var GLAccountOptions = "";
        if (PurchGRPMRO == "" || PurchGRPMRO == "MRO") {
            GLAccountOptions = buildGLAccountOptions('k');
            if (PurchGRPMRO == "MRO") {
                $("#CPFRNO_wrapper").hide();
                $("#CPFRNODDlist").val("")
                $("#CostCenter_wrapper").show();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("K")
            }

        }
        else
        if (PurchGRPMRO == "IO4") {
            GLAccountOptions = buildGLAccountOptions('h');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("H")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("IO4")
            $("#CPFRNODDlist").val("")
        }
        else
        if (PurchGRPMRO == "IO6") {
            GLAccountOptions = buildGLAccountOptions('j');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("J")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("IO6")
            $("#CPFRNODDlist").val("")
        }
        else
        if (PurchGRPMRO == "IO5") {
            GLAccountOptions = buildGLAccountOptions('i');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("I")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("IO5")
            $("#CPFRNODDlist").val("")
        }
        else
        if (PurchGRPMRO == "REW") {
            GLAccountOptions = buildGLAccountOptions('r');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("R")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("REW")
            $("#CPFRNODDlist").val("")
        }
        else {
            GLAccountOptions = buildGLAccountOptions('f');

            if (PurchGRPMRO == "IO1") {
                $("#CostCenter_wrapper").hide();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("F")
                $("#CPFRNO_wrapper").show();
                BuildCFRNumberDDList("IO1")
                $("#CPFRNODDlist").val("")
            }
            else
            if (PurchGRPMRO == "IO2") {
                $("#CostCenter_wrapper").hide();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("F")
                $("#CPFRNO_wrapper").show();
                BuildCFRNumberDDList("IO2")
                $("#CPFRNODDlist").val("")
            }
            else
            if (PurchGRPMRO == "IO3") {
                $("#CostCenter_wrapper").hide();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("F")
                $("#CPFRNO_wrapper").show();
                BuildCFRNumberDDList("IO3")
                $("#CPFRNODDlist").val("")
            }

        }

        $(document).find(".GLAccount").html(GLAccountOptions)



    });

    $("#PurchaseRequistionHistoryFrm").submit(function (e) {
        $("#errorMsg").text("");
        e.preventDefault();
        var SELF = $("#PurchaseRequistionHistoryFrm").serialize();

        return $.ajax({
            type: "POST",
            url: "/Requisition/PurchaseRequisitionHistory",
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            data: SELF,
            success: function (retData) {
                if (retData != null) {
                    if (retData.status == "1") {
                        $("#LineItems").html(retData.message);
                    }
                    else
                    if (retData.status == "-1") {
                        $("#LineItems").html(retData.message);
                    }
                    else
                    if (retData.status == "-2") {
                        $("#errorMsg").text(retData.message);
                    }

                }
                else {
                    $("#LineItems").html(retData.message);
                }
            },
            error: function (data) {
                alert("Some error occoured. Please try later");
            }
        });

        return false;
    });


    $("#SubmitRequistionBtn").click(function (evt) {
        evt.preventDefault();
        var PurchaseRequistionLineItemList = [];
        $("#LineItems").children().each(function () {
            PurchaseRequistionLineItemList.push(JSON.stringify({
                "LineItem": $(this).find(':nth-child(1) > input').val(),
                "Description": $(this).find(':nth-child(2) > input').val(),
                "GLAccount": $(this).find(':nth-child(3) > select').val(),
                "Quantity": $(this).find(':nth-child(4) > input').val(),
                "UnitPrice": $(this).find(':nth-child(5) > input').val(),
                "UOM": $(this).find(':nth-child(6) > select').val(),
                "Total": $(this).find(':nth-child(7) > input').val(),
                "Taxable": $(this).find(':nth-child(8) > select').val(),
                "DeliveryDate": $(this).find(':nth-child(9) > input').val(),
                "VendorMaterial": $(this).find(':nth-child(10) > input').val(),
                "TrackingNumber": $(this).find(':nth-child(11) > input').val(),
            }));
        });

        var PurchaseRequistion = {
            "purchaseGroup": $("#PurchaseGroupDDlist").val(),
            "costCenter": $("#CostCenterDDlist").val(),
            "vendor": $("#VendorDDlist").val(),
            "cPFRNO": $("#CPFRNODDlist").val(),
            "headerText": $("#HeaderText").val(),
            "acctCat": $("#txtacctcat").val(),
            "purchaseRequistionLineItems": PurchaseRequistionLineItemList
        }

        return $.ajax({
            type: "POST",
            url: "/Requisition/SubmitPurchaseRequisition",
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            data: JSON.stringify(PurchaseRequistion),
            success: function (data) {
                return data;
            },
            error: function (data) {
                alert("Some error occoured. Please try later");
            }
        });


    });

});



