﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseRequisition.ViewModel
{
    public class HistoryViewModel
    {
        public string PurchaseRequistion { get; set; }
        public string RequistionFromDate { get; set; }
        public string RequistionToDate { get; set; }
        public string VendorNumber { get; set; }
        public string Requistioner { get; set; }
        public string CostCenter { get; set; }
        public string CPFR { get; set; }
        public string TrackingNumber { get; set; }
    }
}
