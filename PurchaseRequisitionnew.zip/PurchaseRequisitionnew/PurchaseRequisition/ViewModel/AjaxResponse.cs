﻿namespace PurchaseRequisition.ViewModel
{
    public class AjaxResponse
    {
        public string status { get; set; }
        public string message { get; set; }
        public string redirecturl { get; set; }
    }
}
