﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.DirectoryServices

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click

        'sets the sql database connection based upon the web.config settings
        If Page.IsValid Then


            Try
                Button1.Enabled = False
                Dim con As New SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
                Dim cmd As New SqlCommand
                Dim myLdapConnection As DirectoryEntry = createDirectoryEntry()
                Dim search As DirectorySearcher = New DirectorySearcher(myLdapConnection)
                Dim FQDN As String = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name ' User.Identity.Name.ToString For some reason this no longer works in Windows Server 2016
                'FQDN = "YMMCDOM\TESTNAME12345"
                ' https://stackoverflow.com/questions/1056487/httpcontext-current-user-identity-name-is-always-string-empty
                Dim usrnm As String = FQDN.Remove(0, 8)
                Dim email As String = usrnm + "@ymmc.yamaha-motor.com"
                Dim dlvdate1 As DateTime = txtdate1.Text
                Dim s1 As String
                Dim dlvdate2 As DateTime = txtdate2.Text
                Dim s2 As String
                Dim dlvdate3 As DateTime = txtdate2.Text
                Dim s3 As String
                Dim dlvdate4 As DateTime = txtdate2.Text
                Dim s4 As String
                Dim dlvdate5 As DateTime = txtdate2.Text
                Dim s5 As String
                Dim dlvdate6 As DateTime = txtdate2.Text
                Dim s6 As String
                Dim dlvdate7 As DateTime = txtdate2.Text
                Dim s7 As String
                Dim dlvdate8 As DateTime = txtdate2.Text
                Dim s8 As String
                Dim dlvdate9 As DateTime = txtdate2.Text
                Dim s9 As String
                Dim dlvdate10 As DateTime = txtdate2.Text
                Dim s10 As String
                Dim dlvdate11 As DateTime = txtdate1.Text
                Dim s11 As String
                Dim dlvdate12 As DateTime = txtdate2.Text
                Dim s12 As String
                Dim dlvdate13 As DateTime = txtdate2.Text
                Dim s13 As String
                Dim dlvdate14 As DateTime = txtdate2.Text
                Dim s14 As String
                Dim dlvdate15 As DateTime = txtdate2.Text
                Dim s15 As String
                Dim dlvdate16 As DateTime = txtdate2.Text
                Dim s16 As String
                Dim dlvdate17 As DateTime = txtdate2.Text
                Dim s17 As String
                Dim dlvdate18 As DateTime = txtdate2.Text
                Dim s18 As String
                Dim dlvdate19 As DateTime = txtdate2.Text
                Dim s19 As String
                Dim dlvdate20 As DateTime = txtdate2.Text
                Dim s20 As String
                Dim dlvdate21 As DateTime = txtdate1.Text
                Dim s21 As String
                Dim dlvdate22 As DateTime = txtdate2.Text
                Dim s22 As String
                Dim dlvdate23 As DateTime = txtdate2.Text
                Dim s23 As String
                Dim dlvdate24 As DateTime = txtdate2.Text
                Dim s24 As String
                Dim dlvdate25 As DateTime = txtdate2.Text
                Dim s25 As String
                Dim dlvdate26 As DateTime = txtdate2.Text
                Dim s26 As String
                Dim dlvdate27 As DateTime = txtdate2.Text
                Dim s27 As String
                Dim dlvdate28 As DateTime = txtdate2.Text
                Dim s28 As String
                Dim dlvdate29 As DateTime = txtdate2.Text
                Dim s29 As String
                Dim dlvdate30 As DateTime = txtdate2.Text
                Dim s30 As String

                s1 = dlvdate1.ToString("yyyyMMdd")
                s2 = dlvdate2.ToString("yyyyMMdd")
                s3 = dlvdate1.ToString("yyyyMMdd")
                s4 = dlvdate2.ToString("yyyyMMdd")
                s5 = dlvdate2.ToString("yyyyMMdd")
                s6 = dlvdate1.ToString("yyyyMMdd")
                s7 = dlvdate2.ToString("yyyyMMdd")
                s8 = dlvdate1.ToString("yyyyMMdd")
                s9 = dlvdate2.ToString("yyyyMMdd")
                s10 = dlvdate2.ToString("yyyyMMdd")
                s11 = dlvdate1.ToString("yyyyMMdd")
                s12 = dlvdate2.ToString("yyyyMMdd")
                s13 = dlvdate1.ToString("yyyyMMdd")
                s14 = dlvdate2.ToString("yyyyMMdd")
                s15 = dlvdate2.ToString("yyyyMMdd")
                s16 = dlvdate1.ToString("yyyyMMdd")
                s17 = dlvdate2.ToString("yyyyMMdd")
                s18 = dlvdate1.ToString("yyyyMMdd")
                s19 = dlvdate2.ToString("yyyyMMdd")
                s20 = dlvdate2.ToString("yyyyMMdd")
                s21 = dlvdate1.ToString("yyyyMMdd")
                s22 = dlvdate2.ToString("yyyyMMdd")
                s23 = dlvdate1.ToString("yyyyMMdd")
                s24 = dlvdate2.ToString("yyyyMMdd")
                s25 = dlvdate2.ToString("yyyyMMdd")
                s26 = dlvdate1.ToString("yyyyMMdd")
                s27 = dlvdate2.ToString("yyyyMMdd")
                s28 = dlvdate1.ToString("yyyyMMdd")
                s29 = dlvdate2.ToString("yyyyMMdd")
                s30 = dlvdate2.ToString("yyyyMMdd")

                Dim prc1string As String = txtprice1.Text
                Dim prc1 As Decimal = Convert.ToDecimal(prc1string)
                Dim prcdec1 As String = prc1.ToString("0.00")
                Dim prc2string As String = txtprice2.Text
                Dim prc2 As Decimal = Convert.ToDecimal(prc2string)
                Dim prcdec2 As String = prc2.ToString("0.00")
                Dim prc3string As String = txtprice3.Text
                Dim prc3 As Decimal = Convert.ToDecimal(prc3string)
                Dim prcdec3 As String = prc3.ToString("0.00")
                Dim prc4string As String = txtprice4.Text
                Dim prc4 As Decimal = Convert.ToDecimal(prc4string)
                Dim prcdec4 As String = prc4.ToString("0.00")
                Dim prc5string As String = txtprice5.Text
                Dim prc5 As Decimal = Convert.ToDecimal(prc5string)
                Dim prcdec5 As String = prc5.ToString("0.00")
                Dim prc6string As String = txtprice6.Text
                Dim prc6 As Decimal = Convert.ToDecimal(prc6string)
                Dim prcdec6 As String = prc6.ToString("0.00")
                Dim prc7string As String = txtprice7.Text
                Dim prc7 As Decimal = Convert.ToDecimal(prc7string)
                Dim prcdec7 As String = prc7.ToString("0.00")
                Dim prc8string As String = txtprice8.Text
                Dim prc8 As Decimal = Convert.ToDecimal(prc8string)
                Dim prcdec8 As String = prc8.ToString("0.00")
                Dim prc9string As String = txtprice9.Text
                Dim prc9 As Decimal = Convert.ToDecimal(prc9string)
                Dim prcdec9 As String = prc9.ToString("0.00")
                Dim prc10string As String = txtprice10.Text
                Dim prc10 As Decimal = Convert.ToDecimal(prc10string)
                Dim prcdec10 As String = prc10.ToString("0.00")
                Dim prc11string As String = txtprice11.Text
                Dim prc11 As Decimal = Convert.ToDecimal(prc11string)
                Dim prcdec11 As String = prc11.ToString("0.00")
                Dim prc12string As String = txtprice12.Text
                Dim prc12 As Decimal = Convert.ToDecimal(prc12string)
                Dim prcdec12 As String = prc12.ToString("0.00")
                Dim prc13string As String = txtprice13.Text
                Dim prc13 As Decimal = Convert.ToDecimal(prc13string)
                Dim prcdec13 As String = prc13.ToString("0.00")
                Dim prc14string As String = txtprice14.Text
                Dim prc14 As Decimal = Convert.ToDecimal(prc14string)
                Dim prcdec14 As String = prc14.ToString("0.00")
                Dim prc15string As String = txtprice15.Text
                Dim prc15 As Decimal = Convert.ToDecimal(prc15string)
                Dim prcdec15 As String = prc15.ToString("0.00")
                Dim prc16string As String = txtprice16.Text
                Dim prc16 As Decimal = Convert.ToDecimal(prc16string)
                Dim prcdec16 As String = prc16.ToString("0.00")
                Dim prc17string As String = txtprice17.Text
                Dim prc17 As Decimal = Convert.ToDecimal(prc17string)
                Dim prcdec17 As String = prc17.ToString("0.00")
                Dim prc18string As String = txtprice18.Text
                Dim prc18 As Decimal = Convert.ToDecimal(prc18string)
                Dim prcdec18 As String = prc18.ToString("0.00")
                Dim prc19string As String = txtprice19.Text
                Dim prc19 As Decimal = Convert.ToDecimal(prc19string)
                Dim prcdec19 As String = prc19.ToString("0.00")
                Dim prc20string As String = txtprice20.Text
                Dim prc20 As Decimal = Convert.ToDecimal(prc20string)
                Dim prcdec20 As String = prc20.ToString("0.00")
                Dim prc21string As String = txtprice21.Text
                Dim prc21 As Decimal = Convert.ToDecimal(prc21string)
                Dim prcdec21 As String = prc21.ToString("0.00")
                Dim prc22string As String = txtprice22.Text
                Dim prc22 As Decimal = Convert.ToDecimal(prc22string)
                Dim prcdec22 As String = prc22.ToString("0.00")
                Dim prc23string As String = txtprice23.Text
                Dim prc23 As Decimal = Convert.ToDecimal(prc23string)
                Dim prcdec23 As String = prc23.ToString("0.00")
                Dim prc24string As String = txtprice24.Text
                Dim prc24 As Decimal = Convert.ToDecimal(prc24string)
                Dim prcdec24 As String = prc24.ToString("0.00")
                Dim prc25string As String = txtprice25.Text
                Dim prc25 As Decimal = Convert.ToDecimal(prc25string)
                Dim prcdec25 As String = prc25.ToString("0.00")
                Dim prc26string As String = txtprice26.Text
                Dim prc26 As Decimal = Convert.ToDecimal(prc26string)
                Dim prcdec26 As String = prc26.ToString("0.00")
                Dim prc27string As String = txtprice27.Text
                Dim prc27 As Decimal = Convert.ToDecimal(prc27string)
                Dim prcdec27 As String = prc27.ToString("0.00")
                Dim prc28string As String = txtprice28.Text
                Dim prc28 As Decimal = Convert.ToDecimal(prc28string)
                Dim prcdec28 As String = prc28.ToString("0.00")
                Dim prc29string As String = txtprice29.Text
                Dim prc29 As Decimal = Convert.ToDecimal(prc29string)
                Dim prcdec29 As String = prc29.ToString("0.00")
                Dim prc30string As String = txtprice30.Text
                Dim prc30 As Decimal = Convert.ToDecimal(prc30string)
                Dim prcdec30 As String = prc30.ToString("0.00")

                Txthead.Text = Txthead.Text.Replace("'", "''")

                txtlng1.Text = txtlng1.Text.Replace("'", "''")
                txtlng2.Text = txtlng2.Text.Replace("'", "''")
                txtlng3.Text = txtlng3.Text.Replace("'", "''")
                txtlng4.Text = txtlng4.Text.Replace("'", "''")
                txtlng5.Text = txtlng5.Text.Replace("'", "''")
                txtlng6.Text = txtlng6.Text.Replace("'", "''")
                txtlng7.Text = txtlng7.Text.Replace("'", "''")
                txtlng8.Text = txtlng8.Text.Replace("'", "''")
                txtlng9.Text = txtlng9.Text.Replace("'", "''")
                txtlng10.Text = txtlng10.Text.Replace("'", "''")
                txtlng11.Text = txtlng11.Text.Replace("'", "''")
                txtlng12.Text = txtlng12.Text.Replace("'", "''")
                txtlng13.Text = txtlng13.Text.Replace("'", "''")
                txtlng14.Text = txtlng14.Text.Replace("'", "''")
                txtlng15.Text = txtlng15.Text.Replace("'", "''")
                txtlng16.Text = txtlng16.Text.Replace("'", "''")
                txtlng17.Text = txtlng17.Text.Replace("'", "''")
                txtlng18.Text = txtlng18.Text.Replace("'", "''")
                txtlng19.Text = txtlng19.Text.Replace("'", "''")
                txtlng20.Text = txtlng20.Text.Replace("'", "''")
                txtlng21.Text = txtlng21.Text.Replace("'", "''")
                txtlng22.Text = txtlng22.Text.Replace("'", "''")
                txtlng23.Text = txtlng23.Text.Replace("'", "''")
                txtlng24.Text = txtlng24.Text.Replace("'", "''")
                txtlng25.Text = txtlng25.Text.Replace("'", "''")
                txtlng26.Text = txtlng26.Text.Replace("'", "''")
                txtlng27.Text = txtlng27.Text.Replace("'", "''")
                txtlng28.Text = txtlng28.Text.Replace("'", "''")
                txtlng29.Text = txtlng29.Text.Replace("'", "''")
                txtlng30.Text = txtlng30.Text.Replace("'", "''")

                txtshrt1.Text = txtshrt1.Text.Replace("'", "''")
                txtshrt2.Text = txtshrt2.Text.Replace("'", "''")
                txtshrt3.Text = txtshrt3.Text.Replace("'", "''")
                txtshrt4.Text = txtshrt4.Text.Replace("'", "''")
                txtshrt5.Text = txtshrt5.Text.Replace("'", "''")
                txtshrt6.Text = txtshrt6.Text.Replace("'", "''")
                txtshrt7.Text = txtshrt7.Text.Replace("'", "''")
                txtshrt8.Text = txtshrt8.Text.Replace("'", "''")
                txtshrt9.Text = txtshrt9.Text.Replace("'", "''")
                txtshrt10.Text = txtshrt10.Text.Replace("'", "''")
                txtshrt11.Text = txtshrt11.Text.Replace("'", "''")
                txtshrt12.Text = txtshrt12.Text.Replace("'", "''")
                txtshrt13.Text = txtshrt13.Text.Replace("'", "''")
                txtshrt14.Text = txtshrt14.Text.Replace("'", "''")
                txtshrt15.Text = txtshrt15.Text.Replace("'", "''")
                txtshrt16.Text = txtshrt16.Text.Replace("'", "''")
                txtshrt17.Text = txtshrt17.Text.Replace("'", "''")
                txtshrt18.Text = txtshrt18.Text.Replace("'", "''")
                txtshrt19.Text = txtshrt19.Text.Replace("'", "''")
                txtshrt20.Text = txtshrt20.Text.Replace("'", "''")
                txtshrt21.Text = txtshrt21.Text.Replace("'", "''")
                txtshrt22.Text = txtshrt22.Text.Replace("'", "''")
                txtshrt23.Text = txtshrt23.Text.Replace("'", "''")
                txtshrt24.Text = txtshrt24.Text.Replace("'", "''")
                txtshrt25.Text = txtshrt25.Text.Replace("'", "''")
                txtshrt26.Text = txtshrt26.Text.Replace("'", "''")
                txtshrt27.Text = txtshrt27.Text.Replace("'", "''")
                txtshrt28.Text = txtshrt28.Text.Replace("'", "''")
                txtshrt29.Text = txtshrt29.Text.Replace("'", "''")
                txtshrt30.Text = txtshrt30.Text.Replace("'", "''")

                Txtvenmat1.Text = Txtvenmat1.Text.Replace("'", "''")
                Txtvenmat2.Text = Txtvenmat2.Text.Replace("'", "''")
                Txtvenmat3.Text = Txtvenmat3.Text.Replace("'", "''")
                Txtvenmat4.Text = Txtvenmat4.Text.Replace("'", "''")
                Txtvenmat5.Text = Txtvenmat5.Text.Replace("'", "''")
                Txtvenmat6.Text = Txtvenmat6.Text.Replace("'", "''")
                Txtvenmat7.Text = Txtvenmat7.Text.Replace("'", "''")
                Txtvenmat8.Text = Txtvenmat8.Text.Replace("'", "''")
                Txtvenmat9.Text = Txtvenmat9.Text.Replace("'", "''")
                Txtvenmat10.Text = Txtvenmat10.Text.Replace("'", "''")
                Txtvenmat11.Text = Txtvenmat11.Text.Replace("'", "''")
                Txtvenmat12.Text = Txtvenmat12.Text.Replace("'", "''")
                Txtvenmat13.Text = Txtvenmat13.Text.Replace("'", "''")
                Txtvenmat14.Text = Txtvenmat14.Text.Replace("'", "''")
                Txtvenmat15.Text = Txtvenmat15.Text.Replace("'", "''")
                Txtvenmat16.Text = Txtvenmat16.Text.Replace("'", "''")
                Txtvenmat17.Text = Txtvenmat17.Text.Replace("'", "''")
                Txtvenmat18.Text = Txtvenmat18.Text.Replace("'", "''")
                Txtvenmat19.Text = Txtvenmat19.Text.Replace("'", "''")
                Txtvenmat20.Text = Txtvenmat20.Text.Replace("'", "''")
                Txtvenmat21.Text = Txtvenmat21.Text.Replace("'", "''")
                Txtvenmat22.Text = Txtvenmat22.Text.Replace("'", "''")
                Txtvenmat23.Text = Txtvenmat23.Text.Replace("'", "''")
                Txtvenmat24.Text = Txtvenmat24.Text.Replace("'", "''")
                Txtvenmat25.Text = Txtvenmat25.Text.Replace("'", "''")
                Txtvenmat26.Text = Txtvenmat26.Text.Replace("'", "''")
                Txtvenmat27.Text = Txtvenmat27.Text.Replace("'", "''")
                Txtvenmat28.Text = Txtvenmat28.Text.Replace("'", "''")
                Txtvenmat29.Text = Txtvenmat29.Text.Replace("'", "''")
                Txtvenmat30.Text = Txtvenmat30.Text.Replace("'", "''")

                Txttrackno1.Text = Txttrackno1.Text.Replace("'", "''")
                Txttrackno2.Text = Txttrackno2.Text.Replace("'", "''")
                Txttrackno3.Text = Txttrackno3.Text.Replace("'", "''")
                Txttrackno4.Text = Txttrackno4.Text.Replace("'", "''")
                Txttrackno5.Text = Txttrackno5.Text.Replace("'", "''")
                Txttrackno6.Text = Txttrackno6.Text.Replace("'", "''")
                Txttrackno7.Text = Txttrackno7.Text.Replace("'", "''")
                Txttrackno8.Text = Txttrackno8.Text.Replace("'", "''")
                Txttrackno9.Text = Txttrackno9.Text.Replace("'", "''")
                Txttrackno10.Text = Txttrackno10.Text.Replace("'", "''")
                Txttrackno11.Text = Txttrackno11.Text.Replace("'", "''")
                Txttrackno12.Text = Txttrackno12.Text.Replace("'", "''")
                Txttrackno13.Text = Txttrackno13.Text.Replace("'", "''")
                Txttrackno14.Text = Txttrackno14.Text.Replace("'", "''")
                Txttrackno15.Text = Txttrackno15.Text.Replace("'", "''")
                Txttrackno16.Text = Txttrackno16.Text.Replace("'", "''")
                Txttrackno17.Text = Txttrackno17.Text.Replace("'", "''")
                Txttrackno18.Text = Txttrackno18.Text.Replace("'", "''")
                Txttrackno19.Text = Txttrackno19.Text.Replace("'", "''")
                Txttrackno20.Text = Txttrackno20.Text.Replace("'", "''")
                Txttrackno21.Text = Txttrackno21.Text.Replace("'", "''")
                Txttrackno22.Text = Txttrackno22.Text.Replace("'", "''")
                Txttrackno23.Text = Txttrackno23.Text.Replace("'", "''")
                Txttrackno24.Text = Txttrackno24.Text.Replace("'", "''")
                Txttrackno25.Text = Txttrackno25.Text.Replace("'", "''")
                Txttrackno26.Text = Txttrackno26.Text.Replace("'", "''")
                Txttrackno27.Text = Txttrackno27.Text.Replace("'", "''")
                Txttrackno28.Text = Txttrackno28.Text.Replace("'", "''")
                Txttrackno29.Text = Txttrackno29.Text.Replace("'", "''")
                Txttrackno30.Text = Txttrackno30.Text.Replace("'", "''")

                'opens the connection and inserts the required data
                'con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;User Instance=True"
                If txtshrt30.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & Txtvenmat24.Text & "', '" & Txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & Txtvenmat25.Text & "', '" & Txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & Txtvenmat26.Text & "', '" & Txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & Txtvenmat27.Text & "', '" & Txttrackno27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.SelectedValue & "', '" & s28 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl28.SelectedValue & "', '" & Txtvenmat28.Text & "', '" & Txttrackno28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl290.Text & "', '" & txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.SelectedValue & "', '" & s29 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl29.SelectedValue & "', '" & Txtvenmat29.Text & "', '" & Txttrackno29.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl300.Text & "', '" & txtshrt30.Text & "', '" & txtlng30.Text & "', '" & txtqty30.Text & "', '" & prcdec30 & "', '" & ddluom30.Text & "', '" & ddltax30.SelectedValue & "', '" & s30 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl30.SelectedValue & "', '" & Txtvenmat30.Text & "', '" & Txttrackno30.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.Text & "', '" & txtdate28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl290.Text & "', '" & txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.Text & "', '" & txtdate29.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl300.Text & "', '" & txtshrt30.Text & "', '" & txtlng30.Text & "', '" & txtqty30.Text & "', '" & prcdec30 & "', '" & ddluom30.Text & "', '" & ddltax30.Text & "', '" & txtdate30.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt29.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & Txtvenmat24.Text & "', '" & Txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & Txtvenmat25.Text & "', '" & Txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & Txtvenmat26.Text & "', '" & Txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & Txtvenmat27.Text & "', '" & Txttrackno27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.SelectedValue & "', '" & s28 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl28.SelectedValue & "', '" & Txtvenmat28.Text & "', '" & Txttrackno28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl290.Text & "', '" & txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.SelectedValue & "', '" & s29 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl29.SelectedValue & "', '" & Txtvenmat29.Text & "', '" & Txttrackno29.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.Text & "', '" & txtdate28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl290.Text & "', '" & txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.Text & "', '" & txtdate29.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt28.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & Txtvenmat24.Text & "', '" & Txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & Txtvenmat25.Text & "', '" & Txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & Txtvenmat26.Text & "', '" & Txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & Txtvenmat27.Text & "', '" & Txttrackno27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.SelectedValue & "', '" & s28 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl28.SelectedValue & "', '" & Txtvenmat28.Text & "', '" & Txttrackno28.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.Text & "', '" & txtdate28.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt27.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & Txtvenmat24.Text & "', '" & Txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & Txtvenmat25.Text & "', '" & Txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & Txtvenmat26.Text & "', '" & Txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & Txtvenmat27.Text & "', '" & Txttrackno27.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt26.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & Txtvenmat24.Text & "', '" & Txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & Txtvenmat25.Text & "', '" & Txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & Txtvenmat26.Text & "', '" & Txttrackno26.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt25.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & Txtvenmat24.Text & "', '" & Txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & Txtvenmat25.Text & "', '" & Txttrackno25.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt24.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & Txtvenmat24.Text & "', '" & Txttrackno24.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt23.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & Txtvenmat23.Text & "', '" & Txttrackno23.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt22.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & Txtvenmat22.Text & "', '" & Txttrackno22.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt21.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & Txtvenmat21.Text & "', '" & Txttrackno21.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt20.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & Txtvenmat20.Text & "', '" & Txttrackno20.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt19.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & Txtvenmat19.Text & "', '" & Txttrackno19.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt18.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & Txtvenmat18.Text & "', '" & Txttrackno18.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt17.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & Txtvenmat17.Text & "', '" & Txttrackno17.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt16.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & Txtvenmat16.Text & "', '" & Txttrackno16.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt15.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & Txtvenmat15.Text & "', '" & Txttrackno15.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt14.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & Txtvenmat14.Text & "', '" & Txttrackno14.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt13.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & Txtvenmat13.Text & "', '" & Txttrackno13.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt12.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & Txtvenmat12.Text & "', '" & Txttrackno12.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt11.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & Txtvenmat11.Text & "', '" & Txttrackno11.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt10.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & Txtvenmat10.Text & "', '" & Txttrackno10.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt9.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & Txtvenmat9.Text & "', '" & Txttrackno9.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt8.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & Txtvenmat8.Text & "', '" & Txttrackno8.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt7.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & Txtvenmat7.Text & "', '" & Txttrackno7.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt6.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & Txtvenmat6.Text & "', '" & Txttrackno6.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt5.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & Txtvenmat5.Text & "', '" & Txttrackno5.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt4.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & Txtvenmat4.Text & "', '" & Txttrackno4.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt3.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & Txtvenmat3.Text & "', '" & Txttrackno3.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf txtshrt2.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & Txtvenmat2.Text & "', '" & Txttrackno2.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                Else
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddlcpfr.SelectedValue & "', '" & LblGroup.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "','" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & Left(usrnm, 12) & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & Txtvenmat1.Text & "', '" & Txttrackno1.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate, subdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddlcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "','" & DateTime.Now & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                End If

                'con.Open()
                'cmd.Connection = con
                'cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                'Dim result As Object = cmd.ExecuteScalar
                'Dim RNO As String = CType(Session.Item("RNO"), String)
                'Dim uppath As String
                'Dim upname As String

                'uppath = "C:\inetpub\www-YCentral\data\poreq\" & RNO
                'Session("VenNo") = ""

                'upname = Dir(uppath, vbDirectory)
                'MkDir("C:\inetpub\www-YCentral\data\poreq\" & RNO)

                'Dim up1 As String
                'Dim up2 As String
                'Dim up3 As String
                'Dim up4 As String
                'Dim up5 As String
                'up1 = FileUpload1.PostedFile.FileName
                'up2 = FileUpload2.PostedFile.FileName
                'up3 = FileUpload3.PostedFile.FileName
                'up4 = FileUpload4.PostedFile.FileName
                'up5 = FileUpload5.PostedFile.FileName
                'Dim a As String = System.IO.Path.GetFileName(up1)
                'Dim b As String = System.IO.Path.GetFileName(up2)
                'Dim c As String = System.IO.Path.GetFileName(up3)
                'Dim d As String = System.IO.Path.GetFileName(up4)
                'Dim f As String = System.IO.Path.GetFileName(up5)

                'Try
                '    FileUpload1.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + a)
                '    FileUpload2.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + b)
                '    FileUpload3.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + c)
                '    FileUpload4.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + d)
                '    FileUpload5.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + f)
                'Catch ex As Exception

                'End Try
                Button1.Enabled = True
                Response.Redirect("default.aspx")
                'con.Open()
                'cmd.Connection = con
                'cmd.CommandText = "select top 1 seqno from purchreq order by seqno desc"
                'Dim result As Object = cmd.ExecuteScalar
                'lblresult.Text = String.Format(result) + 1
                'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddlcpfr.Text & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddlcpfr.Text & "', '" & ddlgrp.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & txtprice2.Text & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "')"
                'cmd.ExecuteNonQuery()
                'con.Close()
            Catch ex As Exception
                Page.RegisterClientScriptBlock("OnLoad", "<script>alert('Unit Price is too long')</script>")
                'Response.Write(ex.Message)
            End Try
        End If

    End Sub
    Private Shared Function createDirectoryEntry() As DirectoryEntry
        Dim ldapConnection As DirectoryEntry = New DirectoryEntry("YMMCDOM.COM")
        ldapConnection.Path = "LDAP://OU=users,DC=YMMCDOM"
        ldapConnection.AuthenticationType = AuthenticationTypes.Secure
        Return ldapConnection
    End Function

    Protected Sub btnadd1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd1.Click
        lbl20.Visible = True
        txtshrt2.Visible = True
        txtlng2.Visible = True
        txtqty2.Visible = True
        txtprice2.Visible = True
        ddluom2.Visible = True
        txttotal2.Visible = True
        ddltax2.Visible = True
        txtdate2.Visible = True
        BtnAdd1.Visible = False
        BtnAdd2.Visible = True
        BtnRem1.Visible = True
        ddlgl2.Visible = True
        valtxtshrt2.Visible = True
        ''vallngthtxtlng2.Visible = True
        valddlgl2.Visible = True
        numvaltxtqty2.Visible = True
        valtxtqty2.Visible = True
        numvaltxtprice2.Visible = True
        valtxtprice2.Visible = True
        ddlgl2.databind()
        txtprice2.Text = ""
        vallngthtxtlng2.Visible = True
        txtvenmat2.visible = True
        txttrackno2.visible = True

        'ddlgl2.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))

    End Sub
    Protected Sub BtnAdd2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd2.Click
        lbl30.Visible = True
        txtshrt3.Visible = True
        txtlng3.Visible = True
        txtqty3.Visible = True
        txtprice3.Visible = True
        ddluom3.Visible = True
        txttotal3.Visible = True
        ddltax3.Visible = True
        txtdate3.Visible = True
        BtnAdd2.Visible = False
        BtnAdd3.Visible = True
        BtnRem2.Visible = True
        BtnRem1.Visible = False
        ddlgl3.Visible = True
        valtxtshrt3.Visible = True
        'vallngthtxtlng3.Visible = True
        valddlgl3.Visible = True
        numvaltxtqty3.Visible = True
        valtxtqty3.Visible = True
        numvaltxtprice3.Visible = True
        valtxtprice3.Visible = True
        ddlgl3.databind()
        txtprice3.Text = ""

        vallngthtxtlng3.Visible = True
        txtvenmat3.visible = True
        txttrackno3.visible = True

    End Sub
    Protected Sub BtnAdd3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd3.Click
        lbl40.Visible = True
        txtshrt4.Visible = True
        txtlng4.Visible = True
        txtqty4.Visible = True
        txtprice4.Visible = True
        ddluom4.Visible = True
        txttotal4.Visible = True
        ddltax4.Visible = True
        txtdate4.Visible = True
        BtnAdd3.Visible = False
        BtnAdd4.Visible = True
        BtnRem3.Visible = True
        BtnRem2.Visible = False
        ddlgl4.Visible = True
        valtxtshrt4.Visible = True
        'vallngthtxtlng4.Visible = True
        valddlgl4.Visible = True
        numvaltxtqty4.Visible = True
        valtxtqty4.Visible = True
        numvaltxtprice4.Visible = True
        valtxtprice4.Visible = True
        ddlgl4.databind()
        txtprice4.Text = ""

        vallngthtxtlng4.Visible = True
        txtvenmat4.visible = True
        txttrackno4.visible = True

    End Sub


    Protected Sub BtnAdd4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd4.Click
        lbl50.Visible = True
        txtshrt5.Visible = True
        txtlng5.Visible = True
        txtqty5.Visible = True
        txtprice5.Visible = True
        ddluom5.Visible = True
        txttotal5.Visible = True
        ddltax5.Visible = True
        txtdate5.Visible = True
        BtnAdd4.Visible = False
        BtnAdd5.Visible = True
        BtnRem4.Visible = True
        BtnRem3.Visible = False
        ddlgl5.Visible = True
        valtxtshrt5.Visible = True
        'vallngthtxtlng5.Visible = True
        valddlgl5.Visible = True
        numvaltxtqty5.Visible = True
        valtxtqty5.Visible = True
        numvaltxtprice5.Visible = True
        valtxtprice5.Visible = True
        ddlgl5.databind()
        txtprice5.Text = ""

        vallngthtxtlng5.Visible = True
        txtvenmat5.visible = True
        txttrackno5.visible = True

    End Sub

    Protected Sub BtnAdd5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd5.Click
        lbl60.Visible = True
        txtshrt6.Visible = True
        txtlng6.Visible = True
        txtqty6.Visible = True
        txtprice6.Visible = True
        ddluom6.Visible = True
        txttotal6.Visible = True
        ddltax6.Visible = True
        txtdate6.Visible = True
        BtnAdd5.Visible = False
        BtnAdd6.Visible = True
        BtnRem5.Visible = True
        BtnRem4.Visible = False
        ddlgl6.Visible = True
        valtxtshrt6.Visible = True
        'vallngthtxtlng6.Visible = True
        valddlgl6.Visible = True
        numvaltxtqty6.Visible = True
        valtxtqty6.Visible = True
        numvaltxtprice6.Visible = True
        valtxtprice6.Visible = True
        ddlgl6.databind()
        txtprice6.Text = ""

        vallngthtxtlng6.Visible = True
        txtvenmat6.visible = True
        txttrackno6.visible = True

    End Sub

    Protected Sub BtnAdd6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd6.Click
        lbl70.Visible = True
        txtshrt7.Visible = True
        txtlng7.Visible = True
        txtqty7.Visible = True
        txtprice7.Visible = True
        ddluom7.Visible = True
        txttotal7.Visible = True
        ddltax7.Visible = True
        txtdate7.Visible = True
        BtnAdd6.Visible = False
        BtnAdd7.Visible = True
        BtnRem6.Visible = True
        BtnRem5.Visible = False
        ddlgl7.Visible = True
        valtxtshrt7.Visible = True
        'vallngthtxtlng7.Visible = True
        valddlgl7.Visible = True
        numvaltxtqty7.Visible = True
        valtxtqty7.Visible = True
        numvaltxtprice7.Visible = True
        valtxtprice7.Visible = True
        ddlgl7.databind()
        txtprice7.Text = ""

        vallngthtxtlng7.Visible = True
        txtvenmat7.visible = True
        txttrackno7.visible = True

    End Sub

    Protected Sub BtnAdd7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd7.Click
        lbl80.Visible = True
        txtshrt8.Visible = True
        txtlng8.Visible = True
        txtqty8.Visible = True
        txtprice8.Visible = True
        ddluom8.Visible = True
        txttotal8.Visible = True
        ddltax8.Visible = True
        txtdate8.Visible = True
        BtnAdd7.Visible = False
        BtnAdd8.Visible = True
        BtnRem7.Visible = True
        BtnRem6.Visible = False
        ddlgl8.Visible = True
        valtxtshrt8.Visible = True
        'vallngthtxtlng8.Visible = True
        valddlgl8.Visible = True
        numvaltxtqty8.Visible = True
        valtxtqty8.Visible = True
        numvaltxtprice8.Visible = True
        valtxtprice8.Visible = True
        ddlgl8.databind()
        txtprice8.Text = ""

        vallngthtxtlng8.Visible = True
        txtvenmat8.visible = True
        txttrackno8.visible = True

    End Sub

    Protected Sub BtnAdd8_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd8.Click
        lbl90.Visible = True
        txtshrt9.Visible = True
        txtlng9.Visible = True
        txtqty9.Visible = True
        txtprice9.Visible = True
        ddluom9.Visible = True
        txttotal9.Visible = True
        ddltax9.Visible = True
        txtdate9.Visible = True
        BtnAdd8.Visible = False
        BtnAdd9.Visible = True
        BtnRem8.Visible = True
        BtnRem7.Visible = False
        ddlgl9.Visible = True
        valtxtshrt9.Visible = True
        'vallngthtxtlng9.Visible = True
        valddlgl9.Visible = True
        numvaltxtqty9.Visible = True
        valtxtqty9.Visible = True
        numvaltxtprice9.Visible = True
        valtxtprice9.Visible = True
        ddlgl9.databind()
        txtprice9.Text = ""

        vallngthtxtlng9.Visible = True
        txtvenmat9.visible = True
        txttrackno9.visible = True

    End Sub

    Protected Sub BtnAdd9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd9.Click
        lbl100.Visible = True
        txtshrt10.Visible = True
        txtlng10.Visible = True
        txtqty10.Visible = True
        txtprice10.Visible = True
        ddluom10.Visible = True
        txttotal10.Visible = True
        ddltax10.Visible = True
        txtdate10.Visible = True
        BtnAdd9.Visible = False
        BtnAdd10.Visible = True
        BtnRem9.Visible = True
        BtnRem8.Visible = False
        ddlgl10.Visible = True
        valtxtshrt10.Visible = True
        'vallngthtxtlng10.Visible = True
        valddlgl10.Visible = True
        numvaltxtqty10.Visible = True
        valtxtqty10.Visible = True
        numvaltxtprice10.Visible = True
        valtxtprice10.Visible = True
        ddlgl10.databind()
        txtprice10.Text = ""

        vallngthtxtlng10.Visible = True
        txtvenmat10.visible = True
        txttrackno10.visible = True

    End Sub

    Protected Sub BtnAdd10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd10.Click
        lbl110.Visible = True
        txtshrt11.Visible = True
        txtlng11.Visible = True
        txtqty11.Visible = True
        txtprice11.Visible = True
        ddluom11.Visible = True
        txttotal11.Visible = True
        ddltax11.Visible = True
        txtdate11.Visible = True
        BtnAdd10.Visible = False
        BtnAdd11.Visible = True
        BtnRem10.Visible = True
        BtnRem9.Visible = False
        ddlgl11.Visible = True
        valtxtshrt11.Visible = True
        'vallngthtxtlng11.Visible = True
        valddlgl11.Visible = True
        numvaltxtqty11.Visible = True
        valtxtqty11.Visible = True
        numvaltxtprice11.Visible = True
        valtxtprice11.Visible = True
        ddlgl11.databind()
        txtprice11.Text = ""

        vallngthtxtlng11.Visible = True
        txtvenmat11.visible = True
        txttrackno11.visible = True

    End Sub

    Protected Sub BtnAdd11_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd11.Click
        lbl120.Visible = True
        txtshrt12.Visible = True
        txtlng12.Visible = True
        txtqty12.Visible = True
        txtprice12.Visible = True
        ddluom12.Visible = True
        txttotal12.Visible = True
        ddltax12.Visible = True
        txtdate12.Visible = True
        BtnAdd11.Visible = False
        BtnAdd12.Visible = True
        BtnRem11.Visible = True
        BtnRem10.Visible = False
        ddlgl12.Visible = True
        valtxtshrt12.Visible = True
        'vallngthtxtlng12.Visible = True
        valddlgl12.Visible = True
        numvaltxtqty12.Visible = True
        valtxtqty12.Visible = True
        numvaltxtprice12.Visible = True
        valtxtprice12.Visible = True
        ddlgl12.databind()
        txtprice12.Text = ""

        vallngthtxtlng12.Visible = True
        txtvenmat12.visible = True
        txttrackno12.visible = True

    End Sub

    Protected Sub BtnAdd12_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd12.Click
        lbl130.Visible = True
        txtshrt13.Visible = True
        txtlng13.Visible = True
        txtqty13.Visible = True
        txtprice13.Visible = True
        ddluom13.Visible = True
        txttotal13.Visible = True
        ddltax13.Visible = True
        txtdate13.Visible = True
        BtnAdd12.Visible = False
        BtnAdd13.Visible = True
        BtnRem12.Visible = True
        BtnRem11.Visible = False
        ddlgl13.Visible = True
        valtxtshrt13.Visible = True
        'vallngthtxtlng13.Visible = True
        valddlgl13.Visible = True
        numvaltxtqty13.Visible = True
        valtxtqty13.Visible = True
        numvaltxtprice13.Visible = True
        valtxtprice13.Visible = True
        ddlgl13.databind()
        txtprice13.Text = ""

        vallngthtxtlng13.Visible = True
        txtvenmat13.visible = True
        txttrackno13.visible = True

    End Sub

    Protected Sub BtnAdd13_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd13.Click
        lbl140.Visible = True
        txtshrt14.Visible = True
        txtlng14.Visible = True
        txtqty14.Visible = True
        txtprice14.Visible = True
        ddluom14.Visible = True
        txttotal14.Visible = True
        ddltax14.Visible = True
        txtdate14.Visible = True
        BtnAdd13.Visible = False
        BtnAdd14.Visible = True
        BtnRem13.Visible = True
        BtnRem12.Visible = False
        ddlgl14.Visible = True
        valtxtshrt14.Visible = True
        'vallngthtxtlng14.Visible = True
        valddlgl14.Visible = True
        numvaltxtqty14.Visible = True
        valtxtqty14.Visible = True
        numvaltxtprice14.Visible = True
        valtxtprice14.Visible = True
        ddlgl14.databind()
        txtprice14.Text = ""

        vallngthtxtlng14.Visible = True
        txtvenmat14.visible = True
        txttrackno14.visible = True

    End Sub

    Protected Sub BtnAdd14_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd14.Click
        lbl150.Visible = True
        txtshrt15.Visible = True
        txtlng15.Visible = True
        txtqty15.Visible = True
        txtprice15.Visible = True
        ddluom15.Visible = True
        txttotal15.Visible = True
        ddltax15.Visible = True
        txtdate15.Visible = True
        BtnAdd14.Visible = False
        BtnAdd15.Visible = True
        BtnRem14.Visible = True
        BtnRem13.Visible = False
        ddlgl15.Visible = True
        valtxtshrt15.Visible = True
        'vallngthtxtlng15.Visible = True
        valddlgl15.Visible = True
        numvaltxtqty15.Visible = True
        valtxtqty15.Visible = True
        numvaltxtprice15.Visible = True
        valtxtprice15.Visible = True
        ddlgl15.databind()
        txtprice15.Text = ""

        vallngthtxtlng15.Visible = True
        txtvenmat15.visible = True
        txttrackno15.visible = True

    End Sub

    Protected Sub BtnAdd15_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd15.Click
        lbl160.Visible = True
        txtshrt16.Visible = True
        txtlng16.Visible = True
        txtqty16.Visible = True
        txtprice16.Visible = True
        ddluom16.Visible = True
        txttotal16.Visible = True
        ddltax16.Visible = True
        txtdate16.Visible = True
        BtnAdd15.Visible = False
        BtnAdd16.Visible = True
        BtnRem15.Visible = True
        BtnRem14.Visible = False
        ddlgl16.Visible = True
        valtxtshrt16.Visible = True
        'vallngthtxtlng16.Visible = True
        valddlgl16.Visible = True
        numvaltxtqty16.Visible = True
        valtxtqty16.Visible = True
        numvaltxtprice16.Visible = True
        valtxtprice16.Visible = True
        ddlgl16.databind()
        txtprice16.Text = ""

        vallngthtxtlng16.Visible = True
        txtvenmat16.visible = True
        txttrackno16.visible = True

    End Sub

    Protected Sub BtnAdd16_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd16.Click
        lbl170.Visible = True
        txtshrt17.Visible = True
        txtlng17.Visible = True
        txtqty17.Visible = True
        txtprice17.Visible = True
        ddluom17.Visible = True
        txttotal17.Visible = True
        ddltax17.Visible = True
        txtdate17.Visible = True
        BtnAdd16.Visible = False
        BtnAdd17.Visible = True
        BtnRem16.Visible = True
        BtnRem15.Visible = False
        ddlgl17.Visible = True
        valtxtshrt17.Visible = True
        'vallngthtxtlng17.Visible = True
        valddlgl17.Visible = True
        numvaltxtqty17.Visible = True
        valtxtqty17.Visible = True
        numvaltxtprice17.Visible = True
        valtxtprice17.Visible = True
        ddlgl17.databind()
        txtprice17.Text = ""

        vallngthtxtlng17.Visible = True
        txtvenmat17.visible = True
        txttrackno17.visible = True

    End Sub

    Protected Sub BtnAdd17_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd17.Click
        lbl180.Visible = True
        txtshrt18.Visible = True
        txtlng18.Visible = True
        txtqty18.Visible = True
        txtprice18.Visible = True
        ddluom18.Visible = True
        txttotal18.Visible = True
        ddltax18.Visible = True
        txtdate18.Visible = True
        BtnAdd17.Visible = False
        BtnAdd18.Visible = True
        BtnRem17.Visible = True
        BtnRem16.Visible = False
        ddlgl18.Visible = True
        valtxtshrt18.Visible = True
        'vallngthtxtlng18.Visible = True
        valddlgl18.Visible = True
        numvaltxtqty18.Visible = True
        valtxtqty18.Visible = True
        numvaltxtprice18.Visible = True
        valtxtprice18.Visible = True
        ddlgl18.databind()
        txtprice18.Text = ""

        vallngthtxtlng18.Visible = True
        txtvenmat18.visible = True
        txttrackno18.visible = True

    End Sub

    Protected Sub BtnAdd18_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd18.Click
        lbl190.Visible = True
        txtshrt19.Visible = True
        txtlng19.Visible = True
        txtqty19.Visible = True
        txtprice19.Visible = True
        ddluom19.Visible = True
        txttotal19.Visible = True
        ddltax19.Visible = True
        txtdate19.Visible = True
        BtnAdd18.Visible = False
        BtnAdd19.Visible = True
        BtnRem18.Visible = True
        BtnRem17.Visible = False
        ddlgl19.Visible = True
        valtxtshrt19.Visible = True
        'vallngthtxtlng19.Visible = True
        valddlgl19.Visible = True
        numvaltxtqty19.Visible = True
        valtxtqty19.Visible = True
        numvaltxtprice19.Visible = True
        valtxtprice19.Visible = True
        ddlgl19.databind()
        txtprice19.Text = ""

        vallngthtxtlng19.Visible = True
        txtvenmat19.visible = True
        txttrackno19.visible = True

    End Sub

    Protected Sub BtnAdd19_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd19.Click
        lbl200.Visible = True
        txtshrt20.Visible = True
        txtlng20.Visible = True
        txtqty20.Visible = True
        txtprice20.Visible = True
        ddluom20.Visible = True
        txttotal20.Visible = True
        ddltax20.Visible = True
        txtdate20.Visible = True
        BtnAdd19.Visible = False
        BtnAdd20.Visible = True
        BtnRem19.Visible = True
        BtnRem18.Visible = False
        ddlgl20.Visible = True
        valtxtshrt20.Visible = True
        'vallngthtxtlng20.Visible = True
        valddlgl20.Visible = True
        numvaltxtqty20.Visible = True
        valtxtqty20.Visible = True
        numvaltxtprice20.Visible = True
        valtxtprice20.Visible = True
        ddlgl20.databind()
        txtprice20.Text = ""

        vallngthtxtlng20.Visible = True
        txtvenmat20.visible = True
        txttrackno20.visible = True

    End Sub

    Protected Sub BtnAdd20_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd20.Click
        lbl210.Visible = True
        txtshrt21.Visible = True
        txtlng21.Visible = True
        txtqty21.Visible = True
        txtprice21.Visible = True
        ddluom21.Visible = True
        txttotal21.Visible = True
        ddltax21.Visible = True
        txtdate21.Visible = True
        BtnAdd20.Visible = False
        BtnAdd21.Visible = True
        BtnRem20.Visible = True
        BtnRem19.Visible = False
        ddlgl21.Visible = True
        valtxtshrt21.Visible = True
        'vallngthtxtlng21.Visible = True
        valddlgl21.Visible = True
        numvaltxtqty21.Visible = True
        valtxtqty21.Visible = True
        numvaltxtprice21.Visible = True
        valtxtprice21.Visible = True
        ddlgl21.databind()
        txtprice21.Text = ""

        vallngthtxtlng21.Visible = True
        txtvenmat21.visible = True
        txttrackno21.visible = True

    End Sub

    Protected Sub BtnAdd21_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd21.Click
        lbl220.Visible = True
        txtshrt22.Visible = True
        txtlng22.Visible = True
        txtqty22.Visible = True
        txtprice22.Visible = True
        ddluom22.Visible = True
        txttotal22.Visible = True
        ddltax22.Visible = True
        txtdate22.Visible = True
        BtnAdd21.Visible = False
        BtnAdd22.Visible = True
        BtnRem21.Visible = True
        BtnRem20.Visible = False
        ddlgl22.Visible = True
        valtxtshrt22.Visible = True
        'vallngthtxtlng22.Visible = True
        valddlgl22.Visible = True
        numvaltxtqty22.Visible = True
        valtxtqty22.Visible = True
        numvaltxtprice22.Visible = True
        valtxtprice22.Visible = True
        ddlgl22.databind()
        txtprice22.Text = ""

        vallngthtxtlng22.Visible = True
        txtvenmat22.visible = True
        txttrackno22.visible = True

    End Sub

    Protected Sub BtnAdd22_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd22.Click
        lbl230.Visible = True
        txtshrt23.Visible = True
        txtlng23.Visible = True
        txtqty23.Visible = True
        txtprice23.Visible = True
        ddluom23.Visible = True
        txttotal23.Visible = True
        ddltax23.Visible = True
        txtdate23.Visible = True
        BtnAdd22.Visible = False
        BtnAdd23.Visible = True
        BtnRem22.Visible = True
        BtnRem21.Visible = False
        ddlgl23.Visible = True
        valtxtshrt23.Visible = True
        'vallngthtxtlng23.Visible = True
        valddlgl23.Visible = True
        numvaltxtqty23.Visible = True
        valtxtqty23.Visible = True
        numvaltxtprice23.Visible = True
        valtxtprice23.Visible = True
        ddlgl23.databind()
        txtprice23.Text = ""

        vallngthtxtlng23.Visible = True
        txtvenmat23.visible = True
        txttrackno23.visible = True

    End Sub

    Protected Sub BtnAdd23_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd23.Click
        lbl240.Visible = True
        txtshrt24.Visible = True
        txtlng24.Visible = True
        txtqty24.Visible = True
        txtprice24.Visible = True
        ddluom24.Visible = True
        txttotal24.Visible = True
        ddltax24.Visible = True
        txtdate24.Visible = True
        BtnAdd23.Visible = False
        BtnAdd24.Visible = True
        BtnRem23.Visible = True
        BtnRem22.Visible = False
        ddlgl24.Visible = True
        valtxtshrt24.Visible = True
        'vallngthtxtlng24.Visible = True
        valddlgl24.Visible = True
        numvaltxtqty24.Visible = True
        valtxtqty24.Visible = True
        numvaltxtprice24.Visible = True
        valtxtprice24.Visible = True
        ddlgl24.databind()
        txtprice24.Text = ""

        vallngthtxtlng24.Visible = True
        txtvenmat24.visible = True
        txttrackno24.visible = True

    End Sub

    Protected Sub BtnAdd24_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd24.Click
        lbl250.Visible = True
        txtshrt25.Visible = True
        txtlng25.Visible = True
        txtqty25.Visible = True
        txtprice25.Visible = True
        ddluom25.Visible = True
        txttotal25.Visible = True
        ddltax25.Visible = True
        txtdate25.Visible = True
        BtnAdd24.Visible = False
        BtnAdd25.Visible = True
        BtnRem24.Visible = True
        BtnRem23.Visible = False
        ddlgl25.Visible = True
        valtxtshrt25.Visible = True
        'vallngthtxtlng25.Visible = True
        valddlgl25.Visible = True
        numvaltxtqty25.Visible = True
        valtxtqty25.Visible = True
        numvaltxtprice25.Visible = True
        valtxtprice25.Visible = True
        ddlgl25.databind()
        txtprice25.Text = ""

        vallngthtxtlng25.Visible = True
        txtvenmat25.visible = True
        txttrackno25.visible = True

    End Sub

    Protected Sub BtnAdd25_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd25.Click
        lbl260.Visible = True
        txtshrt26.Visible = True
        txtlng26.Visible = True
        txtqty26.Visible = True
        txtprice26.Visible = True
        ddluom26.Visible = True
        txttotal26.Visible = True
        ddltax26.Visible = True
        txtdate26.Visible = True
        BtnAdd25.Visible = False
        BtnAdd26.Visible = True
        BtnRem25.Visible = True
        BtnRem24.Visible = False
        ddlgl26.Visible = True
        valtxtshrt26.Visible = True
        'vallngthtxtlng26.Visible = True
        valddlgl26.Visible = True
        numvaltxtqty26.Visible = True
        valtxtqty26.Visible = True
        numvaltxtprice26.Visible = True
        valtxtprice26.Visible = True
        ddlgl26.databind()
        txtprice26.Text = ""

        vallngthtxtlng26.Visible = True
        txtvenmat26.visible = True
        txttrackno26.visible = True

    End Sub

    Protected Sub BtnAdd26_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd26.Click
        lbl270.Visible = True
        txtshrt27.Visible = True
        txtlng27.Visible = True
        txtqty27.Visible = True
        txtprice27.Visible = True
        ddluom27.Visible = True
        txttotal27.Visible = True
        ddltax27.Visible = True
        txtdate27.Visible = True
        BtnAdd26.Visible = False
        BtnAdd27.Visible = True
        BtnRem26.Visible = True
        BtnRem25.Visible = False
        ddlgl27.Visible = True
        valtxtshrt27.Visible = True
        'vallngthtxtlng27.Visible = True
        valddlgl27.Visible = True
        numvaltxtqty27.Visible = True
        valtxtqty27.Visible = True
        numvaltxtprice27.Visible = True
        valtxtprice27.Visible = True
        ddlgl27.databind()
        txtprice27.Text = ""

        vallngthtxtlng27.Visible = True
        txtvenmat27.visible = True
        txttrackno27.visible = True

    End Sub

    Protected Sub BtnAdd27_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd27.Click
        lbl280.Visible = True
        txtshrt28.Visible = True
        txtlng28.Visible = True
        txtqty28.Visible = True
        txtprice28.Visible = True
        ddluom28.Visible = True
        txttotal28.Visible = True
        ddltax28.Visible = True
        txtdate28.Visible = True
        BtnAdd27.Visible = False
        BtnAdd28.Visible = True
        BtnRem27.Visible = True
        BtnRem26.Visible = False
        ddlgl28.Visible = True
        valtxtshrt28.Visible = True
        'vallngthtxtlng28.Visible = True
        valddlgl28.Visible = True
        numvaltxtqty28.Visible = True
        valtxtqty28.Visible = True
        numvaltxtprice28.Visible = True
        valtxtprice28.Visible = True
        ddlgl28.databind()
        txtprice28.Text = ""

        vallngthtxtlng28.Visible = True
        txtvenmat28.visible = True
        txttrackno28.visible = True

    End Sub

    Protected Sub BtnAdd28_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd28.Click
        lbl290.Visible = True
        txtshrt29.Visible = True
        txtlng29.Visible = True
        txtqty29.Visible = True
        txtprice29.Visible = True
        ddluom29.Visible = True
        txttotal29.Visible = True
        ddltax29.Visible = True
        txtdate29.Visible = True
        BtnAdd28.Visible = False
        BtnAdd29.Visible = True
        BtnRem28.Visible = True
        BtnRem27.Visible = False
        ddlgl29.Visible = True
        valtxtshrt29.Visible = True
        'vallngthtxtlng29.Visible = True
        valddlgl29.Visible = True
        numvaltxtqty29.Visible = True
        valtxtqty29.Visible = True
        numvaltxtprice29.Visible = True
        valtxtprice29.Visible = True
        ddlgl29.databind()
        txtprice29.Text = ""

        vallngthtxtlng29.Visible = True
        txtvenmat29.visible = True
        txttrackno29.visible = True


    End Sub

    Protected Sub BtnAdd29_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAdd29.Click
        lbl300.Visible = True
        txtshrt30.Visible = True
        txtlng30.Visible = True
        txtqty30.Visible = True
        txtprice30.Visible = True
        ddluom30.Visible = True
        txttotal30.Visible = True
        ddltax30.Visible = True
        txtdate30.Visible = True
        BtnAdd29.Visible = False
        BtnRem29.Visible = True
        BtnRem28.Visible = False
        ddlgl30.Visible = True
        valtxtshrt30.Visible = True
        'vallngthtxtlng30.Visible = True
        valddlgl30.Visible = True
        numvaltxtqty30.Visible = True
        valtxtqty30.Visible = True
        numvaltxtprice30.Visible = True
        valtxtprice30.Visible = True
        ddlgl30.databind()
        txtprice30.Text = ""

        vallngthtxtlng30.Visible = True
        txtvenmat30.visible = True
        txttrackno30.visible = True


    End Sub

    Protected Sub BtnRem1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem1.Click

        lbl20.Visible = False
        txtshrt2.Visible = False
        txtlng2.Visible = False
        txtqty2.Visible = False
        txtprice2.Visible = False
        ddluom2.Visible = False
        txttotal2.Visible = False
        ddltax2.Visible = False
        txtdate2.Visible = False
        BtnAdd2.Visible = False
        BtnAdd1.Visible = True
        BtnRem1.Visible = False
        ddlgl2.Visible = False
        valtxtshrt2.Visible = False
        'vallngthtxtlng2.Visible = False
        valddlgl2.Visible = False
        numvaltxtqty2.Visible = False
        valtxtqty2.Visible = False
        numvaltxtprice2.Visible = False
        valtxtprice2.Visible = False
        ddlgl2.Items.Remove("---Select Account---")
        txtprice2.Text = "0"

        vallngthtxtlng2.Visible = False
        txtvenmat2.visible = False
        txttrackno2.visible = False


    End Sub

    Protected Sub BtnRem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem2.Click
        lbl30.Visible = False
        txtshrt3.Visible = False
        txtlng3.Visible = False
        txtqty3.Visible = False
        txtprice3.Visible = False
        ddluom3.Visible = False
        txttotal3.Visible = False
        ddltax3.Visible = False
        txtdate3.Visible = False
        BtnAdd2.Visible = True
        BtnAdd3.Visible = False
        BtnRem1.Visible = True
        BtnRem2.Visible = False
        ddlgl3.Visible = False
        valtxtshrt3.Visible = False
        'vallngthtxtlng3.Visible = False
        valddlgl3.Visible = False
        numvaltxtqty3.Visible = False
        valtxtqty3.Visible = False
        numvaltxtprice3.Visible = False
        valtxtprice3.Visible = False
        ddlgl3.Items.Remove("---Select Account---")
        txtprice3.Text = "0"

        vallngthtxtlng3.Visible = False
        txtvenmat3.visible = False
        txttrackno3.visible = False


    End Sub
    Protected Sub BtnRem3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem3.Click
        lbl40.Visible = False
        txtshrt4.Visible = False
        txtlng4.Visible = False
        txtqty4.Visible = False
        txtprice4.Visible = False
        ddluom4.Visible = False
        txttotal4.Visible = False
        ddltax4.Visible = False
        txtdate4.Visible = False
        BtnAdd3.Visible = True
        BtnAdd4.Visible = False
        BtnRem2.Visible = True
        BtnRem3.Visible = False
        ddlgl4.Visible = False
        valtxtshrt4.Visible = False
        'vallngthtxtlng4.Visible = False
        valddlgl4.Visible = False
        numvaltxtqty4.Visible = False
        valtxtqty4.Visible = False
        numvaltxtprice4.Visible = False
        valtxtprice4.Visible = False
        ddlgl4.Items.Remove("---Select Account---")
        txtprice4.Text = "0"

        vallngthtxtlng4.Visible = False
        txtvenmat4.visible = False
        txttrackno4.visible = False


    End Sub
    Protected Sub BtnRem4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem4.Click
        lbl50.Visible = False
        txtshrt5.Visible = False
        txtlng5.Visible = False
        txtqty5.Visible = False
        txtprice5.Visible = False
        ddluom5.Visible = False
        txttotal5.Visible = False
        ddltax5.Visible = False
        txtdate5.Visible = False
        BtnAdd4.Visible = True
        BtnAdd5.Visible = False
        BtnRem3.Visible = True
        BtnRem4.Visible = False
        ddlgl5.Visible = False
        valtxtshrt5.Visible = False
        'vallngthtxtlng5.Visible = False
        valddlgl5.Visible = False
        numvaltxtqty5.Visible = False
        valtxtqty5.Visible = False
        numvaltxtprice5.Visible = False
        valtxtprice5.Visible = False
        ddlgl5.Items.Remove("---Select Account---")
        txtprice5.Text = "0"

        vallngthtxtlng5.Visible = False
        txtvenmat5.visible = False
        txttrackno5.visible = False


    End Sub

    Protected Sub BtnRem5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem5.Click
        lbl60.Visible = False
        txtshrt6.Visible = False
        txtlng6.Visible = False
        txtqty6.Visible = False
        txtprice6.Visible = False
        ddluom6.Visible = False
        txttotal6.Visible = False
        ddltax6.Visible = False
        txtdate6.Visible = False
        BtnAdd5.Visible = True
        BtnAdd6.Visible = False
        BtnRem4.Visible = True
        BtnRem5.Visible = False
        ddlgl6.Visible = False
        valtxtshrt6.Visible = False
        'vallngthtxtlng6.Visible = False
        valddlgl6.Visible = False
        numvaltxtqty6.Visible = False
        valtxtqty6.Visible = False
        numvaltxtprice6.Visible = False
        valtxtprice6.Visible = False
        ddlgl6.Items.Remove("---Select Account---")
        txtprice6.Text = "0"

        vallngthtxtlng6.Visible = False
        txtvenmat6.visible = False
        txttrackno6.visible = False

    End Sub

    Protected Sub BtnRem6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem6.Click
        lbl70.Visible = False
        txtshrt7.Visible = False
        txtlng7.Visible = False
        txtqty7.Visible = False
        txtprice7.Visible = False
        ddluom7.Visible = False
        txttotal7.Visible = False
        ddltax7.Visible = False
        txtdate7.Visible = False
        BtnAdd6.Visible = True
        BtnAdd7.Visible = False
        BtnRem5.Visible = True
        BtnRem6.Visible = False
        ddlgl7.Visible = False
        valtxtshrt7.Visible = False
        'vallngthtxtlng7.Visible = False
        valddlgl7.Visible = False
        numvaltxtqty7.Visible = False
        valtxtqty7.Visible = False
        numvaltxtprice7.Visible = False
        valtxtprice7.Visible = False
        ddlgl7.Items.Remove("---Select Account---")
        txtprice7.Text = "0"

        vallngthtxtlng7.Visible = False
        txtvenmat7.visible = False
        txttrackno7.visible = False

    End Sub

    Protected Sub BtnRem7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem7.Click
        lbl80.Visible = False
        txtshrt8.Visible = False
        txtlng8.Visible = False
        txtqty8.Visible = False
        txtprice8.Visible = False
        ddluom8.Visible = False
        txttotal8.Visible = False
        ddltax8.Visible = False
        txtdate8.Visible = False
        BtnAdd7.Visible = True
        BtnAdd8.Visible = False
        BtnRem6.Visible = True
        BtnRem7.Visible = False
        ddlgl8.Visible = False
        valtxtshrt8.Visible = False
        'vallngthtxtlng8.Visible = False
        valddlgl8.Visible = False
        numvaltxtqty8.Visible = False
        valtxtqty8.Visible = False
        numvaltxtprice8.Visible = False
        valtxtprice8.Visible = False
        ddlgl8.Items.Remove("---Select Account---")
        txtprice8.Text = "0"

        vallngthtxtlng8.Visible = False
        txtvenmat8.visible = False
        txttrackno8.visible = False

    End Sub

    Protected Sub BtnRem8_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem8.Click
        lbl90.Visible = False
        txtshrt9.Visible = False
        txtlng9.Visible = False
        txtqty9.Visible = False
        txtprice9.Visible = False
        ddluom9.Visible = False
        txttotal9.Visible = False
        ddltax9.Visible = False
        txtdate9.Visible = False
        BtnAdd8.Visible = True
        BtnAdd9.Visible = False
        BtnRem7.Visible = True
        BtnRem8.Visible = False
        ddlgl9.Visible = False
        valtxtshrt9.Visible = False
        'vallngthtxtlng9.Visible = False
        valddlgl9.Visible = False
        numvaltxtqty9.Visible = False
        valtxtqty9.Visible = False
        numvaltxtprice9.Visible = False
        valtxtprice9.Visible = False
        ddlgl9.Items.Remove("---Select Account---")
        txtprice9.Text = "0"

        vallngthtxtlng9.Visible = False
        txtvenmat9.visible = False
        txttrackno9.visible = False

    End Sub

    Protected Sub BtnRem9_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem9.Click
        lbl100.Visible = False
        txtshrt10.Visible = False
        txtlng10.Visible = False
        txtqty10.Visible = False
        txtprice10.Visible = False
        ddluom10.Visible = False
        txttotal10.Visible = False
        ddltax10.Visible = False
        txtdate10.Visible = False
        BtnAdd9.Visible = True
        BtnAdd10.Visible = False
        BtnRem8.Visible = True
        BtnRem9.Visible = False
        ddlgl10.Visible = False
        valtxtshrt10.Visible = False
        'vallngthtxtlng10.Visible = False
        valddlgl10.Visible = False
        numvaltxtqty10.Visible = False
        valtxtqty10.Visible = False
        numvaltxtprice10.Visible = False
        valtxtprice10.Visible = False
        ddlgl10.Items.Remove("---Select Account---")
        txtprice10.Text = "0"

        vallngthtxtlng10.Visible = False
        txtvenmat10.visible = False
        txttrackno10.visible = False

    End Sub

    Protected Sub BtnRem10_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem10.Click
        lbl110.Visible = False
        txtshrt11.Visible = False
        txtlng11.Visible = False
        txtqty11.Visible = False
        txtprice11.Visible = False
        ddluom11.Visible = False
        txttotal11.Visible = False
        ddltax11.Visible = False
        txtdate11.Visible = False
        BtnAdd10.Visible = True
        BtnAdd11.Visible = False
        BtnRem9.Visible = True
        BtnRem10.Visible = False
        ddlgl11.Visible = False
        valtxtshrt11.Visible = False
        'vallngthtxtlng11.Visible = False
        valddlgl11.Visible = False
        numvaltxtqty11.Visible = False
        valtxtqty11.Visible = False
        numvaltxtprice11.Visible = False
        valtxtprice11.Visible = False
        ddlgl11.Items.Remove("---Select Account---")
        txtprice11.Text = "0"

        vallngthtxtlng11.Visible = False
        txtvenmat11.visible = False
        txttrackno11.visible = False

    End Sub

    Protected Sub BtnRem11_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem11.Click
        lbl120.Visible = False
        txtshrt12.Visible = False
        txtlng12.Visible = False
        txtqty12.Visible = False
        txtprice12.Visible = False
        ddluom12.Visible = False
        txttotal12.Visible = False
        ddltax12.Visible = False
        txtdate12.Visible = False
        BtnAdd11.Visible = True
        BtnAdd12.Visible = False
        BtnRem10.Visible = True
        BtnRem11.Visible = False
        ddlgl12.Visible = False
        valtxtshrt12.Visible = False
        'vallngthtxtlng12.Visible = False
        valddlgl12.Visible = False
        numvaltxtqty12.Visible = False
        valtxtqty12.Visible = False
        numvaltxtprice12.Visible = False
        valtxtprice12.Visible = False
        ddlgl12.Items.Remove("---Select Account---")
        txtprice12.Text = "0"

        vallngthtxtlng12.Visible = False
        txtvenmat12.visible = False
        txttrackno12.visible = False

    End Sub

    Protected Sub BtnRem12_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem12.Click
        lbl130.Visible = False
        txtshrt13.Visible = False
        txtlng13.Visible = False
        txtqty13.Visible = False
        txtprice13.Visible = False
        ddluom13.Visible = False
        txttotal13.Visible = False
        ddltax13.Visible = False
        txtdate13.Visible = False
        BtnAdd12.Visible = True
        BtnAdd13.Visible = False
        BtnRem11.Visible = True
        BtnRem12.Visible = False
        ddlgl13.Visible = False
        valtxtshrt13.Visible = False
        'vallngthtxtlng13.Visible = False
        valddlgl13.Visible = False
        numvaltxtqty13.Visible = False
        valtxtqty13.Visible = False
        numvaltxtprice13.Visible = False
        valtxtprice13.Visible = False
        ddlgl13.Items.Remove("---Select Account---")
        txtprice13.Text = "0"

        vallngthtxtlng13.Visible = False
        txtvenmat13.visible = False
        txttrackno13.visible = False

    End Sub

    Protected Sub BtnRem13_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem13.Click
        lbl140.Visible = False
        txtshrt14.Visible = False
        txtlng14.Visible = False
        txtqty14.Visible = False
        txtprice14.Visible = False
        ddluom14.Visible = False
        txttotal14.Visible = False
        ddltax14.Visible = False
        txtdate14.Visible = False
        BtnAdd13.Visible = True
        BtnAdd14.Visible = False
        BtnRem12.Visible = True
        BtnRem13.Visible = False
        ddlgl14.Visible = False
        valtxtshrt14.Visible = False
        'vallngthtxtlng14.Visible = False
        valddlgl14.Visible = False
        numvaltxtqty14.Visible = False
        valtxtqty14.Visible = False
        numvaltxtprice14.Visible = False
        valtxtprice14.Visible = False
        ddlgl14.Items.Remove("---Select Account---")
        txtprice14.Text = "0"

        vallngthtxtlng14.Visible = False
        txtvenmat14.visible = False
        txttrackno14.visible = False

    End Sub

    Protected Sub BtnRem14_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem14.Click
        lbl150.Visible = False
        txtshrt15.Visible = False
        txtlng15.Visible = False
        txtqty15.Visible = False
        txtprice15.Visible = False
        ddluom15.Visible = False
        txttotal15.Visible = False
        ddltax15.Visible = False
        txtdate15.Visible = False
        BtnAdd14.Visible = True
        BtnAdd15.Visible = False
        BtnRem13.Visible = True
        BtnRem14.Visible = False
        ddlgl15.Visible = False
        valtxtshrt15.Visible = False
        'vallngthtxtlng15.Visible = False
        valddlgl15.Visible = False
        numvaltxtqty15.Visible = False
        valtxtqty15.Visible = False
        numvaltxtprice15.Visible = False
        valtxtprice15.Visible = False
        ddlgl15.Items.Remove("---Select Account---")
        txtprice15.Text = "0"

        vallngthtxtlng15.Visible = False
        txtvenmat15.visible = False
        txttrackno15.visible = False

    End Sub

    Protected Sub BtnRem15_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem15.Click
        lbl160.Visible = False
        txtshrt16.Visible = False
        txtlng16.Visible = False
        txtqty16.Visible = False
        txtprice16.Visible = False
        ddluom16.Visible = False
        txttotal16.Visible = False
        ddltax16.Visible = False
        txtdate16.Visible = False
        BtnAdd15.Visible = True
        BtnAdd16.Visible = False
        BtnRem14.Visible = True
        BtnRem15.Visible = False
        ddlgl16.Visible = False
        valtxtshrt16.Visible = False
        'vallngthtxtlng16.Visible = False
        valddlgl16.Visible = False
        numvaltxtqty16.Visible = False
        valtxtqty16.Visible = False
        numvaltxtprice16.Visible = False
        valtxtprice16.Visible = False
        ddlgl16.Items.Remove("---Select Account---")
        txtprice16.Text = "0"

        vallngthtxtlng16.Visible = False
        txtvenmat16.visible = False
        txttrackno16.visible = False

    End Sub

    Protected Sub BtnRem16_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem16.Click
        lbl170.Visible = False
        txtshrt17.Visible = False
        txtlng17.Visible = False
        txtqty17.Visible = False
        txtprice17.Visible = False
        ddluom17.Visible = False
        txttotal17.Visible = False
        ddltax17.Visible = False
        txtdate17.Visible = False
        BtnAdd16.Visible = True
        BtnAdd17.Visible = False
        BtnRem15.Visible = True
        BtnRem16.Visible = False
        ddlgl17.Visible = False
        valtxtshrt17.Visible = False
        'vallngthtxtlng17.Visible = False
        valddlgl17.Visible = False
        numvaltxtqty17.Visible = False
        valtxtqty17.Visible = False
        numvaltxtprice17.Visible = False
        valtxtprice17.Visible = False
        ddlgl17.Items.Remove("---Select Account---")
        txtprice17.Text = "0"

        vallngthtxtlng17.Visible = False
        txtvenmat17.visible = False
        txttrackno17.visible = False

    End Sub

    Protected Sub BtnRem17_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem17.Click
        lbl180.Visible = False
        txtshrt18.Visible = False
        txtlng18.Visible = False
        txtqty18.Visible = False
        txtprice18.Visible = False
        ddluom18.Visible = False
        txttotal18.Visible = False
        ddltax18.Visible = False
        txtdate18.Visible = False
        BtnAdd17.Visible = True
        BtnAdd18.Visible = False
        BtnRem16.Visible = True
        BtnRem17.Visible = False
        ddlgl18.Visible = False
        valtxtshrt18.Visible = False
        'vallngthtxtlng18.Visible = False
        valddlgl18.Visible = False
        numvaltxtqty18.Visible = False
        valtxtqty18.Visible = False
        numvaltxtprice18.Visible = False
        valtxtprice18.Visible = False
        ddlgl18.Items.Remove("---Select Account---")
        txtprice18.Text = "0"

        vallngthtxtlng18.Visible = False
        txtvenmat18.visible = False
        txttrackno18.visible = False

    End Sub

    Protected Sub BtnRem18_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem18.Click
        lbl190.Visible = False
        txtshrt19.Visible = False
        txtlng19.Visible = False
        txtqty19.Visible = False
        txtprice19.Visible = False
        ddluom19.Visible = False
        txttotal19.Visible = False
        ddltax19.Visible = False
        txtdate19.Visible = False
        BtnAdd18.Visible = True
        BtnAdd19.Visible = False
        BtnRem17.Visible = True
        BtnRem18.Visible = False
        ddlgl19.Visible = False
        valtxtshrt19.Visible = False
        'vallngthtxtlng19.Visible = False
        valddlgl19.Visible = False
        numvaltxtqty19.Visible = False
        valtxtqty19.Visible = False
        numvaltxtprice19.Visible = False
        valtxtprice19.Visible = False
        ddlgl19.Items.Remove("---Select Account---")
        txtprice19.Text = "0"

        vallngthtxtlng19.Visible = False
        txtvenmat19.visible = False
        txttrackno19.visible = False

    End Sub

    Protected Sub BtnRem19_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem19.Click
        lbl200.Visible = False
        txtshrt20.Visible = False
        txtlng20.Visible = False
        txtqty20.Visible = False
        txtprice20.Visible = False
        ddluom20.Visible = False
        txttotal20.Visible = False
        ddltax20.Visible = False
        txtdate20.Visible = False
        BtnAdd19.Visible = True
        BtnAdd20.Visible = False
        BtnRem18.Visible = True
        BtnRem19.Visible = False
        ddlgl20.Visible = False
        valtxtshrt20.Visible = False
        'vallngthtxtlng20.Visible = False
        valddlgl20.Visible = False
        numvaltxtqty20.Visible = False
        valtxtqty20.Visible = False
        numvaltxtprice20.Visible = False
        valtxtprice20.Visible = False
        ddlgl20.Items.Remove("---Select Account---")
        txtprice20.Text = "0"

        vallngthtxtlng20.Visible = False
        txtvenmat20.visible = False
        txttrackno20.visible = False

    End Sub

    Protected Sub BtnRem20_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem20.Click
        lbl210.Visible = False
        txtshrt21.Visible = False
        txtlng21.Visible = False
        txtqty21.Visible = False
        txtprice21.Visible = False
        ddluom21.Visible = False
        txttotal21.Visible = False
        ddltax21.Visible = False
        txtdate21.Visible = False
        BtnAdd20.Visible = True
        BtnAdd21.Visible = False
        BtnRem19.Visible = True
        BtnRem20.Visible = False
        ddlgl21.Visible = False
        valtxtshrt21.Visible = False
        'vallngthtxtlng21.Visible = False
        valddlgl21.Visible = False
        numvaltxtqty21.Visible = False
        valtxtqty21.Visible = False
        numvaltxtprice21.Visible = False
        valtxtprice21.Visible = False
        ddlgl21.Items.Remove("---Select Account---")
        txtprice21.Text = "0"

        vallngthtxtlng21.Visible = False
        txtvenmat21.visible = False
        txttrackno21.visible = False

    End Sub

    Protected Sub BtnRem21_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem21.Click
        lbl220.Visible = False
        txtshrt22.Visible = False
        txtlng22.Visible = False
        txtqty22.Visible = False
        txtprice22.Visible = False
        ddluom22.Visible = False
        txttotal22.Visible = False
        ddltax22.Visible = False
        txtdate22.Visible = False
        BtnAdd21.Visible = True
        BtnAdd22.Visible = False
        BtnRem20.Visible = True
        BtnRem21.Visible = False
        ddlgl22.Visible = False
        valtxtshrt22.Visible = False
        'vallngthtxtlng22.Visible = False
        valddlgl22.Visible = False
        numvaltxtqty22.Visible = False
        valtxtqty22.Visible = False
        numvaltxtprice22.Visible = False
        valtxtprice22.Visible = False
        ddlgl22.Items.Remove("---Select Account---")
        txtprice22.Text = "0"

        vallngthtxtlng22.Visible = False
        txtvenmat22.visible = False
        txttrackno22.visible = False

    End Sub

    Protected Sub BtnRem22_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem22.Click
        lbl230.Visible = False
        txtshrt23.Visible = False
        txtlng23.Visible = False
        txtqty23.Visible = False
        txtprice23.Visible = False
        ddluom23.Visible = False
        txttotal23.Visible = False
        ddltax23.Visible = False
        txtdate23.Visible = False
        BtnAdd22.Visible = True
        BtnAdd23.Visible = False
        BtnRem21.Visible = True
        BtnRem22.Visible = False
        ddlgl23.Visible = False
        valtxtshrt23.Visible = False
        'vallngthtxtlng23.Visible = False
        valddlgl23.Visible = False
        numvaltxtqty23.Visible = False
        valtxtqty23.Visible = False
        numvaltxtprice23.Visible = False
        valtxtprice23.Visible = False
        ddlgl23.Items.Remove("---Select Account---")
        txtprice23.Text = "0"

        vallngthtxtlng23.Visible = False
        txtvenmat23.visible = False
        txttrackno23.visible = False

    End Sub

    Protected Sub BtnRem23_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem23.Click
        lbl240.Visible = False
        txtshrt24.Visible = False
        txtlng24.Visible = False
        txtqty24.Visible = False
        txtprice24.Visible = False
        ddluom24.Visible = False
        txttotal24.Visible = False
        ddltax24.Visible = False
        txtdate24.Visible = False
        BtnAdd23.Visible = True
        BtnAdd24.Visible = False
        BtnRem22.Visible = True
        BtnRem23.Visible = False
        ddlgl24.Visible = False
        valtxtshrt24.Visible = False
        'vallngthtxtlng24.Visible = False
        valddlgl24.Visible = False
        numvaltxtqty24.Visible = False
        valtxtqty24.Visible = False
        numvaltxtprice24.Visible = False
        valtxtprice24.Visible = False
        ddlgl24.Items.Remove("---Select Account---")
        txtprice24.Text = "0"

        vallngthtxtlng24.Visible = False
        txtvenmat24.visible = False
        txttrackno24.visible = False

    End Sub

    Protected Sub BtnRem24_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem24.Click
        lbl250.Visible = False
        txtshrt25.Visible = False
        txtlng25.Visible = False
        txtqty25.Visible = False
        txtprice25.Visible = False
        ddluom25.Visible = False
        txttotal25.Visible = False
        ddltax25.Visible = False
        txtdate25.Visible = False
        BtnAdd24.Visible = True
        BtnAdd25.Visible = False
        BtnRem23.Visible = True
        BtnRem24.Visible = False
        ddlgl25.Visible = False
        valtxtshrt25.Visible = False
        'vallngthtxtlng25.Visible = False
        valddlgl25.Visible = False
        numvaltxtqty25.Visible = False
        valtxtqty25.Visible = False
        numvaltxtprice25.Visible = False
        valtxtprice25.Visible = False
        ddlgl25.Items.Remove("---Select Account---")
        txtprice25.Text = "0"

        vallngthtxtlng25.Visible = False
        txtvenmat25.visible = False
        txttrackno25.visible = False

    End Sub

    Protected Sub BtnRem25_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem25.Click
        lbl260.Visible = False
        txtshrt26.Visible = False
        txtlng26.Visible = False
        txtqty26.Visible = False
        txtprice26.Visible = False
        ddluom26.Visible = False
        txttotal26.Visible = False
        ddltax26.Visible = False
        txtdate26.Visible = False
        BtnAdd25.Visible = True
        BtnAdd26.Visible = False
        BtnRem24.Visible = True
        BtnRem25.Visible = False
        ddlgl26.Visible = False
        valtxtshrt26.Visible = False
        'vallngthtxtlng26.Visible = False
        valddlgl26.Visible = False
        numvaltxtqty26.Visible = False
        valtxtqty26.Visible = False
        numvaltxtprice26.Visible = False
        valtxtprice26.Visible = False
        ddlgl26.Items.Remove("---Select Account---")
        txtprice26.Text = "0"

        vallngthtxtlng26.Visible = False
        txtvenmat26.visible = False
        txttrackno26.visible = False

    End Sub

    Protected Sub BtnRem26_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem26.Click
        lbl270.Visible = False
        txtshrt27.Visible = False
        txtlng27.Visible = False
        txtqty27.Visible = False
        txtprice27.Visible = False
        ddluom27.Visible = False
        txttotal27.Visible = False
        ddltax27.Visible = False
        txtdate27.Visible = False
        BtnAdd26.Visible = True
        BtnAdd27.Visible = False
        BtnRem25.Visible = True
        BtnRem26.Visible = False
        ddlgl27.Visible = False
        valtxtshrt27.Visible = False
        'vallngthtxtlng27.Visible = False
        valddlgl27.Visible = False
        numvaltxtqty27.Visible = False
        valtxtqty27.Visible = False
        numvaltxtprice27.Visible = False
        valtxtprice27.Visible = False
        ddlgl27.Items.Remove("---Select Account---")
        txtprice27.Text = "0"

        vallngthtxtlng27.Visible = False
        txtvenmat27.visible = False
        txttrackno27.visible = False

    End Sub

    Protected Sub BtnRem27_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem27.Click
        lbl280.Visible = False
        txtshrt28.Visible = False
        txtlng28.Visible = False
        txtqty28.Visible = False
        txtprice28.Visible = False
        ddluom28.Visible = False
        txttotal28.Visible = False
        ddltax28.Visible = False
        txtdate28.Visible = False
        BtnAdd27.Visible = True
        BtnAdd28.Visible = False
        BtnRem26.Visible = True
        BtnRem27.Visible = False
        ddlgl28.Visible = False
        valtxtshrt28.Visible = False
        'vallngthtxtlng28.Visible = False
        valddlgl28.Visible = False
        numvaltxtqty28.Visible = False
        valtxtqty28.Visible = False
        numvaltxtprice28.Visible = False
        valtxtprice28.Visible = False
        ddlgl28.Items.Remove("---Select Account---")
        txtprice28.Text = "0"

        vallngthtxtlng28.Visible = False
        txtvenmat28.visible = False
        txttrackno28.visible = False

    End Sub

    Protected Sub BtnRem28_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem28.Click
        lbl290.Visible = False
        txtshrt29.Visible = False
        txtlng29.Visible = False
        txtqty29.Visible = False
        txtprice29.Visible = False
        ddluom29.Visible = False
        txttotal29.Visible = False
        ddltax29.Visible = False
        txtdate29.Visible = False
        BtnAdd28.Visible = True
        BtnAdd29.Visible = False
        BtnRem27.Visible = True
        BtnRem28.Visible = False
        ddlgl29.Visible = False
        valtxtshrt29.Visible = False
        'vallngthtxtlng29.Visible = False
        valddlgl29.Visible = False
        numvaltxtqty29.Visible = False
        valtxtqty29.Visible = False
        numvaltxtprice29.Visible = False
        valtxtprice29.Visible = False
        ddlgl29.Items.Remove("---Select Account---")
        txtprice29.Text = "0"

        vallngthtxtlng29.Visible = False
        txtvenmat29.visible = False
        txttrackno29.visible = False

    End Sub


    Protected Sub BtnRem29_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRem29.Click
        lbl300.Visible = False
        txtshrt30.Visible = False
        txtlng30.Visible = False
        txtqty30.Visible = False
        txtprice30.Visible = False
        ddluom30.Visible = False
        txttotal30.Visible = False
        ddltax30.Visible = False
        txtdate30.Visible = False
        BtnAdd29.Visible = True
        BtnRem28.Visible = True
        BtnRem29.Visible = False
        ddlgl30.Visible = False
        valtxtshrt30.Visible = False
        'vallngthtxtlng30.Visible = False
        valddlgl30.Visible = False
        numvaltxtqty30.Visible = False
        valtxtqty30.Visible = False
        numvaltxtprice30.Visible = False
        valtxtprice30.Visible = False
        ddlgl30.Items.Remove("---Select Account---")
        txtprice30.Text = "0"

        vallngthtxtlng30.Visible = False
        txtvenmat30.visible = False
        txttrackno30.visible = False

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim FQDN As String = "showell5345345435435"
        Dim usrnm As String = FQDN.Remove(0, 8)
        Dim email As String = usrnm + "@ymmc.yamaha-motor.com"
        'If Not Page.IsPostBack() Then
        '    Page.RegisterClientScriptBlock("OnLoad", "<script>alert('Welcome to ShotDev.Com')</script>")
        'End If

        lblsubdate.Text = DateTime.Now.ToString("yyyyMMdd")
        Label1.Text = email
        Dim RNO As String = CType(Session.Item("RNO"), String)
        Label6.Text = RNO
        If RNO = "" Then
            Label5.Visible = False
            Label6.Visible = False

        End If
        Dim VenNo As String = CType(Session.Item("VenNo"), String)
        If VenNo = "" Then
        Else
            ddlvendor.SelectedValue = VenNo
        End If

        Button1.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(Button1, Nothing) + ";")


        txttotal1.Attributes.Add("readonly", "True")
        txttotal2.Attributes.Add("readonly", "True")
        txttotal3.Attributes.Add("readonly", "True")
        txttotal4.Attributes.Add("readonly", "True")
        txttotal5.Attributes.Add("readonly", "True")
        txttotal6.Attributes.Add("readonly", "True")
        txttotal7.Attributes.Add("readonly", "True")
        txttotal8.Attributes.Add("readonly", "True")
        txttotal9.Attributes.Add("readonly", "True")
        txttotal10.Attributes.Add("readonly", "True")
        txttotal11.Attributes.Add("readonly", "True")
        txttotal12.Attributes.Add("readonly", "True")
        txttotal13.Attributes.Add("readonly", "True")
        txttotal14.Attributes.Add("readonly", "True")
        txttotal15.Attributes.Add("readonly", "True")
        txttotal16.Attributes.Add("readonly", "True")
        txttotal17.Attributes.Add("readonly", "True")
        txttotal18.Attributes.Add("readonly", "True")
        txttotal19.Attributes.Add("readonly", "True")
        txttotal20.Attributes.Add("readonly", "True")
        txttotal21.Attributes.Add("readonly", "True")
        txttotal22.Attributes.Add("readonly", "True")
        txttotal23.Attributes.Add("readonly", "True")
        txttotal24.Attributes.Add("readonly", "True")
        txttotal25.Attributes.Add("readonly", "True")
        txttotal26.Attributes.Add("readonly", "True")
        txttotal27.Attributes.Add("readonly", "True")
        txttotal28.Attributes.Add("readonly", "True")
        txttotal29.Attributes.Add("readonly", "True")
        txttotal30.Attributes.Add("readonly", "True")

        txtdate1.Attributes.Add("readonly", "readonly")
        txtdate2.Attributes.Add("readonly", "True")
        txtdate3.Attributes.Add("readonly", "True")
        txtdate4.Attributes.Add("readonly", "True")
        txtdate5.Attributes.Add("readonly", "True")
        txtdate6.Attributes.Add("readonly", "True")
        txtdate7.Attributes.Add("readonly", "True")
        txtdate8.Attributes.Add("readonly", "True")
        txtdate9.Attributes.Add("readonly", "True")
        txtdate10.Attributes.Add("readonly", "True")
        txtdate11.Attributes.Add("readonly", "True")
        txtdate12.Attributes.Add("readonly", "True")
        txtdate13.Attributes.Add("readonly", "True")
        txtdate14.Attributes.Add("readonly", "True")
        txtdate15.Attributes.Add("readonly", "True")
        txtdate16.Attributes.Add("readonly", "True")
        txtdate17.Attributes.Add("readonly", "True")
        txtdate18.Attributes.Add("readonly", "True")
        txtdate19.Attributes.Add("readonly", "True")
        txtdate20.Attributes.Add("readonly", "True")
        txtdate21.Attributes.Add("readonly", "True")
        txtdate22.Attributes.Add("readonly", "True")
        txtdate23.Attributes.Add("readonly", "True")
        txtdate24.Attributes.Add("readonly", "True")
        txtdate25.Attributes.Add("readonly", "True")
        txtdate26.Attributes.Add("readonly", "True")
        txtdate27.Attributes.Add("readonly", "True")
        txtdate28.Attributes.Add("readonly", "True")
        txtdate29.Attributes.Add("readonly", "True")
        txtdate30.Attributes.Add("readonly", "True")

        'txtdate1.Text = DateTime.Now.ToString("yyyyMMdd")
        'txtdate2.Text = Date.Now.Date
        'txtdate3.Text = Date.Now.Date
        'txtdate4.Text = Date.Now.Date
        'txtdate5.Text = Date.Now.Date
        'txtdate6.Text = Date.Now.Date
        'txtdate7.Text = Date.Now.Date
        'txtdate8.Text = Date.Now.Date
        'txtdate9.Text = Date.Now.Date
        'txtdate10.Text = Date.Now.Date
        'txtdate11.Text = Date.Now.Date
        'txtdate12.Text = Date.Now.Date
        'txtdate13.Text = Date.Now.Date
        'txtdate14.Text = Date.Now.Date
        'txtdate15.Text = Date.Now.Date
        'txtdate16.Text = Date.Now.Date
        'txtdate17.Text = Date.Now.Date
        'txtdate18.Text = Date.Now.Date
        'txtdate19.Text = Date.Now.Date
        'txtdate20.Text = Date.Now.Date
        'txtdate21.Text = Date.Now.Date
        'txtdate22.Text = Date.Now.Date
        'txtdate23.Text = Date.Now.Date
        'txtdate24.Text = Date.Now.Date
        'txtdate25.Text = Date.Now.Date
        'txtdate26.Text = Date.Now.Date
        'txtdate27.Text = Date.Now.Date
        'txtdate28.Text = Date.Now.Date
        'txtdate29.Text = Date.Now.Date
        'txtdate30.Text = Date.Now.Date

        txtqty1.Attributes.Add("onchange", "DefaultValue();")
        txtprice1.Attributes.Add("onchange", "DefaultValue();")
        txtqty2.Attributes.Add("onchange", "DefaultValue();")
        txtprice2.Attributes.Add("onchange", "DefaultValue();")
        txtqty3.Attributes.Add("onchange", "DefaultValue();")
        txtprice3.Attributes.Add("onchange", "DefaultValue();")
        txtqty4.Attributes.Add("onchange", "DefaultValue();")
        txtprice4.Attributes.Add("onchange", "DefaultValue();")
        txtqty5.Attributes.Add("onchange", "DefaultValue();")
        txtprice5.Attributes.Add("onchange", "DefaultValue();")
        txtprice6.Attributes.Add("onchange", "DefaultValue();")
        txtqty6.Attributes.Add("onchange", "DefaultValue();")
        txtprice7.Attributes.Add("onchange", "DefaultValue();")
        txtqty7.Attributes.Add("onchange", "DefaultValue();")
        txtprice8.Attributes.Add("onchange", "DefaultValue();")
        txtqty8.Attributes.Add("onchange", "DefaultValue();")
        txtprice9.Attributes.Add("onchange", "DefaultValue();")
        txtqty9.Attributes.Add("onchange", "DefaultValue();")
        txtprice10.Attributes.Add("onchange", "DefaultValue();")
        txtqty10.Attributes.Add("onchange", "DefaultValue();")
        txtprice11.Attributes.Add("onchange", "DefaultValue();")
        txtqty11.Attributes.Add("onchange", "DefaultValue();")
        txtprice12.Attributes.Add("onchange", "DefaultValue();")
        txtqty12.Attributes.Add("onchange", "DefaultValue();")
        txtprice13.Attributes.Add("onchange", "DefaultValue();")
        txtqty13.Attributes.Add("onchange", "DefaultValue();")
        txtprice14.Attributes.Add("onchange", "DefaultValue();")
        txtqty14.Attributes.Add("onchange", "DefaultValue();")
        txtprice15.Attributes.Add("onchange", "DefaultValue();")
        txtqty15.Attributes.Add("onchange", "DefaultValue();")
        txtprice16.Attributes.Add("onchange", "DefaultValue();")
        txtqty16.Attributes.Add("onchange", "DefaultValue();")
        txtprice17.Attributes.Add("onchange", "DefaultValue();")
        txtqty17.Attributes.Add("onchange", "DefaultValue();")
        txtprice18.Attributes.Add("onchange", "DefaultValue();")
        txtqty18.Attributes.Add("onchange", "DefaultValue();")
        txtprice19.Attributes.Add("onchange", "DefaultValue();")
        txtqty19.Attributes.Add("onchange", "DefaultValue();")
        txtprice20.Attributes.Add("onchange", "DefaultValue();")
        txtqty20.Attributes.Add("onchange", "DefaultValue();")
        txtprice21.Attributes.Add("onchange", "DefaultValue();")
        txtqty21.Attributes.Add("onchange", "DefaultValue();")
        txtprice22.Attributes.Add("onchange", "DefaultValue();")
        txtqty22.Attributes.Add("onchange", "DefaultValue();")
        txtprice23.Attributes.Add("onchange", "DefaultValue();")
        txtqty23.Attributes.Add("onchange", "DefaultValue();")
        txtprice24.Attributes.Add("onchange", "DefaultValue();")
        txtqty24.Attributes.Add("onchange", "DefaultValue();")
        txtprice25.Attributes.Add("onchange", "DefaultValue();")
        txtqty25.Attributes.Add("onchange", "DefaultValue();")
        txtprice26.Attributes.Add("onchange", "DefaultValue();")
        txtqty26.Attributes.Add("onchange", "DefaultValue();")
        txtprice27.Attributes.Add("onchange", "DefaultValue();")
        txtqty27.Attributes.Add("onchange", "DefaultValue();")
        txtprice28.Attributes.Add("onchange", "DefaultValue();")
        txtqty28.Attributes.Add("onchange", "DefaultValue();")
        txtprice29.Attributes.Add("onchange", "DefaultValue();")
        txtqty29.Attributes.Add("onchange", "DefaultValue();")
        txtprice30.Attributes.Add("onchange", "DefaultValue();")
        txtqty30.Attributes.Add("onchange", "DefaultValue();")

        If radiobuttonlist1.selectedvalue = "MRO" Then
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = GL
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gl
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = gl
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = gl
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = gl
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = gl
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = gl
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = gl
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = gl
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = gl
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = gl
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = gl
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = gl
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = gl
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = gl
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = gl
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = gl
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = gl
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = gl
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = gl
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = gl
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = gl
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = gl
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = gl
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = gl
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = gl
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = gl
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = gl
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = gl
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = gl

        ElseIf radiobuttonlist1.selectedvalue = "" Then
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = GL
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gl
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = gl
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = gl
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = gl
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = gl
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = gl
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = gl
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = gl
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = gl
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = gl
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = gl
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = gl
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = gl
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = gl
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = gl
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = gl
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = gl
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = gl
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = gl
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = gl
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = gl
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = gl
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = gl
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = gl
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = gl
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = gl
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = gl
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = gl
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = gl
        ElseIf radiobuttonlist1.selectedvalue = "IO4" Then
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glh
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glh
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glh
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glh
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glh
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glh
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glh
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glh
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glh
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glh
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glh
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glh
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glh
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glh
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glh
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glh
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glh
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glh
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glh
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glh
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glh
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glh
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glh
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glh
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glh
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glh
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glh
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glh
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glh
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glh
        ElseIf radiobuttonlist1.selectedvalue = "IO6" Then
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glj
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glj
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glj
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glj
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glj
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glj
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glj
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glj
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glj
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glj
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glj
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glj
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glj
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glj
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glj
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glj
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glj
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glj
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glj
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glj
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glj
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glj
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glj
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glj
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glj
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glj
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glj
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glj
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glj
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glj
        ElseIf radiobuttonlist1.selectedvalue = "IO5" Then
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = gli
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gli
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = gli
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = gli
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = gli
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = gli
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = gli
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = gli
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = gli
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = gli
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = gli
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = gli
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = gli
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = gli
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = gli
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = gli
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = gli
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = gli
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = gli
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = gli
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = gli
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = gli
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = gli
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = gli
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = gli
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = gli
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = gli
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = gli
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = gli
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = gli
        ElseIf radiobuttonlist1.selectedvalue = "REW" Then
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glr
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glr
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glr
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glr
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glr
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glr
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glr
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glr
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glr
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glr
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glr
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glr
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glr
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glr
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glr
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glr
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glr
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glr
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glr
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glr
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glr
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glr
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glr
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glr
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glr
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glr
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glr
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glr
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glr
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glr
        Else
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glf
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glf
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glf
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glf
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glf
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glf
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glf
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glf
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glf
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glf
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glf
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glf
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glf
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glf
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glf
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glf
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glf
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glf
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glf
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glf
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glf
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glf
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glf
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glf
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glf
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glf
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glf
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glf
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glf
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glf


        End If
        If radiobuttonlist1.selectedvalue = "" Then
            lblgroup.text = "MRO"
        Else
            lblgroup.text = radiobuttonlist1.selectedvalue

        End If


        'ddlgl1.databind()
        'ddlgl2.DataBind()
        'ddlgl3.DataBind()
        'ddlgl4.DataBind()
        'ddlgl5.DataBind()
        'ddlgl6.DataBind()
        'ddlgl7.DataBind()
        'ddlgl8.DataBind()
        'ddlgl9.DataBind()
        'ddlgl10.DataBind()
        'ddlgl11.DataBind()
        'ddlgl12.DataBind()
        'ddlgl13.DataBind()
        'ddlgl14.DataBind()
        'ddlgl15.DataBind()
        'ddlgl16.DataBind()
        'ddlgl17.DataBind()
        'ddlgl18.DataBind()
        'ddlgl19.DataBind()
        'ddlgl20.DataBind()
        'ddlgl21.DataBind()
        'ddlgl22.DataBind()
        'ddlgl23.DataBind()
        'ddlgl24.DataBind()
        'ddlgl25.DataBind()
        'ddlgl26.DataBind()
        'ddlgl27.DataBind()
        'ddlgl28.DataBind()
        'ddlgl29.DataBind()
        'ddlgl30.DataBind()

    End Sub

    Protected Sub ddlvendor_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlvendor.DataBound

        ddlvendor.Items.Insert(0, New ListItem("---Select Vendor---", "---Select Vendor---"))

        Dim VenNo As String = CType(Session.Item("VenNo"), String)
        If VenNo = "" Then
            ddlvendor.SelectedValue = "---Select Vendor---"
        Else
            ddlvendor.SelectedValue = VenNo
        End If

    End Sub


    'Protected Sub CheckBox1_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox1.CheckedChanged
    '    If CheckBox1.Checked = True Then
    '        ddlcpfr.Visible = True
    '        ddlcpfr.DataBind()
    '        valddlcpfr.Visible = True
    '        'ddlgrp.SelectedValue = "CPFR"
    '        'ddlgrp.Enabled = False
    '        ddlcpfr.SelectedValue = "---Select CPFR Number---"
    '        'txtacctcat.Text = "F"
    '        'ddlgrp.Items.Remove("MRO")
    '        ddlgrp.DataBind()
    '        ddlgl1.DataBind()
    '        ddlgl2.DataBind()
    '        ddlgl3.DataBind()
    '        ddlgl4.DataBind()
    '        ddlgl5.DataBind()
    '        ddlgl6.DataBind()
    '        ddlgl7.DataBind()
    '        ddlgl8.DataBind()
    '        ddlgl9.DataBind()
    '        ddlgl10.DataBind()
    '        ddlgl11.DataBind()
    '        ddlgl12.DataBind()
    '        ddlgl13.DataBind()
    '        ddlgl14.DataBind()
    '        ddlgl15.DataBind()
    '        ddlgl16.DataBind()
    '        ddlgl17.DataBind()
    '        ddlgl18.DataBind()
    '        ddlgl19.DataBind()
    '        ddlgl20.DataBind()
    '        ddlgl21.DataBind()
    '        ddlgl22.DataBind()
    '        ddlgl23.DataBind()
    '        ddlgl24.DataBind()
    '        ddlgl25.DataBind()
    '        ddlgl26.DataBind()
    '        ddlgl27.DataBind()
    '        ddlgl28.DataBind()
    '        ddlgl29.DataBind()
    '        ddlgl30.DataBind()

    '    Else
    '        ddlgrp.DataBind()
    '        ddlcpfr.Visible = False
    '        valddlcpfr.Visible = False
    '        ddlgrp.SelectedValue = "---Select Purchasing Group---"
    '        ddlcpfr.SelectedValue = ""
    '        'ddlgrp.Enabled = True
    '        txtacctcat.Text = "k"
    '        ddlgl1.DataBind()
    '        ddlgl2.DataBind()
    '        ddlgl3.DataBind()
    '        ddlgl4.DataBind()
    '        ddlgl5.DataBind()
    '        ddlgl6.DataBind()
    '        ddlgl7.DataBind()
    '        ddlgl8.DataBind()
    '        ddlgl9.DataBind()
    '        ddlgl10.DataBind()
    '        ddlgl11.DataBind()
    '        ddlgl12.DataBind()
    '        ddlgl13.DataBind()
    '        ddlgl14.DataBind()
    '        ddlgl15.DataBind()
    '        ddlgl16.DataBind()
    '        ddlgl17.DataBind()
    '        ddlgl18.DataBind()
    '        ddlgl19.DataBind()
    '        ddlgl20.DataBind()
    '        ddlgl21.DataBind()
    '        ddlgl22.DataBind()
    '        ddlgl23.DataBind()
    '        ddlgl24.DataBind()
    '        ddlgl25.DataBind()
    '        ddlgl26.DataBind()
    '        ddlgl27.DataBind()
    '        ddlgl28.DataBind()
    '        ddlgl29.DataBind()
    '        ddlgl30.DataBind()
    '        'ddlgrp.Items.Insert(1, New ListItem("MRO", "MRO"))




    '    End If
    'End Sub

    Protected Sub Page_PreInit(sender As Object, e As System.EventArgs) Handles Me.PreInit
        txtdate1.Text = Date.Now.Date
        txtdate2.Text = Date.Now.Date
        txtdate3.Text = Date.Now.Date
        txtdate4.Text = Date.Now.Date
        txtdate5.Text = Date.Now.Date
        txtdate6.Text = Date.Now.Date
        txtdate7.Text = Date.Now.Date
        txtdate8.Text = Date.Now.Date
        txtdate9.Text = Date.Now.Date
        txtdate10.Text = Date.Now.Date
        txtdate11.Text = Date.Now.Date
        txtdate12.Text = Date.Now.Date
        txtdate13.Text = Date.Now.Date
        txtdate14.Text = Date.Now.Date
        txtdate15.Text = Date.Now.Date
        txtdate16.Text = Date.Now.Date
        txtdate17.Text = Date.Now.Date
        txtdate18.Text = Date.Now.Date
        txtdate19.Text = Date.Now.Date
        txtdate20.Text = Date.Now.Date
        txtdate21.Text = Date.Now.Date
        txtdate22.Text = Date.Now.Date
        txtdate23.Text = Date.Now.Date
        txtdate24.Text = Date.Now.Date
        txtdate25.Text = Date.Now.Date
        txtdate26.Text = Date.Now.Date
        txtdate27.Text = Date.Now.Date
        txtdate28.Text = Date.Now.Date
        txtdate29.Text = Date.Now.Date
        txtdate30.Text = Date.Now.Date
    End Sub

    Protected Sub ddlgrp_DataBound(sender As Object, e As System.EventArgs) Handles ddlgrp.DataBound
        ddlgrp.Items.Insert(0, New ListItem("---Select Purchasing Group---", "---Select Purchasing Group---"))
        ddlgrp.SelectedValue = "---Select Purchasing Group---"
        If CheckBox1.Checked = True Then
            'ddlgrp.Items.Remove("MRO - MRO")
            'ddlgrp.Items.Remove("MRO")

        End If

    End Sub

    Protected Sub ddlccenter_DataBound(sender As Object, e As System.EventArgs) Handles ddlccenter.DataBound
        ddlccenter.Items.Insert(0, New ListItem("---Select Cost Center---", "---Select Cost Center---"))
        ddlccenter.SelectedValue = "---Select Cost Center---"
        ddlccenter.items.insert(0, New ListItem("", ""))
    End Sub

    Protected Sub ddlcpfr_DataBound(sender As Object, e As System.EventArgs) Handles ddlcpfr.DataBound
        ddlcpfr.Items.Insert(0, New ListItem("---Select CPFR Number---", "---Select CPFR Number---"))
        ddlcpfr.Items.Insert(0, New ListItem("", ""))
        ddlcpfr.SelectedValue = "---Select CPFR Number---"
    End Sub

    'Protected Sub ddlgl1_DataBinding(sender As Object, e As System.EventArgs) Handles ddlgl1.DataBinding
    '    If txtacctcat.Text = "h" Then
    '        ddlgl1.DataSource = GLh
    '        ddlgl1.DataSourceID = ""

    '    End If
    'End Sub

    Protected Sub ddlgl1_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl1.DataBound
        ddlgl1.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl2_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl2.DataBound
        ddlgl2.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl3_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl3.DataBound
        ddlgl3.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))



    End Sub
    Protected Sub ddlgl4_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl4.DataBound
        ddlgl4.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl5_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl5.DataBound
        ddlgl5.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl6_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl6.DataBound
        ddlgl6.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl7_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl7.DataBound
        ddlgl7.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl8_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl8.DataBound
        ddlgl8.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl9_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl9.DataBound
        ddlgl9.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl10_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl10.DataBound
        ddlgl10.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl11_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl11.DataBound
        ddlgl11.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl12_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl12.DataBound
        ddlgl12.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl13_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl13.DataBound
        ddlgl13.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl14_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl14.DataBound
        ddlgl14.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl15_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl15.DataBound
        ddlgl15.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl16_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl16.DataBound
        ddlgl16.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub

    Protected Sub ddlgl17_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl17.DataBound
        ddlgl17.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl18_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl18.DataBound
        ddlgl18.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl19_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl19.DataBound
        ddlgl19.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl20_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl20.DataBound
        ddlgl20.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl21_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl21.DataBound
        ddlgl21.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl22_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl22.DataBound
        ddlgl22.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl23_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl23.DataBound
        ddlgl23.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl24_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl24.DataBound
        ddlgl24.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl25_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl25.DataBound
        ddlgl25.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl26_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl26.DataBound
        ddlgl26.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl27_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl27.DataBound
        ddlgl27.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl28_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl28.DataBound
        ddlgl28.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl29_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl29.DataBound
        ddlgl29.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl30_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl30.DataBound
        ddlgl30.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub

    'Protected Sub ddlgrp_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ddlgrp.SelectedIndexChanged


    '    If ddlgrp.SelectedValue = "MRO" Then
    '        txtacctcat.Text = "K"

    '    ElseIf ddlgrp.SelectedValue = "IO4" Then
    '        txtacctcat.Text = "H"
    '    Else
    '        txtacctcat.Text = "F"
    '    End If
    'End Sub

    Protected Sub RadioButtonList1_DataBound(sender As Object, e As System.EventArgs) Handles RadioButtonList1.DataBound
        RadioButtonList1.SelectedValue = "MRO"
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        If RadioButtonList1.SelectedValue = "MRO" Then
            ddlccenter.visible = True
            valddlccenter.visible = True
            valddlccenterblnk.visible = True
            ddlccenter.selectedvalue = "---Select Cost Center---"
            lblccenter.visible = True
            'ddlcpfr.DataSource = CPFR
            'ddlcpfr.DataSourceID = ""
            'ddlcpfr.databind()
            ddlcpfr.selectedvalue = ""
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = GL
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gl
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = gl
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = gl
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = gl
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = gl
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = gl
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = gl
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = gl
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = gl
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = gl
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = gl
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = gl
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = gl
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = gl
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = gl
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = gl
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = gl
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = gl
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = gl
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = gl
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = gl
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = gl
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = gl
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = gl
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = gl
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = gl
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = gl
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = gl
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = gl
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.visible = False
            lblcpfr.visible = False
            txtacctcat.Text = "K"
            valddlcpfr.Visible = False
            valcpfrblnk.Visible = False
        ElseIf RadioButtonList1.SelectedValue = "IO1" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = GLf
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glf
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glf
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glf
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glf
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glf
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glf
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glf
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glf
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glf
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glf
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glf
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glf
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glf
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glf
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glf
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glf
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glf
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glf
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glf
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glf
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glf
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glf
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glf
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glf
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glf
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glf
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glf
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glf
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glf
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.DataSource = CPFRio1
            ddlcpfr.datasourceid = ""
            ddlcpfr.databind()
            ddlcpfr.visible = True
            lblcpfr.visible = True
            txtacctcat.Text = "F"
            valddlcpfr.Visible = True
            valcpfrblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO2" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = GLf
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glf
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glf
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glf
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glf
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glf
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glf
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glf
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glf
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glf
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glf
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glf
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glf
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glf
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glf
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glf
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glf
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glf
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glf
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glf
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glf
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glf
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glf
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glf
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glf
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glf
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glf
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glf
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glf
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glf
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.DataSource = CPFRio2
            ddlcpfr.datasourceid = ""
            ddlcpfr.databind()
            ddlcpfr.visible = True
            lblcpfr.visible = True
            txtacctcat.Text = "F"
            valddlcpfr.Visible = True
            valcpfrblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO3" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = GLf
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glf
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glf
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glf
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glf
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glf
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glf
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glf
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glf
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glf
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glf
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glf
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glf
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glf
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glf
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glf
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glf
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glf
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glf
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glf
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glf
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glf
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glf
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glf
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glf
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glf
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glf
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glf
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glf
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glf
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.DataSource = CPFRio3
            ddlcpfr.datasourceid = ""
            ddlcpfr.databind()
            ddlcpfr.visible = True
            lblcpfr.visible = True
            txtacctcat.Text = "F"
            valddlcpfr.Visible = True
            valcpfrblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO4" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glh
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glh
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glh
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glh
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glh
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glh
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glh
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glh
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glh
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glh
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glh
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glh
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glh
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glh
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glh
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glh
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glh
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glh
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glh
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glh
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glh
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glh
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glh
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glh
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glh
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glh
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glh
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glh
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glh
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glh
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.DataSource = CPFRio4
            ddlcpfr.datasourceid = ""
            ddlcpfr.databind()
            ddlcpfr.visible = True
            lblcpfr.visible = True
            txtacctcat.Text = "H"
            valddlcpfr.Visible = True
            valcpfrblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO5" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = gli
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gli
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = gli
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = gli
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = gli
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = gli
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = gli
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = gli
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = gli
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = gli
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = gli
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = gli
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = gli
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = gli
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = gli
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = gli
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = gli
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = gli
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = gli
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = gli
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = gli
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = gli
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = gli
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = gli
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = gli
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = gli
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = gli
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = gli
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = gli
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = gli
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.DataSource = CPFRio5
            ddlcpfr.datasourceid = ""
            ddlcpfr.databind()
            ddlcpfr.visible = True
            lblcpfr.visible = True
            txtacctcat.Text = "I"
            valddlcpfr.Visible = True
            valcpfrblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO6" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glj
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glj
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glj
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glj
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glj
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glj
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glj
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glj
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glj
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glj
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glj
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glj
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glj
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glj
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glj
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glj
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glj
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glj
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glj
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glj
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glj
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glj
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glj
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glj
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glj
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glj
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glj
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glj
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glj
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glj
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.DataSource = CPFRio6
            ddlcpfr.datasourceid = ""
            ddlcpfr.databind()
            ddlcpfr.visible = True
            lblcpfr.visible = True
            txtacctcat.Text = "J"
            valddlcpfr.Visible = True
            valcpfrblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "REW" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glr
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glr
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glr
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glr
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glr
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glr
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glr
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glr
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glr
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glr
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glr
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glr
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glr
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glr
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glr
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glr
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glr
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glr
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glr
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glr
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glr
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glr
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glr
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glr
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glr
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glr
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glr
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glr
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glr
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glr
            ddlgl1.databind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddlcpfr.DataSource = CPFRrew
            ddlcpfr.datasourceid = ""
            ddlcpfr.databind()
            ddlcpfr.visible = True
            lblcpfr.visible = True
            txtacctcat.Text = "R"
            valddlcpfr.Visible = True
            valcpfrblnk.Visible = True
        End If
    End Sub

    Protected Sub BtnVenSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVenSearch.Click
        Panel1.Visible = False
        Panel2.Visible = True
        'Response.Redirect("~/Vendor_Search.aspx")
    End Sub
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Session("VenNo") = ""
    End Sub

    Protected Sub GridView2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView2.SelectedIndexChanged
        ddlvendor.SelectedValue = gridview2.selectedvalue
        Panel2.visible = False
        Panel1.Visible = True


    End Sub

    Protected Sub BtnVSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVSearch.Click
        GridView2.Visible = True
    End Sub

    Protected Sub BtnVenSearchCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVenSearchCancel.Click
        Panel2.Visible = False
        Panel1.Visible = True
    End Sub
End Class
