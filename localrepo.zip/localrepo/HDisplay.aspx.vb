﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class Display
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Dim con As New SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
        Dim cmd As New SqlCommand
        Dim dt As New DataTable
        Dim HIDno As String = CType(Session.Item("HIDno"), String)
        'lblidno.Text = IDno
        con.Open()
        cmd.Connection = con
        cmd.CommandText = "Select count(*) from SAPPOREQH WHERE seqkey = '" & HIDno & "'"
        Dim result As Object = cmd.ExecuteScalar
        'lblresult.Text = String.Format(result)
        'cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.Text & "', '" & ddlcpfr.SelectedValue & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "','" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "')"
        'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate, subdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddlcpfr.Text & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "','" & DateTime.Now & "')"
        cmd.ExecuteNonQuery()
        con.Close()

        con.Open()
        Dim da As New SqlDataAdapter("SELECT * FROM SAPPOREQH WHERE seqkey = '" & HIDno & "'" & "order by SEQLINE asc", con)
        da.Fill(dt)
        lblven.Text = dt.Rows(0)("vendor")
        lblcc.Text = dt.Rows(0)("ccenter")
        lblcpfr.Text = dt.Rows(0)("cpfr")
        lblgrp.Text = dt.Rows(0)("purgroup")
        lblhdr.Text = dt.Rows(0)("hdrtext")
        lblstatus.Text = dt.Rows(0)("status")
        If Not IsDBNull(dt.Rows(0)("errordesc")) Then
            lblerr.Visible = True
            lblerrtxt.Visible = True
            lblerr.Text = dt.Rows(0)("errordesc")
        End If
        If Not IsDBNull(dt.Rows(0)("cpfr")) Then
            lblcpfr.Text = dt.Rows(0)("cpfr")
        Else
            lblcpfr.Text = ""
        End If

        If Not IsDBNull(dt.Rows(0)("poreq")) Then
            lblreq.Text = dt.Rows(0)("poreq")
        End If
        If Not IsDBNull(dt.Rows(0)("sappo")) Then
            lblpo.Text = dt.Rows(0)("sappo")
        End If

        If dt.Rows(0)("status") = "1" Then
            lblstatdesc.Text = "Pending"
        ElseIf dt.Rows(0)("status") = "X" Then
            lblstatdesc.Text = "Transferred to SAP"
        ElseIf dt.Rows(0)("status") = "2" Then
            lblstatdesc.Text = "SAP Requsition Created"
        ElseIf dt.Rows(0)("status") = "3" Then
            lblstatdesc.Text = "PO Created"
        ElseIf dt.Rows(0)("status") = "4" Then
            lblstatdesc.Text = "Rejected"
        ElseIf dt.Rows(0)("status") = "6" Then
            lblstatdesc.Text = "ERROR, See error description."
            lblstatdesc.ForeColor = Drawing.Color.Red

        End If
        Dim tot0 As Double
        Dim tot1 As Double
        Dim tot2 As Double
        Dim tot3 As Double
        Dim tot4 As Double
        Dim tot5 As Double
        Dim tot6 As Double
        Dim tot7 As Double
        Dim tot8 As Double
        Dim tot9 As Double
        Dim tot10 As Double
        Dim tot11 As Double
        Dim tot12 As Double
        Dim tot13 As Double
        Dim tot14 As Double
        Dim tot15 As Double
        Dim tot16 As Double
        Dim tot17 As Double
        Dim tot18 As Double
        Dim tot19 As Double
        Dim tot20 As Double
        Dim tot21 As Double
        Dim tot22 As Double
        Dim tot23 As Double
        Dim tot24 As Double
        Dim tot25 As Double
        Dim tot26 As Double
        Dim tot27 As Double
        Dim tot28 As Double
        Dim tot29 As Double
        tot0 = dt.Rows(0)("unitprc") * dt.Rows(0)("unitqty")
        lbltot1.Text = String.Format("${0:0.00}", tot0)
        lblsht1.Text = dt.Rows(0)("shorttext")
        lblgl1.Text = dt.Rows(0)("glacct")
        lblqty1.Text = dt.Rows(0)("unitqty")
        lblprice1.Text = dt.Rows(0)("unitprc")
        lbluom1.Text = dt.Rows(0)("uom")
        lbltax1.Text = dt.Rows(0)("taxflag")
        lbldelv1.Text = dt.Rows(0)("dlvdate")
        If Not IsDBNull(dt.Rows(0)("venitem")) Then
            lblvenmat1.Text = dt.Rows(0)("venitem")
        Else
            lblvenmat1.Text = ""
        End If
        If Not IsDBNull(dt.Rows(0)("refpart")) Then
            lbltrackno1.Text = dt.Rows(0)("refpart")
        Else
            lbltrackno1.Text = ""
        End If
        If Not IsDBNull(dt.Rows(0)("longtext")) Then
            lbllng1.Text = dt.Rows(0)("longtext")
        Else
            lbllng1.Text = ""
        End If

        If result > "1" Then
            tot1 = dt.Rows(1)("unitprc") * dt.Rows(1)("unitqty")
            Panel2.Visible = True
            lblsht2.Text = dt.Rows(1)("shorttext")

            lblgl2.Text = dt.Rows(1)("glacct")
            lblqty2.Text = dt.Rows(1)("unitqty")
            lblprice2.Text = dt.Rows(1)("unitprc")
            lbluom2.Text = dt.Rows(1)("uom")
            lbltot2.Text = String.Format("${0:0.00}", tot1)
            lbltax2.Text = dt.Rows(1)("taxflag")
            lbldelv2.Text = dt.Rows(1)("dlvdate")
            If Not IsDBNull(dt.Rows(1)("venitem")) Then
                lblvenmat2.Text = dt.Rows(1)("venitem")
            Else
                lblvenmat2.Text = ""
            End If
            If Not IsDBNull(dt.Rows(1)("refpart")) Then
                lbltrackno2.Text = dt.Rows(1)("refpart")
            Else
                lbltrackno2.Text = ""
            End If
            If Not IsDBNull(dt.Rows(1)("longtext")) Then
                lbllng2.Text = dt.Rows(1)("longtext")
            Else
                lbllng2.Text = ""
            End If
        End If
        If result > "2" Then
            tot2 = dt.Rows(2)("unitprc") * dt.Rows(2)("unitqty")
            Panel3.Visible = True
            lblsht3.Text = dt.Rows(2)("shorttext")

            lblgl3.Text = dt.Rows(2)("glacct")
            lblqty3.Text = dt.Rows(2)("unitqty")
            lblprice3.Text = dt.Rows(2)("unitprc")
            lbluom3.Text = dt.Rows(2)("uom")
            lbltot3.Text = String.Format("${0:0.00}", tot2)
            lbltax3.Text = dt.Rows(2)("taxflag")
            lbldelv3.Text = dt.Rows(2)("dlvdate")
            If Not IsDBNull(dt.Rows(2)("venitem")) Then
                lblvenmat3.Text = dt.Rows(2)("venitem")
            Else
                lblvenmat3.Text = ""
            End If
            If Not IsDBNull(dt.Rows(2)("refpart")) Then
                lbltrackno3.Text = dt.Rows(2)("refpart")
            Else
                lbltrackno3.Text = ""
            End If
            If Not IsDBNull(dt.Rows(2)("longtext")) Then
                lbllng3.Text = dt.Rows(2)("longtext")
            Else
                lbllng3.Text = ""
            End If
        End If
        If result > "3" Then
            tot3 = dt.Rows(3)("unitprc") * dt.Rows(3)("unitqty")
            Panel4.Visible = True
            lblsht4.Text = dt.Rows(3)("shorttext")

            lblgl4.Text = dt.Rows(3)("glacct")
            lblqty4.Text = dt.Rows(3)("unitqty")
            lblprice4.Text = dt.Rows(3)("unitprc")
            lbluom4.Text = dt.Rows(3)("uom")
            lbltot4.Text = String.Format("${0:0.00}", tot3)
            lbltax4.Text = dt.Rows(3)("taxflag")
            lbldelv4.Text = dt.Rows(3)("dlvdate")
            If Not IsDBNull(dt.Rows(3)("venitem")) Then
                lblvenmat4.Text = dt.Rows(3)("venitem")
            Else
                lblvenmat4.Text = ""
            End If
            If Not IsDBNull(dt.Rows(3)("refpart")) Then
                lbltrackno4.Text = dt.Rows(3)("refpart")
            Else
                lbltrackno4.Text = ""
            End If
            If Not IsDBNull(dt.Rows(3)("longtext")) Then
                lbllng4.Text = dt.Rows(3)("longtext")
            Else
                lbllng4.Text = ""
            End If
        End If
        If result > "4" Then
            tot4 = dt.Rows(4)("unitprc") * dt.Rows(4)("unitqty")
            Panel5.Visible = True
            lblsht5.Text = dt.Rows(4)("shorttext")

            lblgl5.Text = dt.Rows(4)("glacct")
            lblqty5.Text = dt.Rows(4)("unitqty")
            lblprice5.Text = dt.Rows(4)("unitprc")
            lbluom5.Text = dt.Rows(4)("uom")
            lbltot5.Text = String.Format("${0:0.00}", tot4)
            lbltax5.Text = dt.Rows(4)("taxflag")
            lbldelv5.Text = dt.Rows(4)("dlvdate")
            If Not IsDBNull(dt.Rows(4)("venitem")) Then
                lblvenmat5.Text = dt.Rows(4)("venitem")
            Else
                lblvenmat5.Text = ""
            End If
            If Not IsDBNull(dt.Rows(4)("refpart")) Then
                lbltrackno5.Text = dt.Rows(4)("refpart")
            Else
                lbltrackno5.Text = ""
            End If
            If Not IsDBNull(dt.Rows(4)("longtext")) Then
                lbllng5.Text = dt.Rows(4)("longtext")
            Else
                lbllng5.Text = ""
            End If
        End If
        If result > "5" Then
            tot5 = dt.Rows(5)("unitprc") * dt.Rows(5)("unitqty")
            Panel6.Visible = True
            lblsht6.Text = dt.Rows(5)("shorttext")

            lblgl6.Text = dt.Rows(5)("glacct")
            lblqty6.Text = dt.Rows(5)("unitqty")
            lblprice6.Text = dt.Rows(5)("unitprc")
            lbluom6.Text = dt.Rows(5)("uom")
            lbltot6.Text = String.Format("${0:0.00}", tot5)
            lbltax6.Text = dt.Rows(5)("taxflag")
            lbldelv6.Text = dt.Rows(5)("dlvdate")
            If Not IsDBNull(dt.Rows(5)("venitem")) Then
                lblvenmat6.Text = dt.Rows(5)("venitem")
            Else
                lblvenmat6.Text = ""
            End If
            If Not IsDBNull(dt.Rows(5)("refpart")) Then
                lbltrackno6.Text = dt.Rows(5)("refpart")
            Else
                lbltrackno6.Text = ""
            End If
            If Not IsDBNull(dt.Rows(5)("longtext")) Then
                lbllng6.Text = dt.Rows(5)("longtext")
            Else
                lbllng6.Text = ""
            End If
        End If
        If result > "6" Then
            tot6 = dt.Rows(6)("unitprc") * dt.Rows(6)("unitqty")
            Panel7.Visible = True
            lblsht7.Text = dt.Rows(6)("shorttext")

            lblgl7.Text = dt.Rows(6)("glacct")
            lblqty7.Text = dt.Rows(6)("unitqty")
            lblprice7.Text = dt.Rows(6)("unitprc")
            lbluom7.Text = dt.Rows(6)("uom")
            lbltot7.Text = String.Format("${0:0.00}", tot6)
            lbltax7.Text = dt.Rows(6)("taxflag")
            lbldelv7.Text = dt.Rows(6)("dlvdate")
            If Not IsDBNull(dt.Rows(6)("venitem")) Then
                lblvenmat7.Text = dt.Rows(6)("venitem")
            Else
                lblvenmat7.Text = ""
            End If
            If Not IsDBNull(dt.Rows(6)("refpart")) Then
                lbltrackno7.Text = dt.Rows(6)("refpart")
            Else
                lbltrackno7.Text = ""
            End If
            If Not IsDBNull(dt.Rows(6)("longtext")) Then
                lbllng7.Text = dt.Rows(6)("longtext")
            Else
                lbllng7.Text = ""
            End If
        End If
        If result > "7" Then
            tot7 = dt.Rows(7)("unitprc") * dt.Rows(7)("unitqty")
            Panel8.Visible = True
            lblsht8.Text = dt.Rows(7)("shorttext")

            lblgl8.Text = dt.Rows(7)("glacct")
            lblqty8.Text = dt.Rows(7)("unitqty")
            lblprice8.Text = dt.Rows(7)("unitprc")
            lbluom8.Text = dt.Rows(7)("uom")
            lbltot8.Text = String.Format("${0:0.00}", tot7)
            lbltax8.Text = dt.Rows(7)("taxflag")
            lbldelv8.Text = dt.Rows(7)("dlvdate")
            If Not IsDBNull(dt.Rows(7)("venitem")) Then
                lblvenmat8.Text = dt.Rows(7)("venitem")
            Else
                lblvenmat8.Text = ""
            End If
            If Not IsDBNull(dt.Rows(7)("refpart")) Then
                lbltrackno8.Text = dt.Rows(7)("refpart")
            Else
                lbltrackno8.Text = ""
            End If
            If Not IsDBNull(dt.Rows(7)("longtext")) Then
                lbllng8.Text = dt.Rows(7)("longtext")
            Else
                lbllng8.Text = ""
            End If
        End If
        If result > "8" Then
            tot8 = dt.Rows(8)("unitprc") * dt.Rows(8)("unitqty")
            Panel9.Visible = True
            lblsht9.Text = dt.Rows(8)("shorttext")

            lblgl9.Text = dt.Rows(8)("glacct")
            lblqty9.Text = dt.Rows(8)("unitqty")
            lblprice9.Text = dt.Rows(8)("unitprc")
            lbluom9.Text = dt.Rows(8)("uom")
            lbltot9.Text = String.Format("${0:0.00}", tot8)
            lbltax9.Text = dt.Rows(8)("taxflag")
            lbldelv9.Text = dt.Rows(8)("dlvdate")
            If Not IsDBNull(dt.Rows(8)("venitem")) Then
                lblvenmat9.Text = dt.Rows(8)("venitem")
            Else
                lblvenmat9.Text = ""
            End If
            If Not IsDBNull(dt.Rows(8)("refpart")) Then
                lbltrackno9.Text = dt.Rows(8)("refpart")
            Else
                lbltrackno9.Text = ""
            End If
            If Not IsDBNull(dt.Rows(8)("longtext")) Then
                lbllng9.Text = dt.Rows(8)("longtext")
            Else
                lbllng9.Text = ""
            End If
        End If
        If result > "9" Then
            tot9 = dt.Rows(9)("unitprc") * dt.Rows(9)("unitqty")
            Panel10.Visible = True
            lblsht10.Text = dt.Rows(9)("shorttext")

            lblgl10.Text = dt.Rows(9)("glacct")
            lblqty10.Text = dt.Rows(9)("unitqty")
            lblprice10.Text = dt.Rows(9)("unitprc")
            lbluom10.Text = dt.Rows(9)("uom")
            lbltot10.Text = String.Format("${0:0.00}", tot9)
            lbltax10.Text = dt.Rows(9)("taxflag")
            lbldelv10.Text = dt.Rows(9)("dlvdate")
            If Not IsDBNull(dt.Rows(9)("venitem")) Then
                lblvenmat10.Text = dt.Rows(9)("venitem")
            Else
                lblvenmat10.Text = ""
            End If
            If Not IsDBNull(dt.Rows(9)("refpart")) Then
                lbltrackno10.Text = dt.Rows(9)("refpart")
            Else
                lbltrackno10.Text = ""
            End If
            If Not IsDBNull(dt.Rows(9)("longtext")) Then
                lbllng10.Text = dt.Rows(9)("longtext")
            Else
                lbllng10.Text = ""
            End If
        End If
        If result > "10" Then
            tot10 = dt.Rows(10)("unitprc") * dt.Rows(10)("unitqty")
            Panel11.Visible = True
            lblsht11.Text = dt.Rows(10)("shorttext")

            lblgl11.Text = dt.Rows(10)("glacct")
            lblqty11.Text = dt.Rows(10)("unitqty")
            lblprice11.Text = dt.Rows(10)("unitprc")
            lbluom11.Text = dt.Rows(10)("uom")
            lbltot11.Text = String.Format("${0:0.00}", tot10)
            lbltax11.Text = dt.Rows(10)("taxflag")
            lbldelv11.Text = dt.Rows(10)("dlvdate")
            If Not IsDBNull(dt.Rows(10)("venitem")) Then
                lblvenmat11.Text = dt.Rows(10)("venitem")
            Else
                lblvenmat11.Text = ""
            End If
            If Not IsDBNull(dt.Rows(10)("refpart")) Then
                lbltrackno11.Text = dt.Rows(10)("refpart")
            Else
                lbltrackno11.Text = ""
            End If
            If Not IsDBNull(dt.Rows(10)("longtext")) Then
                lbllng11.Text = dt.Rows(10)("longtext")
            Else
                lbllng11.Text = ""
            End If
        End If
        If result > "11" Then
            tot11 = dt.Rows(11)("unitprc") * dt.Rows(11)("unitqty")
            Panel12.Visible = True
            lblsht12.Text = dt.Rows(11)("shorttext")

            lblgl12.Text = dt.Rows(11)("glacct")
            lblqty12.Text = dt.Rows(11)("unitqty")
            lblprice12.Text = dt.Rows(11)("unitprc")
            lbluom12.Text = dt.Rows(11)("uom")
            lbltot12.Text = String.Format("${0:0.00}", tot11)
            lbltax12.Text = dt.Rows(11)("taxflag")
            lbldelv12.Text = dt.Rows(11)("dlvdate")
            If Not IsDBNull(dt.Rows(11)("venitem")) Then
                lblvenmat12.Text = dt.Rows(11)("venitem")
            Else
                lblvenmat12.Text = ""
            End If
            If Not IsDBNull(dt.Rows(11)("refpart")) Then
                lbltrackno12.Text = dt.Rows(11)("refpart")
            Else
                lbltrackno12.Text = ""
            End If
            If Not IsDBNull(dt.Rows(11)("longtext")) Then
                lbllng12.Text = dt.Rows(11)("longtext")
            Else
                lbllng12.Text = ""
            End If
        End If
        If result > "12" Then
            tot12 = dt.Rows(12)("unitprc") * dt.Rows(12)("unitqty")
            Panel13.Visible = True
            lblsht13.Text = dt.Rows(12)("shorttext")

            lblgl13.Text = dt.Rows(12)("glacct")
            lblqty13.Text = dt.Rows(12)("unitqty")
            lblprice13.Text = dt.Rows(12)("unitprc")
            lbluom13.Text = dt.Rows(12)("uom")
            lbltot13.Text = String.Format("${0:0.00}", tot12)
            lbltax13.Text = dt.Rows(12)("taxflag")
            lbldelv13.Text = dt.Rows(12)("dlvdate")
            If Not IsDBNull(dt.Rows(12)("venitem")) Then
                lblvenmat13.Text = dt.Rows(12)("venitem")
            Else
                lblvenmat13.Text = ""
            End If
            If Not IsDBNull(dt.Rows(12)("refpart")) Then
                lbltrackno13.Text = dt.Rows(12)("refpart")
            Else
                lbltrackno13.Text = ""
            End If
            If Not IsDBNull(dt.Rows(12)("longtext")) Then
                lbllng13.Text = dt.Rows(12)("longtext")
            Else
                lbllng13.Text = ""
            End If
        End If
        If result > "13" Then
            tot13 = dt.Rows(13)("unitprc") * dt.Rows(13)("unitqty")
            Panel14.Visible = True
            lblsht14.Text = dt.Rows(13)("shorttext")

            lblgl14.Text = dt.Rows(13)("glacct")
            lblqty14.Text = dt.Rows(13)("unitqty")
            lblprice14.Text = dt.Rows(13)("unitprc")
            lbluom14.Text = dt.Rows(13)("uom")
            lbltot14.Text = String.Format("${0:0.00}", tot13)
            lbltax14.Text = dt.Rows(13)("taxflag")
            lbldelv14.Text = dt.Rows(13)("dlvdate")
            If Not IsDBNull(dt.Rows(13)("venitem")) Then
                lblvenmat14.Text = dt.Rows(13)("venitem")
            Else
                lblvenmat14.Text = ""
            End If
            If Not IsDBNull(dt.Rows(13)("refpart")) Then
                lbltrackno14.Text = dt.Rows(13)("refpart")
            Else
                lbltrackno14.Text = ""
            End If
            If Not IsDBNull(dt.Rows(13)("longtext")) Then
                lbllng14.Text = dt.Rows(13)("longtext")
            Else
                lbllng14.Text = ""
            End If
        End If
        If result > "14" Then
            tot14 = dt.Rows(14)("unitprc") * dt.Rows(14)("unitqty")
            Panel15.Visible = True
            lblsht15.Text = dt.Rows(14)("shorttext")

            lblgl15.Text = dt.Rows(14)("glacct")
            lblqty15.Text = dt.Rows(14)("unitqty")
            lblprice15.Text = dt.Rows(14)("unitprc")
            lbluom15.Text = dt.Rows(14)("uom")
            lbltot15.Text = String.Format("${0:0.00}", tot14)
            lbltax15.Text = dt.Rows(14)("taxflag")
            lbldelv15.Text = dt.Rows(14)("dlvdate")
            If Not IsDBNull(dt.Rows(14)("venitem")) Then
                lblvenmat15.Text = dt.Rows(14)("venitem")
            Else
                lblvenmat15.Text = ""
            End If
            If Not IsDBNull(dt.Rows(14)("refpart")) Then
                lbltrackno15.Text = dt.Rows(14)("refpart")
            Else
                lbltrackno15.Text = ""
            End If
            If Not IsDBNull(dt.Rows(14)("longtext")) Then
                lbllng15.Text = dt.Rows(14)("longtext")
            Else
                lbllng15.Text = ""
            End If
        End If
        If result > "15" Then
            tot15 = dt.Rows(15)("unitprc") * dt.Rows(15)("unitqty")
            Panel16.Visible = True
            lblsht16.Text = dt.Rows(15)("shorttext")

            lblgl16.Text = dt.Rows(15)("glacct")
            lblqty16.Text = dt.Rows(15)("unitqty")
            lblprice16.Text = dt.Rows(15)("unitprc")
            lbluom16.Text = dt.Rows(15)("uom")
            lbltot16.Text = String.Format("${0:0.00}", tot15)
            lbltax16.Text = dt.Rows(15)("taxflag")
            lbldelv16.Text = dt.Rows(15)("dlvdate")
            If Not IsDBNull(dt.Rows(15)("venitem")) Then
                lblvenmat16.Text = dt.Rows(15)("venitem")
            Else
                lblvenmat16.Text = ""
            End If
            If Not IsDBNull(dt.Rows(15)("refpart")) Then
                lbltrackno16.Text = dt.Rows(15)("refpart")
            Else
                lbltrackno16.Text = ""
            End If
            If Not IsDBNull(dt.Rows(15)("longtext")) Then
                lbllng16.Text = dt.Rows(15)("longtext")
            Else
                lbllng16.Text = ""
            End If
        End If
        If result > "16" Then
            tot16 = dt.Rows(16)("unitprc") * dt.Rows(16)("unitqty")
            Panel17.Visible = True
            lblsht17.Text = dt.Rows(16)("shorttext")

            lblgl17.Text = dt.Rows(16)("glacct")
            lblqty17.Text = dt.Rows(16)("unitqty")
            lblprice17.Text = dt.Rows(16)("unitprc")
            lbluom17.Text = dt.Rows(16)("uom")
            lbltot17.Text = String.Format("${0:0.00}", tot16)
            lbltax17.Text = dt.Rows(16)("taxflag")
            lbldelv17.Text = dt.Rows(16)("dlvdate")
            If Not IsDBNull(dt.Rows(16)("venitem")) Then
                lblvenmat17.Text = dt.Rows(16)("venitem")
            Else
                lblvenmat17.Text = ""
            End If
            If Not IsDBNull(dt.Rows(16)("refpart")) Then
                lbltrackno17.Text = dt.Rows(16)("refpart")
            Else
                lbltrackno17.Text = ""
            End If
            If Not IsDBNull(dt.Rows(16)("longtext")) Then
                lbllng17.Text = dt.Rows(16)("longtext")
            Else
                lbllng17.Text = ""
            End If
        End If
        If result > "17" Then
            tot17 = dt.Rows(17)("unitprc") * dt.Rows(17)("unitqty")
            Panel18.Visible = True
            lblsht18.Text = dt.Rows(17)("shorttext")

            lblgl18.Text = dt.Rows(17)("glacct")
            lblqty18.Text = dt.Rows(17)("unitqty")
            lblprice18.Text = dt.Rows(17)("unitprc")
            lbluom18.Text = dt.Rows(17)("uom")
            lbltot18.Text = String.Format("${0:0.00}", tot17)
            lbltax18.Text = dt.Rows(17)("taxflag")
            lbldelv18.Text = dt.Rows(17)("dlvdate")
            If Not IsDBNull(dt.Rows(17)("venitem")) Then
                lblvenmat18.Text = dt.Rows(17)("venitem")
            Else
                lblvenmat18.Text = ""
            End If
            If Not IsDBNull(dt.Rows(17)("refpart")) Then
                lbltrackno18.Text = dt.Rows(17)("refpart")
            Else
                lbltrackno18.Text = ""
            End If
            If Not IsDBNull(dt.Rows(17)("longtext")) Then
                lbllng18.Text = dt.Rows(17)("longtext")
            Else
                lbllng18.Text = ""
            End If
        End If
        If result > "18" Then
            tot18 = dt.Rows(18)("unitprc") * dt.Rows(18)("unitqty")
            Panel19.Visible = True
            lblsht19.Text = dt.Rows(18)("shorttext")

            lblgl19.Text = dt.Rows(18)("glacct")
            lblqty19.Text = dt.Rows(18)("unitqty")
            lblprice19.Text = dt.Rows(18)("unitprc")
            lbluom19.Text = dt.Rows(18)("uom")
            lbltot19.Text = String.Format("${0:0.00}", tot18)
            lbltax19.Text = dt.Rows(18)("taxflag")
            lbldelv19.Text = dt.Rows(18)("dlvdate")
            If Not IsDBNull(dt.Rows(18)("venitem")) Then
                lblvenmat19.Text = dt.Rows(18)("venitem")
            Else
                lblvenmat19.Text = ""
            End If
            If Not IsDBNull(dt.Rows(18)("refpart")) Then
                lbltrackno19.Text = dt.Rows(18)("refpart")
            Else
                lbltrackno19.Text = ""
            End If
            If Not IsDBNull(dt.Rows(18)("longtext")) Then
                lbllng19.Text = dt.Rows(18)("longtext")
            Else
                lbllng19.Text = ""
            End If
        End If
        If result > "19" Then
            tot19 = dt.Rows(19)("unitprc") * dt.Rows(19)("unitqty")
            Panel20.Visible = True
            lblsht20.Text = dt.Rows(19)("shorttext")

            lblgl20.Text = dt.Rows(19)("glacct")
            lblqty20.Text = dt.Rows(19)("unitqty")
            lblprice20.Text = dt.Rows(19)("unitprc")
            lbluom20.Text = dt.Rows(19)("uom")
            lbltot20.Text = String.Format("${0:0.00}", tot19)
            lbltax20.Text = dt.Rows(19)("taxflag")
            lbldelv20.Text = dt.Rows(19)("dlvdate")
            If Not IsDBNull(dt.Rows(19)("venitem")) Then
                lblvenmat20.Text = dt.Rows(19)("venitem")
            Else
                lblvenmat20.Text = ""
            End If
            If Not IsDBNull(dt.Rows(19)("refpart")) Then
                lbltrackno20.Text = dt.Rows(19)("refpart")
            Else
                lbltrackno20.Text = ""
            End If
            If Not IsDBNull(dt.Rows(19)("longtext")) Then
                lbllng20.Text = dt.Rows(19)("longtext")
            Else
                lbllng20.Text = ""
            End If
        End If
        If result > "20" Then
            tot20 = dt.Rows(20)("unitprc") * dt.Rows(20)("unitqty")
            Panel21.Visible = True
            lblsht21.Text = dt.Rows(20)("shorttext")

            lblgl21.Text = dt.Rows(20)("glacct")
            lblqty21.Text = dt.Rows(20)("unitqty")
            lblprice21.Text = dt.Rows(20)("unitprc")
            lbluom21.Text = dt.Rows(20)("uom")
            lbltot21.Text = String.Format("${0:0.00}", tot20)
            lbltax21.Text = dt.Rows(20)("taxflag")
            lbldelv21.Text = dt.Rows(20)("dlvdate")
            If Not IsDBNull(dt.Rows(20)("venitem")) Then
                lblvenmat21.Text = dt.Rows(20)("venitem")
            Else
                lblvenmat21.Text = ""
            End If
            If Not IsDBNull(dt.Rows(20)("refpart")) Then
                lbltrackno21.Text = dt.Rows(20)("refpart")
            Else
                lbltrackno21.Text = ""
            End If
            If Not IsDBNull(dt.Rows(20)("longtext")) Then
                lbllng21.Text = dt.Rows(20)("longtext")
            Else
                lbllng21.Text = ""
            End If
        End If
        If result > "21" Then
            tot21 = dt.Rows(21)("unitprc") * dt.Rows(21)("unitqty")
            Panel22.Visible = True
            lblsht22.Text = dt.Rows(21)("shorttext")

            lblgl22.Text = dt.Rows(21)("glacct")
            lblqty22.Text = dt.Rows(21)("unitqty")
            lblprice22.Text = dt.Rows(21)("unitprc")
            lbluom22.Text = dt.Rows(21)("uom")
            lbltot22.Text = String.Format("${0:0.00}", tot21)
            lbltax22.Text = dt.Rows(21)("taxflag")
            lbldelv22.Text = dt.Rows(21)("dlvdate")
            If Not IsDBNull(dt.Rows(21)("venitem")) Then
                lblvenmat22.Text = dt.Rows(21)("venitem")
            Else
                lblvenmat22.Text = ""
            End If
            If Not IsDBNull(dt.Rows(21)("refpart")) Then
                lbltrackno22.Text = dt.Rows(21)("refpart")
            Else
                lbltrackno22.Text = ""
            End If
            If Not IsDBNull(dt.Rows(21)("longtext")) Then
                lbllng22.Text = dt.Rows(21)("longtext")
            Else
                lbllng22.Text = ""
            End If
        End If
        If result > "22" Then
            tot22 = dt.Rows(22)("unitprc") * dt.Rows(22)("unitqty")
            Panel23.Visible = True
            lblsht23.Text = dt.Rows(22)("shorttext")

            lblgl23.Text = dt.Rows(22)("glacct")
            lblqty23.Text = dt.Rows(22)("unitqty")
            lblprice23.Text = dt.Rows(22)("unitprc")
            lbluom23.Text = dt.Rows(22)("uom")
            lbltot23.Text = String.Format("${0:0.00}", tot22)
            lbltax23.Text = dt.Rows(22)("taxflag")
            lbldelv23.Text = dt.Rows(22)("dlvdate")
            If Not IsDBNull(dt.Rows(22)("venitem")) Then
                lblvenmat23.Text = dt.Rows(22)("venitem")
            Else
                lblvenmat23.Text = ""
            End If
            If Not IsDBNull(dt.Rows(22)("refpart")) Then
                lbltrackno23.Text = dt.Rows(22)("refpart")
            Else
                lbltrackno23.Text = ""
            End If
            If Not IsDBNull(dt.Rows(22)("longtext")) Then
                lbllng23.Text = dt.Rows(22)("longtext")
            Else
                lbllng23.Text = ""
            End If
        End If
        If result > "23" Then
            tot23 = dt.Rows(23)("unitprc") * dt.Rows(23)("unitqty")
            Panel24.Visible = True
            lblsht24.Text = dt.Rows(23)("shorttext")

            lblgl24.Text = dt.Rows(23)("glacct")
            lblqty24.Text = dt.Rows(23)("unitqty")
            lblprice24.Text = dt.Rows(23)("unitprc")
            lbluom24.Text = dt.Rows(23)("uom")
            lbltot24.Text = String.Format("${0:0.00}", tot23)
            lbltax24.Text = dt.Rows(23)("taxflag")
            lbldelv24.Text = dt.Rows(23)("dlvdate")
            If Not IsDBNull(dt.Rows(23)("venitem")) Then
                lblvenmat24.Text = dt.Rows(23)("venitem")
            Else
                lblvenmat24.Text = ""
            End If
            If Not IsDBNull(dt.Rows(23)("refpart")) Then
                lbltrackno24.Text = dt.Rows(23)("refpart")
            Else
                lbltrackno24.Text = ""
            End If
            If Not IsDBNull(dt.Rows(23)("longtext")) Then
                lbllng24.Text = dt.Rows(23)("longtext")
            Else
                lbllng24.Text = ""
            End If

        End If
        If result > "24" Then
            tot24 = dt.Rows(24)("unitprc") * dt.Rows(24)("unitqty")
            Panel25.Visible = True
            lblsht25.Text = dt.Rows(24)("shorttext")

            lblgl25.Text = dt.Rows(24)("glacct")
            lblqty25.Text = dt.Rows(24)("unitqty")
            lblprice25.Text = dt.Rows(24)("unitprc")
            lbluom25.Text = dt.Rows(24)("uom")
            lbltot25.Text = String.Format("${0:0.00}", tot24)
            lbltax25.Text = dt.Rows(24)("taxflag")
            lbldelv25.Text = dt.Rows(24)("dlvdate")
            If Not IsDBNull(dt.Rows(24)("venitem")) Then
                lblvenmat25.Text = dt.Rows(24)("venitem")
            Else
                lblvenmat25.Text = ""
            End If
            If Not IsDBNull(dt.Rows(24)("refpart")) Then
                lbltrackno25.Text = dt.Rows(24)("refpart")
            Else
                lbltrackno25.Text = ""
            End If
            If Not IsDBNull(dt.Rows(24)("longtext")) Then
                lbllng25.Text = dt.Rows(24)("longtext")
            Else
                lbllng25.Text = ""
            End If
        End If
        If result > "25" Then
            tot25 = dt.Rows(25)("unitprc") * dt.Rows(25)("unitqty")
            Panel26.Visible = True
            lblsht26.Text = dt.Rows(25)("shorttext")

            lblgl26.Text = dt.Rows(25)("glacct")
            lblqty26.Text = dt.Rows(25)("unitqty")
            lblprice26.Text = dt.Rows(25)("unitprc")
            lbluom26.Text = dt.Rows(25)("uom")
            lbltot26.Text = String.Format("${0:0.00}", tot25)
            lbltax26.Text = dt.Rows(25)("taxflag")
            lbldelv26.Text = dt.Rows(25)("dlvdate")
            If Not IsDBNull(dt.Rows(25)("venitem")) Then
                lblvenmat26.Text = dt.Rows(25)("venitem")
            Else
                lblvenmat26.Text = ""
            End If
            If Not IsDBNull(dt.Rows(25)("refpart")) Then
                lbltrackno26.Text = dt.Rows(25)("refpart")
            Else
                lbltrackno26.Text = ""
            End If
            If Not IsDBNull(dt.Rows(25)("longtext")) Then
                lbllng26.Text = dt.Rows(25)("longtext")
            Else
                lbllng26.Text = ""
            End If
        End If
        If result > "26" Then
            tot26 = dt.Rows(26)("unitprc") * dt.Rows(26)("unitqty")
            Panel27.Visible = True
            lblsht27.Text = dt.Rows(26)("shorttext")

            lblgl27.Text = dt.Rows(26)("glacct")
            lblqty27.Text = dt.Rows(26)("unitqty")
            lblprice27.Text = dt.Rows(26)("unitprc")
            lbluom27.Text = dt.Rows(26)("uom")
            lbltot27.Text = String.Format("${0:0.00}", tot26)
            lbltax27.Text = dt.Rows(26)("taxflag")
            lbldelv27.Text = dt.Rows(26)("dlvdate")
            If Not IsDBNull(dt.Rows(26)("venitem")) Then
                lblvenmat27.Text = dt.Rows(26)("venitem")
            Else
                lblvenmat27.Text = ""
            End If
            If Not IsDBNull(dt.Rows(26)("refpart")) Then
                lbltrackno27.Text = dt.Rows(26)("refpart")
            Else
                lbltrackno27.Text = ""
            End If
            If Not IsDBNull(dt.Rows(26)("longtext")) Then
                lbllng27.Text = dt.Rows(26)("longtext")
            Else
                lbllng27.Text = ""
            End If
        End If
        If result > "27" Then
            tot27 = dt.Rows(27)("unitprc") * dt.Rows(27)("unitqty")
            Panel28.Visible = True
            lblsht28.Text = dt.Rows(27)("shorttext")

            lblgl28.Text = dt.Rows(27)("glacct")
            lblqty28.Text = dt.Rows(27)("unitqty")
            lblprice28.Text = dt.Rows(27)("unitprc")
            lbluom28.Text = dt.Rows(27)("uom")
            lbltot28.Text = String.Format("${0:0.00}", tot27)
            lbltax28.Text = dt.Rows(27)("taxflag")
            lbldelv28.Text = dt.Rows(27)("dlvdate")
            If Not IsDBNull(dt.Rows(27)("venitem")) Then
                lblvenmat28.Text = dt.Rows(27)("venitem")
            Else
                lblvenmat28.Text = ""
            End If
            If Not IsDBNull(dt.Rows(27)("refpart")) Then
                lbltrackno28.Text = dt.Rows(27)("refpart")
            Else
                lbltrackno28.Text = ""
            End If
            If Not IsDBNull(dt.Rows(27)("longtext")) Then
                lbllng28.Text = dt.Rows(27)("longtext")
            Else
                lbllng28.Text = ""
            End If
        End If
        If result > "28" Then
            tot28 = dt.Rows(28)("unitprc") * dt.Rows(28)("unitqty")
            Panel29.Visible = True
            lblsht29.Text = dt.Rows(28)("shorttext")

            lblgl29.Text = dt.Rows(28)("glacct")
            lblqty29.Text = dt.Rows(28)("unitqty")
            lblprice29.Text = dt.Rows(28)("unitprc")
            lbluom29.Text = dt.Rows(28)("uom")
            lbltot29.Text = String.Format("${0:0.00}", tot28)
            lbltax29.Text = dt.Rows(28)("taxflag")
            lbldelv29.Text = dt.Rows(28)("dlvdate")
            If Not IsDBNull(dt.Rows(28)("venitem")) Then
                lblvenmat29.Text = dt.Rows(28)("venitem")
            Else
                lblvenmat29.Text = ""
            End If
            If Not IsDBNull(dt.Rows(28)("refpart")) Then
                lbltrackno29.Text = dt.Rows(28)("refpart")
            Else
                lbltrackno29.Text = ""
            End If
            If Not IsDBNull(dt.Rows(28)("longtext")) Then
                lbllng29.Text = dt.Rows(28)("longtext")
            Else
                lbllng29.Text = ""
            End If
        End If
        If result > "29" Then
            tot29 = dt.Rows(29)("unitprc") * dt.Rows(29)("unitqty")
            Panel30.Visible = True
            lblsht30.Text = dt.Rows(29)("shorttext")

            lblgl30.Text = dt.Rows(29)("glacct")
            lblqty30.Text = dt.Rows(29)("unitqty")
            lblprice30.Text = dt.Rows(29)("unitprc")
            lbluom30.Text = dt.Rows(29)("uom")
            lbltot30.Text = String.Format("${0:0.00}", tot29)
            lbltax30.Text = dt.Rows(29)("taxflag")
            lbldelv30.Text = dt.Rows(29)("dlvdate")
            If Not IsDBNull(dt.Rows(29)("venitem")) Then
                lblvenmat30.Text = dt.Rows(29)("venitem")
            Else
                lblvenmat30.Text = ""
            End If
            If Not IsDBNull(dt.Rows(29)("refpart")) Then
                lbltrackno30.Text = dt.Rows(29)("refpart")
            Else
                lbltrackno30.Text = ""
            End If
            If Not IsDBNull(dt.Rows(29)("longtext")) Then
                lbllng30.Text = dt.Rows(29)("longtext")
            Else
                lbllng30.Text = ""
            End If
        End If


        'cmd.Connection = con
        'cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
        'Dim result As Object = cmd.ExecuteScalar
        'lblresult.Text = String.Format(result) + 1
        'cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.Text & "', '" & ddlcpfr.SelectedValue & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "','" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "')"
        'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate, subdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddlcpfr.Text & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "','" & DateTime.Now & "')"
        'cmd.ExecuteNonQuery()
        con.Close()

    End Sub


    Protected Sub btncopy_Click(sender As Object, e As System.EventArgs) Handles btncopy.Click
        Response.Redirect("~/Hcopy.aspx")

    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim IDno As String = CType(Session.Item("IDno"), String)
        Response.Redirect("/data/poreq/" & IDno)
    End Sub
End Class
