﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PurchReqV2.Controllers;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;

namespace PurchReqV2
{
    public partial class PurchaseRequisitions : PurchReqV2BasePage
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private PurchaseRequisitionsController _controller;

        #endregion

        #endregion

        #region Methods

        #region Public/Protected Methods

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Page.Title = "Purchase Requisitions";
                _controller = new PurchaseRequisitionsController(HttpContext.Current.User.Identity.Name);
                
                if (!IsPostBack)
                {
                    ddlAddPurchReqPurchasingGroup.DataBind();
                    ddlAddPurchReqCpfrNo.DataBind();
                    ddlAddPurchReqCostCenter.DataBind();
                    ddlAddPurchReqGlAccount.DataBind();
                    ddlAddPurchReqVendor.DataBind();
                    gvAddPurchReq.DataBind();
                    pnlCostCenter.Visible = false;
                //    txtAddPurchReqDeliveryDate.Text = _controller.GetNextNonHolidayOrWeekendDate(DateTime.Now.AddDays(30)).ToString("MM/dd/yyyy");
                    txtAddPurchReqDeliveryDate.Text = _controller.GetNextNonHolidayOrWeekendDate(DateTime.Now).ToString("MM/dd/yyyy");
                }

                HandlePurchasingGroupChange(ddlAddPurchReqPurchasingGroup.SelectedValue);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #region Add PurchaseRequisition Section

        /// <summary>
        /// Handles the ContextCreating event of the ldsPurchaseRequisitions control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsPurchaseRequisitions_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the ContextCreating event of the ldsDdlAddPurchReqCpfrNo control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqCpfrNo_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlAddPurchReqCpfrNo control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqCpfrNo_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetAllCpfrs(ddlAddPurchReqPurchasingGroup.SelectedValue);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the selecting command of the drop-down list for CPFR's in the Requisition GridView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ldsDdlGvAddPurchReqCpfrNo_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                var ddlPurchasingGroup = Extensions.FindControlRecursive(gvAddPurchReq, "ddlGvAddPurchReqPurchasingGroup") as DropDownList;
                var cpfrs = _controller.GetAllCpfrs(ddlPurchasingGroup.SelectedValue);
                if (cpfrs.Count == 0)
                {
                    var cpfr = new PurchReq_Cpfr();
                    cpfr.CPFRNO = " ";
                    cpfrs.Add(cpfr);
                }
                e.Result = cpfrs;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the ContextCreating event of the ldsDdlAddPurchReqVendor control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqVendor_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlAddPurchReqVendor control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqVendor_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetAllVendors();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the ContextCreating event of the ldsDdlAddPurchReqCostCenter control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqCostCenter_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlAddPurchReqCostCenter control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqCostCenter_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                e.Result = _controller.GetAllCostCenters(ddlAddPurchReqPurchasingGroup.SelectedValue);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ldsDdlGvAddPurchReqCostCenter_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                var ddlPurchasingGroup = Extensions.FindControlRecursive(gvAddPurchReq, "ddlGvAddPurchReqPurchasingGroup") as DropDownList;
                var costCenters = _controller.GetAllCostCenters(ddlPurchasingGroup.SelectedValue);
                if (costCenters.Count == 0)
                {
                    var costCenter = new PurchReq_CostCenter();
                    costCenter.CCNUMBER = " ";
                    costCenters.Add(costCenter);
                }
                e.Result = costCenters;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the ContextCreating event of the ldsDdlAddPurchReqGlAccount control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqGlAccount_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlAddPurchReqGlAccount control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqGlAccount_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                var glType = _controller.GetGlTypeFromPurGroup(ddlAddPurchReqPurchasingGroup.SelectedValue);
                e.Result = _controller.GetAllGlAccounts(glType);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Populates the GL Type drop-down while editing the Purchase Requisition grid.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ldsDdlGvAddPurchReqGlAccount_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                var ddlPurchasingGroup = Extensions.FindControlRecursive(gvAddPurchReq, "ddlGvAddPurchReqPurchasingGroup") as DropDownList;
                var glType = _controller.GetGlTypeFromPurGroup(ddlPurchasingGroup.SelectedValue);
                e.Result = _controller.GetAllGlAccounts(glType);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the ContextCreating event of the ldsDdlAddPurchReqPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceContextEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqPurchaseRequisition_ContextCreating(object sender, LinqDataSourceContextEventArgs e)
        {
            try
            {
                e.ObjectInstance = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnSelecting event of the ldsDdlAddPurchReqPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceSelectEventArgs"/> instance containing the event data.</param>
        protected void ldsDdlAddPurchReqPurchaseRequisition_OnSelecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            try
            {
                if (Session["CopiedRequisition"] != null)
                {
                    var firstLine = 0;
                    var copiedRequisition = Session["CopiedRequisition"] as List<PurchReq_PurchaseRequisition>;
                    var stagedRequisition = new List<PurchReq_PurchaseRequisitionStaging>();
                    var firstLineItem = copiedRequisition[firstLine];
                    _controller.DeleteStagedPurchaseRequisitionsBySessionID(Session.SessionID);

                    LockDropDownsForPopulatedRequisition(firstLineItem);

                    foreach (var item in copiedRequisition)
                    {
                        var status = "1";
                        var newRequisition = new PurchReq_PurchaseRequisitionStaging();
                        newRequisition.SESSIONID = Session.SessionID;
                        newRequisition.TOTAL = Convert.ToDecimal(item.UNITPRC) * Convert.ToDecimal(item.UNITQTY);
                        newRequisition.UNITQTY = item.UNITQTY;
                        newRequisition.UNITPRC = item.UNITPRC;
                        newRequisition.LONGTEXT = item.LONGTEXT;
                        newRequisition.SHORTTEXT = item.SHORTTEXT;
                        newRequisition.ACCTCAT = item.ACCTCAT;
                        newRequisition.CCenter = item.CCenter;
                        newRequisition.CPFR = item.CPFR;
                        newRequisition.CRTDT = DateTime.Now.ToString("MM/dd/yyyy");
                        newRequisition.DLVDATE = _controller.GetNextNonHolidayOrWeekendDate(DateTime.Now.AddDays(30)).ToString("MM/dd/yyyy");
                        newRequisition.GLACCT = item.GLACCT;
                        newRequisition.HDRTEXT = item.HDRTEXT;
                        newRequisition.LINESEQ = item.LINESEQ;
                        newRequisition.LINESTS = item.LINESTS;
                        newRequisition.PURGROUP = item.PURGROUP;
                        newRequisition.REFPART = item.REFPART;
                        newRequisition.REQEMAIL = String.Format("{0}{1}", _controller.GetUserNameWithoutDomain(HttpContext.Current.User.Identity.Name), Config.DefaultEmailTail);
                        newRequisition.REQUSER = _controller.GetUserNameWithoutDomain(HttpContext.Current.User.Identity.Name);
                        newRequisition.VENITEM = item.VENITEM;
                        newRequisition.VENDOR = item.VENDOR;
                        newRequisition.UOM = item.UOM;
                        newRequisition.TAXFLAG = item.TAXFLAG;
                        newRequisition.STATUS = status;
                        newRequisition.SEQLINE = Convert.ToInt64(item.SEQLINE);

                        stagedRequisition.Add(newRequisition);
                        _controller.UpsertPurchaseRequisitionStaging(newRequisition);

                        AddToRequisitionTotal(newRequisition.TOTAL ?? 0); 
                    }
                    e.Result = stagedRequisition;
                    Session["CopiedRequisition"] = null;
                }
                else if (Session["CopiedRequisitionHistorical"] != null)
                {
                    var copiedRequisition = Session["CopiedRequisitionHistorical"] as List<PurchReq_HistoricalPurchaseRequisition>;
                    var stagedRequisition = new List<PurchReq_PurchaseRequisitionStaging>();
                    var firstLineItem = copiedRequisition[0];

                    LockDropDownsForPopulatedRequisition(firstLineItem);

                    _controller.DeleteStagedPurchaseRequisitionsBySessionID(Session.SessionID);

                    foreach (var item in copiedRequisition)
                    {
                        var status = "1";
                        var newRequisition = new PurchReq_PurchaseRequisitionStaging();
                        newRequisition.SESSIONID = Session.SessionID;
                        newRequisition.TOTAL = Convert.ToDecimal(item.UNITPRC) * Convert.ToDecimal(item.UNITQTY);
                        newRequisition.UNITQTY = item.UNITQTY;
                        newRequisition.UNITPRC = item.UNITPRC;
                        newRequisition.LONGTEXT = item.LONGTEXT;
                        newRequisition.SHORTTEXT = item.SHORTTEXT;
                        newRequisition.ACCTCAT = item.ACCTCAT;
                        newRequisition.CCenter = item.CCenter;
                        newRequisition.CPFR = item.CPFR;
                        newRequisition.CRTDT = DateTime.Now.ToString("MM/dd/yyyy");
                        newRequisition.DLVDATE = _controller.GetNextNonHolidayOrWeekendDate(DateTime.Now.AddDays(30)).ToString("MM/dd/yyyy");
                        newRequisition.GLACCT = item.GLACCT;
                        newRequisition.HDRTEXT = item.HDRTEXT;
                        newRequisition.LINESEQ = item.LINESEQ;
                        newRequisition.LINESTS = item.LINESTS;
                        newRequisition.PURGROUP = item.PURGROUP;
                        newRequisition.REFPART = item.REFPART;
                        newRequisition.REQEMAIL = String.Format("{0}{1}", _controller.GetUserNameWithoutDomain(HttpContext.Current.User.Identity.Name), Config.DefaultEmailTail);
                        newRequisition.REQUSER = _controller.GetUserNameWithoutDomain(HttpContext.Current.User.Identity.Name);
                        newRequisition.VENITEM = item.VENITEM;
                        newRequisition.VENDOR = item.VENDOR;
                        newRequisition.UOM = item.UOM;
                        newRequisition.TAXFLAG = item.TAXFLAG;
                        newRequisition.STATUS = status;
                        newRequisition.SEQLINE = Convert.ToInt64(item.SEQLINE);

                        stagedRequisition.Add(newRequisition);
                        _controller.UpsertPurchaseRequisitionStaging(newRequisition);
                        AddToRequisitionTotal(newRequisition.TOTAL ?? 0);
                    }
                    e.Result = stagedRequisition;
                    Session["CopiedRequisitionHistorical"] = null;
                }
                else
                {
                    var gottenReqs = _controller.GetStagedPurchaseRequisitions(Session.SessionID);

                    foreach(var req in gottenReqs)
                    {
                        req.TOTAL = (Convert.ToDecimal(req.UNITQTY, CultureInfo.InvariantCulture) * Convert.ToDecimal(req.UNITPRC, CultureInfo.InvariantCulture));
                    }

                    e.Result = gottenReqs;
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnAddPurchReqSubmit control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnAddPurchReqSubmit_OnClick(object sender, EventArgs e)
        {
            try
            {
                _controller.MigrateStagingPurchaseRequisitionToProduction(Session.SessionID);
                gvAddPurchReq.DataBind();
                ResetAddPurchaseRequisitionOnGridEmpty();
                DisplayMessage("Success!", MessageType.Success);
                lblRequisitionTotal.Text = @"$0.00";
                return;
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnAddPurchReqCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnAddPurchReqCancel_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearAddToStagingPurchaseRequisitionGrid();
                _controller.DeleteStagedPurchaseRequisitionsBySessionID(Session.SessionID);
                LockDropDownsForPopulatedRequisition(null, true);
                lblRequisitionTotal.Text = @"$0.00";
                txtAddPurchReqHeaderText.Text = String.Empty;
                gvAddPurchReq.DataBind();
                ResetAddPurchaseRequisitionOnGridEmpty();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupCancelAddPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupCancelAddPurchaseRequisition_OnClick(object sender, EventArgs e)
        {
            try
            {
                ClearAddToStagingPurchaseRequisitionGrid(); 
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnPopupAddPurchaseRequisition control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPopupAddPurchaseRequisition_OnClick(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                try
                {
                    if (ddlAddPurchReqGlAccount.SelectedValue.Equals("")) return;

                    var status = @"1";
                    var requisition = new PurchReq_PurchaseRequisitionStaging();
                    requisition.CPFR = string.IsNullOrEmpty(ddlAddPurchReqCpfrNo.SelectedValue) ? " " : ddlAddPurchReqCpfrNo.SelectedValue;
                    requisition.ACCTCAT = Config.DefaultAccountCat;
                    requisition.VENDOR = ddlAddPurchReqVendor.SelectedValue;
                    requisition.REQUSER = _controller.GetUserNameWithoutDomain(HttpContext.Current.User.Identity.Name);
                    requisition.REFPART = txtAddPurchReqTrackingNumber.Text;
                    requisition.UNITPRC = txtAddPurchReqUnitPrice.Text;
                    requisition.UNITQTY = txtAddPurchReqQty.Text;
                    requisition.SHORTTEXT = txtAddPurchReqLineItemText.Text;
                    requisition.LONGTEXT = txtAddPurchReqDescription.Text;
                    requisition.HDRTEXT = txtAddPurchReqHeaderText.Text;
                    requisition.CCenter = String.IsNullOrEmpty(ddlAddPurchReqCostCenter.SelectedValue) ? " " : ddlAddPurchReqCostCenter.SelectedValue;
                    requisition.DLVDATE = _controller.GetNextNonHolidayOrWeekendDate(Convert.ToDateTime(txtAddPurchReqDeliveryDate.Text)).ToString("MM/dd/yyyy");
                    requisition.VENITEM = txtAddPurchReqVendorMaterial.Text;
                    requisition.REQEMAIL = String.Format("{0}{1}", _controller.GetUserNameWithoutDomain(HttpContext.Current.User.Identity.Name), Config.DefaultEmailTail);
                    requisition.CRTDT = DateTime.Now.ToString("MM/dd/yyyy");
                    requisition.UOM = ddlAddPurchReqUom.SelectedValue;
                    requisition.STATUS = status;
                    requisition.TAXFLAG = ddlAddPurchReqTaxable.SelectedValue;
                    requisition.SESSIONID = Session.SessionID;
                    requisition.SEQLINE = _controller.GetNextPurchaseRequisitionStagingSequence(Session.SessionID);
                    requisition.PURGROUP = ddlAddPurchReqPurchasingGroup.SelectedValue;
                    requisition.GLACCT = ddlAddPurchReqGlAccount.SelectedValue;
                    requisition.TOTAL = (Convert.ToDecimal(requisition.UNITQTY, CultureInfo.InvariantCulture) * Convert.ToDecimal(requisition.UNITPRC, CultureInfo.InvariantCulture));

                    _controller.UpsertPurchaseRequisitionStaging(requisition);

                    LockDropDownsForPopulatedRequisition(requisition);
                    AddToRequisitionTotal(requisition.TOTAL ?? 0);
                    gvAddPurchReq.DataBind();
                    ClearAddToStagingPurchaseRequisitionGrid();

                    ddlAddPurchReqPurchasingGroup.Enabled = true;
                    ddlAddPurchReqCpfrNo.Enabled = true;
                    ddlAddPurchReqCostCenter.Enabled = true;
                    ddlAddPurchReqVendor.Enabled = true;
                    ddlAddPurchReqPurchasingGroup.SelectedIndex = -1;
                    ddlAddPurchReqCpfrNo.SelectedIndex = -1;
                    ddlAddPurchReqCostCenter.SelectedIndex = -1;
                    ddlAddPurchReqVendor.SelectedIndex = -1;

                    txtAddPurchReqHeaderText.Enabled = true;
                    txtAddPurchReqHeaderText.Text = string.Empty;

                    DisplayMessage("Success!", MessageType.Success);
                }
                catch (Exception ex)
                {
                    HandleException(ex);
                }
            }
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the ddlAddPurchReqPurchasingGroup control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void ddlAddPurchReqPurchasingGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlAddPurchReqPurchasingGroup.SelectedValue == "MRO")
                {
                    ddlAddPurchReqCostCenter.Visible = true;
                    pnlCostCenter.Visible = true;
                    ddlAddPurchReqCpfrNo.Visible = false;
                    pnlCpfrNumber.Visible = false;
                    ddlAddPurchReqCpfrNo.Items.Clear();

                    ddlAddPurchReqCostCenter.Items.Clear();
                    ddlAddPurchReqCostCenter.DataBind();
                    ddlAddPurchReqCostCenter.Items.Insert(0, new ListItem("Select Cost Center", ""));
                }
                else
                {
                    ddlAddPurchReqCostCenter.Visible = false;
                    pnlCostCenter.Visible = false;
                    pnlCpfrNumber.Visible = true;
                    ddlAddPurchReqCpfrNo.Visible = true;
                    ddlAddPurchReqCostCenter.Items.Clear();

                    ddlAddPurchReqCpfrNo.Items.Clear();
                    ddlAddPurchReqCpfrNo.DataBind();
                    ddlAddPurchReqCpfrNo.Items.Insert(0, new ListItem("Select CPFR NO", ""));
                }

                ddlAddPurchReqGlAccount.Items.Clear();
                ddlAddPurchReqGlAccount.DataBind();
                ddlAddPurchReqGlAccount.Items.Insert(0, new ListItem("Select a GL Account", ""));
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        protected void customValidator_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (txtAddPurchReqUnitPrice.Text == string.Empty)
            {
                customValidator1.ErrorMessage = "Please enter the Purchase Requisition Unit Price.";
                args.IsValid = false;
            }
            else if (Convert.ToDouble(txtAddPurchReqUnitPrice.Text) >= 999999999)
            {
                customValidator1.ErrorMessage = "Unit Price is too long should not be more than 9 digits";
                args.IsValid = false;
            }

            if (!string.IsNullOrEmpty(customValidator1.ErrorMessage))
                customValidator1.ErrorMessage += "\n";

            if (txtAddPurchReqQty.Text == string.Empty)
            {
                customValidator1.ErrorMessage = "Please enter the Purchase Requisition Quantity.";
                args.IsValid = false;
            }
            else if (Convert.ToDouble(txtAddPurchReqQty.Text) >= 999999999)
            {
                customValidator1.ErrorMessage = "Quantity is too long should not be more than 9 digits";
                args.IsValid = false;
            }

            if (Convert.ToDecimal(txtAddPurchReqQty.Text, CultureInfo.InvariantCulture) * Convert.ToDecimal(txtAddPurchReqUnitPrice.Text, CultureInfo.InvariantCulture) > 9999999999)
            {
                customValidator1.ErrorMessage = "Please enter valid Quantity and Unit Price.";
                args.IsValid = false;
            }

        }


        #endregion

        #region Reporting Section

        /// <summary>
        /// Handles the OnClick event of the btnExportPurchaseRequisitions control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="ImageClickEventArgs"/> instance containing the event data.</param>
        protected void btnExportPurchaseRequisitions_OnClick(object sender, ImageClickEventArgs e)
        {
            try
            {
                var result = _controller.GetStagedPurchaseRequisitions(Session.SessionID);
                DownloadExcelWorkbook(_controller.GenerateExcelDocument(result, "Purchase Requisitions"), "PurchaseRequisitions");
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }
        }

        /// <summary>
        /// Handles the Deleting event of the ldsGvAddPurchReq control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceDeleteEventArgs"/> instance containing the event data.</param>
        protected void ldsGvAddPurchReq_Deleting(object sender, LinqDataSourceDeleteEventArgs e)
        {
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                _controller.UpsertPurchaseRequisitionStaging(e.OriginalObject, true);
                var requisitionItem = e.OriginalObject as PurchReq_PurchaseRequisitionStaging;
                AddToRequisitionTotal(-requisitionItem.TOTAL ?? 0);
                e.Cancel = true;
                gvAddPurchReq.DataBind();
                ResetAddPurchaseRequisitionOnGridEmpty();
                DisplayMessage("Success!", MessageType.Success);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the Updating event of the ldsGvAddPurchReq control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="LinqDataSourceUpdateEventArgs"/> instance containing the event data.</param>
        protected void ldsGvAddPurchReq_Updating(object sender, LinqDataSourceUpdateEventArgs e)
        {
            HandlePurchasingGroupChange(ddlAddPurchReqPurchasingGroup.SelectedValue);
            try
            {
                Page.Validate(Config.MainValidationGroup);
                if (!IsValid)
                {
                    e.Cancel = true;
                    return;
                }
                var oldReq = e.OriginalObject as PurchReq_PurchaseRequisitionStaging;
                var newReq = e.NewObject as PurchReq_PurchaseRequisitionStaging;

                if (newReq.GLACCT.Equals("")) return;

                newReq.TOTAL = Convert.ToDecimal(newReq.UNITPRC) * Convert.ToDecimal(newReq.UNITQTY);
                newReq.STATUS = "1";
                _controller.UpsertPurchaseRequisitionStaging(newReq);
                e.Cancel = true;
                
                AddToRequisitionTotal(oldReq.TOTAL == newReq.TOTAL ? 0 : (newReq.TOTAL - oldReq.TOTAL) ?? 0);
                DisplayMessage("Success!", MessageType.Success);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Handles the OnClick event of the btnMoveToHistory control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        public void btnMoveToHistory_OnClick(object sender, EventArgs e)
        {
            Response.Redirect("~/PurchaseRequisitionHistory.aspx");
        }

        #endregion

        #endregion

        #region Private Methods

        private void ClearAddToStagingPurchaseRequisitionGrid()
        {
            txtAddPurchReqDeliveryDate.Text = _controller.GetNextNonHolidayOrWeekendDate(DateTime.Now.AddDays(30)).ToString("MM/dd/yyyy");
            txtAddPurchReqDescription.Text = String.Empty;
            txtAddPurchReqLineItemText.Text = String.Empty;
            txtAddPurchReqQty.Text = String.Empty;
            txtAddPurchReqTrackingNumber.Text = String.Empty;
            txtAddPurchReqUnitPrice.Text = String.Empty;
            txtAddPurchReqVendorMaterial.Text = "";
            ddlAddPurchReqGlAccount.SelectedIndex = 0;
            ddlAddPurchReqTaxable.SelectedIndex = 0;
            ddlAddPurchReqUom.SelectedIndex = 0;
        }

        private void LockDropDownsForPopulatedRequisition(object requisition, bool reset = false)
        {
            var stagingRequisition = requisition as PurchReq_PurchaseRequisitionStaging;
            var historicalRequisition = requisition as PurchReq_HistoricalPurchaseRequisition;
            var releasedRequisition = requisition as PurchReq_PurchaseRequisition;

            if (reset)
            {
                ddlAddPurchReqPurchasingGroup.Enabled = true;
                ddlAddPurchReqCostCenter.Enabled = true;
                ddlAddPurchReqVendor.Enabled = true;
                ddlAddPurchReqCpfrNo.Enabled = true;
                txtAddPurchReqHeaderText.Enabled = true;
                return;
            }

            if (stagingRequisition != null)
            {
                var firstLineItem = stagingRequisition;
                ddlAddPurchReqPurchasingGroup.SelectedValue = firstLineItem.PURGROUP;
                ddlAddPurchReqCostCenter.SelectedValue = firstLineItem.CCenter;
                ddlAddPurchReqVendor.SelectedValue = firstLineItem.VENDOR;
                if(!string.IsNullOrEmpty(firstLineItem.CPFR) && !string.IsNullOrWhiteSpace(firstLineItem.CPFR))
                    ddlAddPurchReqCpfrNo.SelectedValue = firstLineItem.CPFR;
                txtAddPurchReqHeaderText.Text = firstLineItem.HDRTEXT;
                txtAddPurchReqHeaderText.Enabled = false;
                ddlAddPurchReqPurchasingGroup.Enabled = false;
                ddlAddPurchReqCostCenter.Enabled = false;
                ddlAddPurchReqVendor.Enabled = false;
                ddlAddPurchReqCpfrNo.Enabled = false;
            }
            else if (historicalRequisition != null)
            {
                var firstLineItem = historicalRequisition;
                ddlAddPurchReqPurchasingGroup.SelectedValue = firstLineItem.PURGROUP;
                ddlAddPurchReqCostCenter.SelectedValue = firstLineItem.CCenter;
                ddlAddPurchReqVendor.SelectedValue = firstLineItem.VENDOR;
                ddlAddPurchReqCpfrNo.SelectedValue = firstLineItem.CPFR;
                txtAddPurchReqHeaderText.Text = firstLineItem.HDRTEXT;
                txtAddPurchReqHeaderText.Enabled = false;
                ddlAddPurchReqPurchasingGroup.Enabled = false;
                ddlAddPurchReqCostCenter.Enabled = false;
                ddlAddPurchReqVendor.Enabled = false;
                ddlAddPurchReqCpfrNo.Enabled = false;
            }
            else
            {
                var firstLineItem = releasedRequisition;
                if (firstLineItem != null)
                {
                    ddlAddPurchReqPurchasingGroup.SelectedValue = firstLineItem.PURGROUP;
                    ddlAddPurchReqCostCenter.SelectedValue = firstLineItem.CCenter;
                    ddlAddPurchReqVendor.SelectedValue = firstLineItem.VENDOR;
                    ddlAddPurchReqCpfrNo.SelectedValue = firstLineItem.CPFR; 
                    txtAddPurchReqHeaderText.Text = firstLineItem.HDRTEXT;
                }
                ddlAddPurchReqPurchasingGroup.Enabled = false;
                ddlAddPurchReqCostCenter.Enabled = false;
                ddlAddPurchReqVendor.Enabled = false;
                ddlAddPurchReqCpfrNo.Enabled = false;
                txtAddPurchReqHeaderText.Enabled = false;
            }
        }

        private void HandlePurchasingGroupChange(string purchasingGroup)
        {
            switch (purchasingGroup)
            {
                case "MRO":
                    ddlAddPurchReqGlAccount.Visible = true;
                    pnlCostCenter.Visible = true;
                    pnlCpfrNumber.Visible = false;
                    lblCreateVendorMaterial.Visible = false;
                    lblCreateTrackingNo.Visible = false;
                    txtAddPurchReqTrackingNumber.Visible = false;
                    txtAddPurchReqVendorMaterial.Visible = false;
             //       rfvTxtAddPurchReqVendorMaterial.Enabled = false;
                    revTxtAddPurchReqVendorMaterial.Enabled = false;
             //       rfvTxtAddPurchReqTrackingNumber.Enabled = false;
                    revTxtAddPurchReqTrackingNumber.Enabled = false;
                    break;
                default:
                    ddlAddPurchReqGlAccount.Visible = true;
                    pnlCostCenter.Visible = false;
                    pnlCpfrNumber.Visible = true;
                    txtAddPurchReqTrackingNumber.Visible = true;
                    txtAddPurchReqVendorMaterial.Visible = true;
                    lblCreateVendorMaterial.Visible = true;
                    lblCreateTrackingNo.Visible = true;
            //        rfvTxtAddPurchReqVendorMaterial.Enabled = true;
                    revTxtAddPurchReqVendorMaterial.Enabled = true;
            //        rfvTxtAddPurchReqTrackingNumber.Enabled = true;
                    revTxtAddPurchReqTrackingNumber.Enabled = true;
                    break;
            }
        }

        private void AddToRequisitionTotal(decimal amount)
        {
            decimal currentTotal = String.IsNullOrEmpty(lblRequisitionTotal.Text) ? 0 : Convert.ToDecimal(decimal.Parse(lblRequisitionTotal.Text, NumberStyles.Currency, CultureInfo.CurrentCulture.NumberFormat));
            currentTotal += amount;
            lblRequisitionTotal.Text = Math.Round(currentTotal,2).ToString("C");
        }

        private void ResetAddPurchaseRequisitionOnGridEmpty()
        {
            if (gvAddPurchReq.Rows.Count > 0) return;
            ddlAddPurchReqPurchasingGroup.Enabled = true;
            ddlAddPurchReqCostCenter.Enabled = true;
            ddlAddPurchReqVendor.Enabled = true;
            ddlAddPurchReqCpfrNo.Enabled = true;
            txtAddPurchReqHeaderText.Enabled = true;
            lblRequisitionTotal.Text = @"$0.00";
        }

        #endregion

        #endregion

        protected void ddlAddPurchReqCpfrNo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}