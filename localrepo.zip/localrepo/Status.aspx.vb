﻿
Partial Class Status
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Dim FQDN As String = User.Identity.Name
        Dim usrnm As String = FQDN.Remove(0, 8)
        SqlDataSource1.SelectCommand = "SELECT * FROM [SAPPOREQ] WHERE requser = '" & usrnm & "'"
        'SqlDataSource1.SelectCommand = "SELECT * FROM [SAPPOREQ] WHERE requser = 'tdemuynck'"
    End Sub

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        Dim FQDN As String = User.Identity.Name
        Dim usrnm As String = FQDN.Remove(0, 8)
        SqlDataSource1.SelectCommand = "SELECT * FROM [SAPPOREQ] WHERE requser = '" & usrnm & "' and vendor = '" & DropDownList1.SelectedValue & "'"
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Label1.Text = GridView1.SelectedValue
        Session("IDno") = GridView1.SelectedValue
        Response.Redirect("~/display.aspx")
    End Sub
End Class
