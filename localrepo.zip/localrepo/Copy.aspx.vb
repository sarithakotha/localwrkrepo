﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class Display
    Inherits System.Web.UI.Page

    Protected Sub Page_PreInit(sender As Object, e As System.EventArgs) Handles Me.PreInit
        txtdate1.Text = Date.Now.Date
        txtdate2.Text = Date.Now.Date
        txtdate3.Text = Date.Now.Date
        txtdate4.Text = Date.Now.Date
        txtdate5.Text = Date.Now.Date
        txtdate6.Text = Date.Now.Date
        txtdate7.Text = Date.Now.Date
        txtdate8.Text = Date.Now.Date
        txtdate9.Text = Date.Now.Date
        txtdate10.Text = Date.Now.Date
        txtdate11.Text = Date.Now.Date
        txtdate12.Text = Date.Now.Date
        txtdate13.Text = Date.Now.Date
        txtdate14.Text = Date.Now.Date
        txtdate15.Text = Date.Now.Date
        txtdate16.Text = Date.Now.Date
        txtdate17.Text = Date.Now.Date
        txtdate18.Text = Date.Now.Date
        txtdate19.Text = Date.Now.Date
        txtdate20.Text = Date.Now.Date
        txtdate21.Text = Date.Now.Date
        txtdate22.Text = Date.Now.Date
        txtdate23.Text = Date.Now.Date
        txtdate24.Text = Date.Now.Date
        txtdate25.Text = Date.Now.Date
        txtdate26.Text = Date.Now.Date
        txtdate27.Text = Date.Now.Date
        txtdate28.Text = Date.Now.Date
        txtdate29.Text = Date.Now.Date
        txtdate30.Text = Date.Now.Date
    End Sub
    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        txttotal1.Attributes.Add("readonly", "True")
        txttotal2.Attributes.Add("readonly", "True")
        txttotal3.Attributes.Add("readonly", "True")
        txttotal4.Attributes.Add("readonly", "True")
        txttotal5.Attributes.Add("readonly", "True")
        txttotal6.Attributes.Add("readonly", "True")
        txttotal7.Attributes.Add("readonly", "True")
        txttotal8.Attributes.Add("readonly", "True")
        txttotal9.Attributes.Add("readonly", "True")
        txttotal10.Attributes.Add("readonly", "True")
        txttotal11.Attributes.Add("readonly", "True")
        txttotal12.Attributes.Add("readonly", "True")
        txttotal13.Attributes.Add("readonly", "True")
        txttotal14.Attributes.Add("readonly", "True")
        txttotal15.Attributes.Add("readonly", "True")
        txttotal16.Attributes.Add("readonly", "True")
        txttotal17.Attributes.Add("readonly", "True")
        txttotal18.Attributes.Add("readonly", "True")
        txttotal19.Attributes.Add("readonly", "True")
        txttotal20.Attributes.Add("readonly", "True")
        txttotal21.Attributes.Add("readonly", "True")
        txttotal22.Attributes.Add("readonly", "True")
        txttotal23.Attributes.Add("readonly", "True")
        txttotal24.Attributes.Add("readonly", "True")
        txttotal25.Attributes.Add("readonly", "True")
        txttotal26.Attributes.Add("readonly", "True")
        txttotal27.Attributes.Add("readonly", "True")
        txttotal28.Attributes.Add("readonly", "True")
        txttotal29.Attributes.Add("readonly", "True")
        txttotal30.Attributes.Add("readonly", "True")

        txtdate1.Attributes.Add("readonly", "readonly")
        txtdate2.Attributes.Add("readonly", "True")
        txtdate3.Attributes.Add("readonly", "True")
        txtdate4.Attributes.Add("readonly", "True")
        txtdate5.Attributes.Add("readonly", "True")
        txtdate6.Attributes.Add("readonly", "True")
        txtdate7.Attributes.Add("readonly", "True")
        txtdate8.Attributes.Add("readonly", "True")
        txtdate9.Attributes.Add("readonly", "True")
        txtdate10.Attributes.Add("readonly", "True")
        txtdate11.Attributes.Add("readonly", "True")
        txtdate12.Attributes.Add("readonly", "True")
        txtdate13.Attributes.Add("readonly", "True")
        txtdate14.Attributes.Add("readonly", "True")
        txtdate15.Attributes.Add("readonly", "True")
        txtdate16.Attributes.Add("readonly", "True")
        txtdate17.Attributes.Add("readonly", "True")
        txtdate18.Attributes.Add("readonly", "True")
        txtdate19.Attributes.Add("readonly", "True")
        txtdate20.Attributes.Add("readonly", "True")
        txtdate21.Attributes.Add("readonly", "True")
        txtdate22.Attributes.Add("readonly", "True")
        txtdate23.Attributes.Add("readonly", "True")
        txtdate24.Attributes.Add("readonly", "True")
        txtdate25.Attributes.Add("readonly", "True")
        txtdate26.Attributes.Add("readonly", "True")
        txtdate27.Attributes.Add("readonly", "True")
        txtdate28.Attributes.Add("readonly", "True")
        txtdate29.Attributes.Add("readonly", "True")
        txtdate30.Attributes.Add("readonly", "True")

        txtqty1.Attributes.Add("onchange", "DefaultValue();")
        txtprice1.Attributes.Add("onchange", "DefaultValue();")
        txtqty2.Attributes.Add("onchange", "DefaultValue();")
        txtprice2.Attributes.Add("onchange", "DefaultValue();")
        txtqty3.Attributes.Add("onchange", "DefaultValue();")
        txtprice3.Attributes.Add("onchange", "DefaultValue();")
        txtqty4.Attributes.Add("onchange", "DefaultValue();")
        txtprice4.Attributes.Add("onchange", "DefaultValue();")
        txtqty5.Attributes.Add("onchange", "DefaultValue();")
        txtprice5.Attributes.Add("onchange", "DefaultValue();")
        txtprice6.Attributes.Add("onchange", "DefaultValue();")
        txtqty6.Attributes.Add("onchange", "DefaultValue();")
        txtprice7.Attributes.Add("onchange", "DefaultValue();")
        txtqty7.Attributes.Add("onchange", "DefaultValue();")
        txtprice8.Attributes.Add("onchange", "DefaultValue();")
        txtqty8.Attributes.Add("onchange", "DefaultValue();")
        txtprice9.Attributes.Add("onchange", "DefaultValue();")
        txtqty9.Attributes.Add("onchange", "DefaultValue();")
        txtprice10.Attributes.Add("onchange", "DefaultValue();")
        txtqty10.Attributes.Add("onchange", "DefaultValue();")
        txtprice11.Attributes.Add("onchange", "DefaultValue();")
        txtqty11.Attributes.Add("onchange", "DefaultValue();")
        txtprice12.Attributes.Add("onchange", "DefaultValue();")
        txtqty12.Attributes.Add("onchange", "DefaultValue();")
        txtprice13.Attributes.Add("onchange", "DefaultValue();")
        txtqty13.Attributes.Add("onchange", "DefaultValue();")
        txtprice14.Attributes.Add("onchange", "DefaultValue();")
        txtqty14.Attributes.Add("onchange", "DefaultValue();")
        txtprice15.Attributes.Add("onchange", "DefaultValue();")
        txtqty15.Attributes.Add("onchange", "DefaultValue();")
        txtprice16.Attributes.Add("onchange", "DefaultValue();")
        txtqty16.Attributes.Add("onchange", "DefaultValue();")
        txtprice17.Attributes.Add("onchange", "DefaultValue();")
        txtqty17.Attributes.Add("onchange", "DefaultValue();")
        txtprice18.Attributes.Add("onchange", "DefaultValue();")
        txtqty18.Attributes.Add("onchange", "DefaultValue();")
        txtprice19.Attributes.Add("onchange", "DefaultValue();")
        txtqty19.Attributes.Add("onchange", "DefaultValue();")
        txtprice20.Attributes.Add("onchange", "DefaultValue();")
        txtqty20.Attributes.Add("onchange", "DefaultValue();")
        txtprice21.Attributes.Add("onchange", "DefaultValue();")
        txtqty21.Attributes.Add("onchange", "DefaultValue();")
        txtprice22.Attributes.Add("onchange", "DefaultValue();")
        txtqty22.Attributes.Add("onchange", "DefaultValue();")
        txtprice23.Attributes.Add("onchange", "DefaultValue();")
        txtqty23.Attributes.Add("onchange", "DefaultValue();")
        txtprice24.Attributes.Add("onchange", "DefaultValue();")
        txtqty24.Attributes.Add("onchange", "DefaultValue();")
        txtprice25.Attributes.Add("onchange", "DefaultValue();")
        txtqty25.Attributes.Add("onchange", "DefaultValue();")
        txtprice26.Attributes.Add("onchange", "DefaultValue();")
        txtqty26.Attributes.Add("onchange", "DefaultValue();")
        txtprice27.Attributes.Add("onchange", "DefaultValue();")
        txtqty27.Attributes.Add("onchange", "DefaultValue();")
        txtprice28.Attributes.Add("onchange", "DefaultValue();")
        txtqty28.Attributes.Add("onchange", "DefaultValue();")
        txtprice29.Attributes.Add("onchange", "DefaultValue();")
        txtqty29.Attributes.Add("onchange", "DefaultValue();")
        txtprice30.Attributes.Add("onchange", "DefaultValue();")
        txtqty30.Attributes.Add("onchange", "DefaultValue();")

        Button1.Attributes.Add("onclick", " this.disabled = true; " + ClientScript.GetPostBackEventReference(Button1, Nothing) + ";")

        Dim FQDN As String = User.Identity.Name
        Dim usrnm As String = FQDN.Remove(0, 8)
        Dim email As String = usrnm + "@ymmc.yamaha-motor.com"

        lblsubdate.Text = DateTime.Now.ToString("yyyyMMdd")
        Label1.Text = email

        'If Page.IsPostBack Then
        '    If RadioButtonList1.SelectedValue = "MRO" Then
        '        'ddcpfr.DataSource = CPFR
        '        'ddcpfr.DataSourceID = ""
        '        'ddlcpfr.DataBind()
        '        ddcpfr.SelectedValue = ""
        '        ddlgl1.DataSourceID = ""
        '        ddlgl1.DataSource = gl
        '        ddlgl2.DataSourceID = ""
        '        ddlgl2.DataSource = gl
        '        ddlgl3.DataSourceID = ""
        '        ddlgl3.DataSource = gl
        '        ddlgl4.DataSourceID = ""
        '        ddlgl4.DataSource = gl
        '        ddlgl5.DataSourceID = ""
        '        ddlgl5.DataSource = gl
        '        ddlgl6.DataSourceID = ""
        '        ddlgl6.DataSource = gl
        '        ddlgl7.DataSourceID = ""
        '        ddlgl7.DataSource = gl
        '        ddlgl8.DataSourceID = ""
        '        ddlgl8.DataSource = gl
        '        ddlgl9.DataSourceID = ""
        '        ddlgl9.DataSource = gl
        '        ddlgl10.DataSourceID = ""
        '        ddlgl10.DataSource = gl
        '        ddlgl11.DataSourceID = ""
        '        ddlgl11.DataSource = gl
        '        ddlgl12.DataSourceID = ""
        '        ddlgl12.DataSource = gl
        '        ddlgl13.DataSourceID = ""
        '        ddlgl13.DataSource = gl
        '        ddlgl14.DataSourceID = ""
        '        ddlgl14.DataSource = gl
        '        ddlgl15.DataSourceID = ""
        '        ddlgl15.DataSource = gl
        '        ddlgl16.DataSourceID = ""
        '        ddlgl16.DataSource = gl
        '        ddlgl17.DataSourceID = ""
        '        ddlgl17.DataSource = gl
        '        ddlgl18.DataSourceID = ""
        '        ddlgl18.DataSource = gl
        '        ddlgl19.DataSourceID = ""
        '        ddlgl19.DataSource = gl
        '        ddlgl20.DataSourceID = ""
        '        ddlgl20.DataSource = gl
        '        ddlgl21.DataSourceID = ""
        '        ddlgl21.DataSource = gl
        '        ddlgl22.DataSourceID = ""
        '        ddlgl22.DataSource = gl
        '        ddlgl23.DataSourceID = ""
        '        ddlgl23.DataSource = gl
        '        ddlgl24.DataSourceID = ""
        '        ddlgl24.DataSource = gl
        '        ddlgl25.DataSourceID = ""
        '        ddlgl25.DataSource = gl
        '        ddlgl26.DataSourceID = ""
        '        ddlgl26.DataSource = gl
        '        ddlgl27.DataSourceID = ""
        '        ddlgl27.DataSource = gl
        '        ddlgl28.DataSourceID = ""
        '        ddlgl28.DataSource = gl
        '        ddlgl29.DataSourceID = ""
        '        ddlgl29.DataSource = gl
        '        ddlgl30.DataSourceID = ""
        '        ddlgl30.DataSource = gl
        '        ddcpfr.Visible = False
        '        ddlcpfr.Visible = False
        '        txtacctcat.Text = "K"
        '        ValCPFR.Visible = False
        '        valCPFRblnk.Visible = False
        '    ElseIf RadioButtonList1.SelectedValue = "IO1" Then
        '        ddlgl1.DataSourceID = ""
        '        ddlgl1.DataSource = glf
        '        ddlgl2.DataSourceID = ""
        '        ddlgl2.DataSource = glf
        '        ddlgl3.DataSourceID = ""
        '        ddlgl3.DataSource = glf
        '        ddlgl4.DataSourceID = ""
        '        ddlgl4.DataSource = glf
        '        ddlgl5.DataSourceID = ""
        '        ddlgl5.DataSource = glf
        '        ddlgl6.DataSourceID = ""
        '        ddlgl6.DataSource = glf
        '        ddlgl7.DataSourceID = ""
        '        ddlgl7.DataSource = glf
        '        ddlgl8.DataSourceID = ""
        '        ddlgl8.DataSource = glf
        '        ddlgl9.DataSourceID = ""
        '        ddlgl9.DataSource = glf
        '        ddlgl10.DataSourceID = ""
        '        ddlgl10.DataSource = glf
        '        ddlgl11.DataSourceID = ""
        '        ddlgl11.DataSource = glf
        '        ddlgl12.DataSourceID = ""
        '        ddlgl12.DataSource = glf
        '        ddlgl13.DataSourceID = ""
        '        ddlgl13.DataSource = glf
        '        ddlgl14.DataSourceID = ""
        '        ddlgl14.DataSource = glf
        '        ddlgl15.DataSourceID = ""
        '        ddlgl15.DataSource = glf
        '        ddlgl16.DataSourceID = ""
        '        ddlgl16.DataSource = glf
        '        ddlgl17.DataSourceID = ""
        '        ddlgl17.DataSource = glf
        '        ddlgl18.DataSourceID = ""
        '        ddlgl18.DataSource = glf
        '        ddlgl19.DataSourceID = ""
        '        ddlgl19.DataSource = glf
        '        ddlgl20.DataSourceID = ""
        '        ddlgl20.DataSource = glf
        '        ddlgl21.DataSourceID = ""
        '        ddlgl21.DataSource = glf
        '        ddlgl22.DataSourceID = ""
        '        ddlgl22.DataSource = glf
        '        ddlgl23.DataSourceID = ""
        '        ddlgl23.DataSource = glf
        '        ddlgl24.DataSourceID = ""
        '        ddlgl24.DataSource = glf
        '        ddlgl25.DataSourceID = ""
        '        ddlgl25.DataSource = glf
        '        ddlgl26.DataSourceID = ""
        '        ddlgl26.DataSource = glf
        '        ddlgl27.DataSourceID = ""
        '        ddlgl27.DataSource = glf
        '        ddlgl28.DataSourceID = ""
        '        ddlgl28.DataSource = glf
        '        ddlgl29.DataSourceID = ""
        '        ddlgl29.DataSource = glf
        '        ddlgl30.DataSourceID = ""
        '        ddlgl30.DataSource = glf
        '        ddcpfr.DataSource = cpfrio1
        '        ddcpfr.DataSourceID = ""
        '        ddcpfr.DataBind()
        '        ddcpfr.Visible = True
        '        ddlcpfr.Visible = True
        '        txtacctcat.Text = "F"
        '        ValCPFR.Visible = True
        '        valCPFRblnk.Visible = True
        '    ElseIf RadioButtonList1.SelectedValue = "IO2" Then
        '        ddlgl1.DataSourceID = ""
        '        ddlgl1.DataSource = glf
        '        ddlgl2.DataSourceID = ""
        '        ddlgl2.DataSource = glf
        '        ddlgl3.DataSourceID = ""
        '        ddlgl3.DataSource = glf
        '        ddlgl4.DataSourceID = ""
        '        ddlgl4.DataSource = glf
        '        ddlgl5.DataSourceID = ""
        '        ddlgl5.DataSource = glf
        '        ddlgl6.DataSourceID = ""
        '        ddlgl6.DataSource = glf
        '        ddlgl7.DataSourceID = ""
        '        ddlgl7.DataSource = glf
        '        ddlgl8.DataSourceID = ""
        '        ddlgl8.DataSource = glf
        '        ddlgl9.DataSourceID = ""
        '        ddlgl9.DataSource = glf
        '        ddlgl10.DataSourceID = ""
        '        ddlgl10.DataSource = glf
        '        ddlgl11.DataSourceID = ""
        '        ddlgl11.DataSource = glf
        '        ddlgl12.DataSourceID = ""
        '        ddlgl12.DataSource = glf
        '        ddlgl13.DataSourceID = ""
        '        ddlgl13.DataSource = glf
        '        ddlgl14.DataSourceID = ""
        '        ddlgl14.DataSource = glf
        '        ddlgl15.DataSourceID = ""
        '        ddlgl15.DataSource = glf
        '        ddlgl16.DataSourceID = ""
        '        ddlgl16.DataSource = glf
        '        ddlgl17.DataSourceID = ""
        '        ddlgl17.DataSource = glf
        '        ddlgl18.DataSourceID = ""
        '        ddlgl18.DataSource = glf
        '        ddlgl19.DataSourceID = ""
        '        ddlgl19.DataSource = glf
        '        ddlgl20.DataSourceID = ""
        '        ddlgl20.DataSource = glf
        '        ddlgl21.DataSourceID = ""
        '        ddlgl21.DataSource = glf
        '        ddlgl22.DataSourceID = ""
        '        ddlgl22.DataSource = glf
        '        ddlgl23.DataSourceID = ""
        '        ddlgl23.DataSource = glf
        '        ddlgl24.DataSourceID = ""
        '        ddlgl24.DataSource = glf
        '        ddlgl25.DataSourceID = ""
        '        ddlgl25.DataSource = glf
        '        ddlgl26.DataSourceID = ""
        '        ddlgl26.DataSource = glf
        '        ddlgl27.DataSourceID = ""
        '        ddlgl27.DataSource = glf
        '        ddlgl28.DataSourceID = ""
        '        ddlgl28.DataSource = glf
        '        ddlgl29.DataSourceID = ""
        '        ddlgl29.DataSource = glf
        '        ddlgl30.DataSourceID = ""
        '        ddlgl30.DataSource = glf
        '        ddcpfr.DataSource = cpfrio2
        '        ddcpfr.DataSourceID = ""
        '        ddcpfr.DataBind()
        '        ddcpfr.Visible = True
        '        ddlcpfr.Visible = True
        '        txtacctcat.Text = "F"
        '        ValCPFR.Visible = True
        '        valCPFRblnk.Visible = True
        '    ElseIf RadioButtonList1.SelectedValue = "IO3" Then
        '        ddlgl1.DataSourceID = ""
        '        ddlgl1.DataSource = glf
        '        ddlgl2.DataSourceID = ""
        '        ddlgl2.DataSource = glf
        '        ddlgl3.DataSourceID = ""
        '        ddlgl3.DataSource = glf
        '        ddlgl4.DataSourceID = ""
        '        ddlgl4.DataSource = glf
        '        ddlgl5.DataSourceID = ""
        '        ddlgl5.DataSource = glf
        '        ddlgl6.DataSourceID = ""
        '        ddlgl6.DataSource = glf
        '        ddlgl7.DataSourceID = ""
        '        ddlgl7.DataSource = glf
        '        ddlgl8.DataSourceID = ""
        '        ddlgl8.DataSource = glf
        '        ddlgl9.DataSourceID = ""
        '        ddlgl9.DataSource = glf
        '        ddlgl10.DataSourceID = ""
        '        ddlgl10.DataSource = glf
        '        ddlgl11.DataSourceID = ""
        '        ddlgl11.DataSource = glf
        '        ddlgl12.DataSourceID = ""
        '        ddlgl12.DataSource = glf
        '        ddlgl13.DataSourceID = ""
        '        ddlgl13.DataSource = glf
        '        ddlgl14.DataSourceID = ""
        '        ddlgl14.DataSource = glf
        '        ddlgl15.DataSourceID = ""
        '        ddlgl15.DataSource = glf
        '        ddlgl16.DataSourceID = ""
        '        ddlgl16.DataSource = glf
        '        ddlgl17.DataSourceID = ""
        '        ddlgl17.DataSource = glf
        '        ddlgl18.DataSourceID = ""
        '        ddlgl18.DataSource = glf
        '        ddlgl19.DataSourceID = ""
        '        ddlgl19.DataSource = glf
        '        ddlgl20.DataSourceID = ""
        '        ddlgl20.DataSource = glf
        '        ddlgl21.DataSourceID = ""
        '        ddlgl21.DataSource = glf
        '        ddlgl22.DataSourceID = ""
        '        ddlgl22.DataSource = glf
        '        ddlgl23.DataSourceID = ""
        '        ddlgl23.DataSource = glf
        '        ddlgl24.DataSourceID = ""
        '        ddlgl24.DataSource = glf
        '        ddlgl25.DataSourceID = ""
        '        ddlgl25.DataSource = glf
        '        ddlgl26.DataSourceID = ""
        '        ddlgl26.DataSource = glf
        '        ddlgl27.DataSourceID = ""
        '        ddlgl27.DataSource = glf
        '        ddlgl28.DataSourceID = ""
        '        ddlgl28.DataSource = glf
        '        ddlgl29.DataSourceID = ""
        '        ddlgl29.DataSource = glf
        '        ddlgl30.DataSourceID = ""
        '        ddlgl30.DataSource = glf
        '        ddcpfr.DataSource = cpfrio3
        '        ddcpfr.DataSourceID = ""
        '        ddcpfr.DataBind()
        '        ddcpfr.Visible = True
        '        ddlcpfr.Visible = True
        '        txtacctcat.Text = "F"
        '        ValCPFR.Visible = True
        '        valCPFRblnk.Visible = True
        '    ElseIf RadioButtonList1.SelectedValue = "IO4" Then
        '        ddlgl1.DataSourceID = ""
        '        ddlgl1.DataSource = glh
        '        ddlgl2.DataSourceID = ""
        '        ddlgl2.DataSource = glh
        '        ddlgl3.DataSourceID = ""
        '        ddlgl3.DataSource = glh
        '        ddlgl4.DataSourceID = ""
        '        ddlgl4.DataSource = glh
        '        ddlgl5.DataSourceID = ""
        '        ddlgl5.DataSource = glh
        '        ddlgl6.DataSourceID = ""
        '        ddlgl6.DataSource = glh
        '        ddlgl7.DataSourceID = ""
        '        ddlgl7.DataSource = glh
        '        ddlgl8.DataSourceID = ""
        '        ddlgl8.DataSource = glh
        '        ddlgl9.DataSourceID = ""
        '        ddlgl9.DataSource = glh
        '        ddlgl10.DataSourceID = ""
        '        ddlgl10.DataSource = glh
        '        ddlgl11.DataSourceID = ""
        '        ddlgl11.DataSource = glh
        '        ddlgl12.DataSourceID = ""
        '        ddlgl12.DataSource = glh
        '        ddlgl13.DataSourceID = ""
        '        ddlgl13.DataSource = glh
        '        ddlgl14.DataSourceID = ""
        '        ddlgl14.DataSource = glh
        '        ddlgl15.DataSourceID = ""
        '        ddlgl15.DataSource = glh
        '        ddlgl16.DataSourceID = ""
        '        ddlgl16.DataSource = glh
        '        ddlgl17.DataSourceID = ""
        '        ddlgl17.DataSource = glh
        '        ddlgl18.DataSourceID = ""
        '        ddlgl18.DataSource = glh
        '        ddlgl19.DataSourceID = ""
        '        ddlgl19.DataSource = glh
        '        ddlgl20.DataSourceID = ""
        '        ddlgl20.DataSource = glh
        '        ddlgl21.DataSourceID = ""
        '        ddlgl21.DataSource = glh
        '        ddlgl22.DataSourceID = ""
        '        ddlgl22.DataSource = glh
        '        ddlgl23.DataSourceID = ""
        '        ddlgl23.DataSource = glh
        '        ddlgl24.DataSourceID = ""
        '        ddlgl24.DataSource = glh
        '        ddlgl25.DataSourceID = ""
        '        ddlgl25.DataSource = glh
        '        ddlgl26.DataSourceID = ""
        '        ddlgl26.DataSource = glh
        '        ddlgl27.DataSourceID = ""
        '        ddlgl27.DataSource = glh
        '        ddlgl28.DataSourceID = ""
        '        ddlgl28.DataSource = glh
        '        ddlgl29.DataSourceID = ""
        '        ddlgl29.DataSource = glh
        '        ddlgl30.DataSourceID = ""
        '        ddlgl30.DataSource = glh
        '        ddcpfr.DataSource = cpfrio4
        '        ddcpfr.DataSourceID = ""
        '        ddcpfr.DataBind()
        '        ddcpfr.Visible = True
        '        ddlcpfr.Visible = True
        '        txtacctcat.Text = "H"
        '        ValCPFR.Visible = True
        '        valCPFRblnk.Visible = True
        '    End If
        'End If

        If Not Page.IsPostBack Then

            Dim con As New SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
            Dim cmd As New SqlCommand
            Dim dt As New DataTable
            Dim IDno As String = CType(Session.Item("IDno"), String)
            'lblidno.Text = IDno
            con.Open()
            cmd.Connection = con
            cmd.CommandText = "Select count(*) from SAPPOREQ WHERE seqkey = '" & IDno & "'"
            Dim result As Object = cmd.ExecuteScalar
            'lblresult.Text = String.Format(result)
            'cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.Text & "', '" & ddlcpfr.SelectedValue & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "','" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "')"
            'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate, subdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddlcpfr.Text & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "','" & DateTime.Now & "')"
            cmd.ExecuteNonQuery()
            con.Close()

            con.Open()
            Dim da As New SqlDataAdapter("SELECT * FROM SAPPOREQ WHERE seqkey = '" & IDno & "'", con)
            da.Fill(dt)
            ddlvendor.Text = dt.Rows(0)("vendor")
            If dt.rows(0)("ccenter") = "" Then
                ddlccenter.visible = False
                valddlccenter.visible = False
                valddlccenterblnk.visible = False
                lblccenter.visible = False
            Else
                ddlccenter.selectedvalue = dt.rows(0)("ccenter")
            End If

            If Not IsDBNull(dt.Rows(0)("cpfr")) Then
                'ddcpfr.Visible = True
                If dt.Rows(0)("purgroup") = "IO1" Then
                    ddcpfr.DataSource = cpfrio1
                    ddcpfr.DataSourceID = ""
                    ddcpfr.SelectedValue = dt.Rows(0)("cpfr")
                ElseIf dt.Rows(0)("purgroup") = "IO2" Then
                    ddcpfr.DataSource = cpfrio2
                    ddcpfr.DataSourceID = ""
                    ddcpfr.SelectedValue = dt.Rows(0)("cpfr")
                ElseIf dt.Rows(0)("purgroup") = "IO3" Then
                    ddcpfr.DataSource = cpfrio3
                    ddcpfr.DataSourceID = ""
                    ddcpfr.SelectedValue = dt.Rows(0)("cpfr")
                ElseIf dt.Rows(0)("purgroup") = "IO4" Then
                    ddcpfr.DataSource = cpfrio4
                    ddcpfr.DataSourceID = ""
                    ddcpfr.SelectedValue = dt.Rows(0)("cpfr")
                ElseIf dt.Rows(0)("purgroup") = "IO5" Then
                    ddcpfr.DataSource = cpfrio5
                    ddcpfr.DataSourceID = ""
                    ddcpfr.SelectedValue = dt.Rows(0)("cpfr")
                ElseIf dt.Rows(0)("purgroup") = "IO6" Then
                    ddcpfr.DataSource = cpfrio6
                    ddcpfr.DataSourceID = ""
                    ddcpfr.SelectedValue = dt.Rows(0)("cpfr")
                ElseIf dt.Rows(0)("purgroup") = "REW" Then
                    ddcpfr.DataSource = CPFRrew
                    ddcpfr.DataSourceID = ""
                    ddcpfr.SelectedValue = dt.Rows(0)("cpfr")
                End If

            End If
            If dt.Rows(0)("cpfr") = "" Then
                ddcpfr.visible = False
                ddlcpfr.Visible = False
                ddcpfr.SelectedValue = ""
            End If
            RadioButtonList1.SelectedValue = dt.Rows(0)("purgroup")
            lblgroup.Text = dt.Rows(0)("purgroup")

            'lblcpfr.Text = dt.Rows(0)("cpfr")
            'lblgrp.Text = dt.Rows(0)("purgroup")
            txthead.Text = dt.Rows(0)("hdrtext")
            'lblstatus.Text = dt.Rows(0)("status")
            'If Not IsDBNull(dt.Rows(0)("errordesc")) Then
            '    lblerr.Visible = True
            '    lblerrtxt.Visible = True
            '    lblerr.Text = dt.Rows(0)("errordesc")
            'End If
            'If Not IsDBNull(dt.Rows(0)("cpfr")) Then
            '    lblcpfr.Text = dt.Rows(0)("cpfr")
            'Else
            '    lblcpfr.Text = ""
            'End If

            'If Not IsDBNull(dt.Rows(0)("poreq")) Then
            '    lblreq.Text = dt.Rows(0)("poreq")
            'End If
            'If Not IsDBNull(dt.Rows(0)("sappo")) Then
            '    lblpo.Text = dt.Rows(0)("sappo")
            'End If

            'If dt.Rows(0)("status") = "1" Then
            '    lblstatdesc.Text = "Pending"
            'ElseIf dt.Rows(0)("status") = "X" Then
            '    lblstatdesc.Text = "Transfered to SAP"
            'ElseIf dt.Rows(0)("status") = "2" Then
            '    lblstatdesc.Text = "SAP Requsition Created"
            'ElseIf dt.Rows(0)("status") = "3" Then
            '    lblstatdesc.Text = "PO Created"
            'ElseIf dt.Rows(0)("status") = "4" Then
            '    lblstatdesc.Text = "Rejected"
            'ElseIf dt.Rows(0)("status") = "6" Then
            '    lblstatdesc.Text = "ERROR, See error description."
            '    lblstatdesc.ForeColor = Drawing.Color.Red

            'End If
            Dim tot0 As Double
            Dim tot1 As Double
            Dim tot2 As Double
            Dim tot3 As Double
            Dim tot4 As Double
            Dim tot5 As Double
            Dim tot6 As Double
            Dim tot7 As Double
            Dim tot8 As Double
            Dim tot9 As Double
            Dim tot10 As Double
            Dim tot11 As Double
            Dim tot12 As Double
            Dim tot13 As Double
            Dim tot14 As Double
            Dim tot15 As Double
            Dim tot16 As Double
            Dim tot17 As Double
            Dim tot18 As Double
            Dim tot19 As Double
            Dim tot20 As Double
            Dim tot21 As Double
            Dim tot22 As Double
            Dim tot23 As Double
            Dim tot24 As Double
            Dim tot25 As Double
            Dim tot26 As Double
            Dim tot27 As Double
            Dim tot28 As Double
            Dim tot29 As Double
            tot0 = dt.Rows(0)("unitprc") * dt.Rows(0)("unitqty")
            txttotal1.Text = String.Format("${0:0.00}", tot0)
            Txtshrt1.Text = dt.Rows(0)("shorttext")
            ddlgl1.SelectedValue = dt.Rows(0)("glacct")
            txtqty1.Text = dt.Rows(0)("unitqty")
            txtprice1.Text = dt.Rows(0)("unitprc")
            ddluom1.SelectedValue = dt.Rows(0)("uom")
            ddltax1.SelectedValue = dt.Rows(0)("taxflag")
            If Not IsDBNull(dt.Rows(0)("venitem")) Then
                txtvenmat1.Text = dt.Rows(0)("venitem")
            Else
                txtvenmat1.Text = ""
            End If
            If Not IsDBNull(dt.Rows(0)("refpart")) Then
                txttrackno1.Text = dt.Rows(0)("refpart")
            Else
                txttrackno1.Text = ""
            End If
            If Not IsDBNull(dt.Rows(0)("longtext")) Then
                txtlng1.Text = dt.Rows(0)("longtext")
            Else
                txtlng1.Text = ""
            End If
            'txtdate1.Text = dt.Rows(0)("dlvdate")
            If dt.Rows(0)("purgroup") = "MRO" Then
                txtacctcat.Text = "K"
                ddlgl1.DataSourceID = ""
                ddlgl1.DataSource = gl
                ddlgl2.DataSourceID = ""
                ddlgl2.DataSource = gl
                ddlgl3.DataSourceID = ""
                ddlgl3.DataSource = gl
                ddlgl4.DataSourceID = ""
                ddlgl4.DataSource = gl
                ddlgl5.DataSourceID = ""
                ddlgl5.DataSource = gl
                ddlgl6.DataSourceID = ""
                ddlgl6.DataSource = gl
                ddlgl7.DataSourceID = ""
                ddlgl7.DataSource = gl
                ddlgl8.DataSourceID = ""
                ddlgl8.DataSource = gl
                ddlgl9.DataSourceID = ""
                ddlgl9.DataSource = gl
                ddlgl10.DataSourceID = ""
                ddlgl10.DataSource = gl
                ddlgl11.DataSourceID = ""
                ddlgl11.DataSource = gl
                ddlgl12.DataSourceID = ""
                ddlgl12.DataSource = gl
                ddlgl13.DataSourceID = ""
                ddlgl13.DataSource = gl
                ddlgl14.DataSourceID = ""
                ddlgl14.DataSource = gl
                ddlgl15.DataSourceID = ""
                ddlgl15.DataSource = gl
                ddlgl16.DataSourceID = ""
                ddlgl16.DataSource = gl
                ddlgl17.DataSourceID = ""
                ddlgl17.DataSource = gl
                ddlgl18.DataSourceID = ""
                ddlgl18.DataSource = gl
                ddlgl19.DataSourceID = ""
                ddlgl19.DataSource = gl
                ddlgl20.DataSourceID = ""
                ddlgl20.DataSource = gl
                ddlgl21.DataSourceID = ""
                ddlgl21.DataSource = gl
                ddlgl22.DataSourceID = ""
                ddlgl22.DataSource = gl
                ddlgl23.DataSourceID = ""
                ddlgl23.DataSource = gl
                ddlgl24.DataSourceID = ""
                ddlgl24.DataSource = gl
                ddlgl25.DataSourceID = ""
                ddlgl25.DataSource = gl
                ddlgl26.DataSourceID = ""
                ddlgl26.DataSource = gl
                ddlgl27.DataSourceID = ""
                ddlgl27.DataSource = gl
                ddlgl28.DataSourceID = ""
                ddlgl28.DataSource = gl
                ddlgl29.DataSourceID = ""
                ddlgl29.DataSource = gl
                ddlgl30.DataSourceID = ""
                ddlgl30.DataSource = gl
                ddlgl2.databind()

            ElseIf dt.Rows(0)("purgroup") = "IO4" Then
                txtacctcat.Text = "H"
                ddlgl1.DataSourceID = ""
                ddlgl1.DataSource = glh
                ddlgl2.DataSourceID = ""
                ddlgl2.DataSource = glh
                ddlgl3.DataSourceID = ""
                ddlgl3.DataSource = glh
                ddlgl4.DataSourceID = ""
                ddlgl4.DataSource = glh
                ddlgl5.DataSourceID = ""
                ddlgl5.DataSource = glh
                ddlgl6.DataSourceID = ""
                ddlgl6.DataSource = glh
                ddlgl7.DataSourceID = ""
                ddlgl7.DataSource = glh
                ddlgl8.DataSourceID = ""
                ddlgl8.DataSource = glh
                ddlgl9.DataSourceID = ""
                ddlgl9.DataSource = glh
                ddlgl10.DataSourceID = ""
                ddlgl10.DataSource = glh
                ddlgl11.DataSourceID = ""
                ddlgl11.DataSource = glh
                ddlgl12.DataSourceID = ""
                ddlgl12.DataSource = glh
                ddlgl13.DataSourceID = ""
                ddlgl13.DataSource = glh
                ddlgl14.DataSourceID = ""
                ddlgl14.DataSource = glh
                ddlgl15.DataSourceID = ""
                ddlgl15.DataSource = glh
                ddlgl16.DataSourceID = ""
                ddlgl16.DataSource = glh
                ddlgl17.DataSourceID = ""
                ddlgl17.DataSource = glh
                ddlgl18.DataSourceID = ""
                ddlgl18.DataSource = glh
                ddlgl19.DataSourceID = ""
                ddlgl19.DataSource = glh
                ddlgl20.DataSourceID = ""
                ddlgl20.DataSource = glh
                ddlgl21.DataSourceID = ""
                ddlgl21.DataSource = glh
                ddlgl22.DataSourceID = ""
                ddlgl22.DataSource = glh
                ddlgl23.DataSourceID = ""
                ddlgl23.DataSource = glh
                ddlgl24.DataSourceID = ""
                ddlgl24.DataSource = glh
                ddlgl25.DataSourceID = ""
                ddlgl25.DataSource = glh
                ddlgl26.DataSourceID = ""
                ddlgl26.DataSource = glh
                ddlgl27.DataSourceID = ""
                ddlgl27.DataSource = glh
                ddlgl28.DataSourceID = ""
                ddlgl28.DataSource = glh
                ddlgl29.DataSourceID = ""
                ddlgl29.DataSource = glh
                ddlgl30.DataSourceID = ""
                ddlgl30.DataSource = glh
            ElseIf dt.Rows(0)("purgroup") = "IO5" Then
                txtacctcat.Text = "I"
                ddlgl1.DataSourceID = ""
                ddlgl1.DataSource = gli
                ddlgl2.DataSourceID = ""
                ddlgl2.DataSource = gli
                ddlgl3.DataSourceID = ""
                ddlgl3.DataSource = gli
                ddlgl4.DataSourceID = ""
                ddlgl4.DataSource = gli
                ddlgl5.DataSourceID = ""
                ddlgl5.DataSource = gli
                ddlgl6.DataSourceID = ""
                ddlgl6.DataSource = gli
                ddlgl7.DataSourceID = ""
                ddlgl7.DataSource = gli
                ddlgl8.DataSourceID = ""
                ddlgl8.DataSource = gli
                ddlgl9.DataSourceID = ""
                ddlgl9.DataSource = gli
                ddlgl10.DataSourceID = ""
                ddlgl10.DataSource = gli
                ddlgl11.DataSourceID = ""
                ddlgl11.DataSource = gli
                ddlgl12.DataSourceID = ""
                ddlgl12.DataSource = gli
                ddlgl13.DataSourceID = ""
                ddlgl13.DataSource = gli
                ddlgl14.DataSourceID = ""
                ddlgl14.DataSource = gli
                ddlgl15.DataSourceID = ""
                ddlgl15.DataSource = gli
                ddlgl16.DataSourceID = ""
                ddlgl16.DataSource = gli
                ddlgl17.DataSourceID = ""
                ddlgl17.DataSource = gli
                ddlgl18.DataSourceID = ""
                ddlgl18.DataSource = gli
                ddlgl19.DataSourceID = ""
                ddlgl19.DataSource = gli
                ddlgl20.DataSourceID = ""
                ddlgl20.DataSource = gli
                ddlgl21.DataSourceID = ""
                ddlgl21.DataSource = gli
                ddlgl22.DataSourceID = ""
                ddlgl22.DataSource = gli
                ddlgl23.DataSourceID = ""
                ddlgl23.DataSource = gli
                ddlgl24.DataSourceID = ""
                ddlgl24.DataSource = gli
                ddlgl25.DataSourceID = ""
                ddlgl25.DataSource = gli
                ddlgl26.DataSourceID = ""
                ddlgl26.DataSource = gli
                ddlgl27.DataSourceID = ""
                ddlgl27.DataSource = gli
                ddlgl28.DataSourceID = ""
                ddlgl28.DataSource = gli
                ddlgl29.DataSourceID = ""
                ddlgl29.DataSource = gli
                ddlgl30.DataSourceID = ""
                ddlgl30.DataSource = gli
            ElseIf dt.Rows(0)("purgroup") = "IO6" Then
                txtacctcat.Text = "J"
                ddlgl1.DataSourceID = ""
                ddlgl1.DataSource = glj
                ddlgl2.DataSourceID = ""
                ddlgl2.DataSource = glj
                ddlgl3.DataSourceID = ""
                ddlgl3.DataSource = glj
                ddlgl4.DataSourceID = ""
                ddlgl4.DataSource = glj
                ddlgl5.DataSourceID = ""
                ddlgl5.DataSource = glj
                ddlgl6.DataSourceID = ""
                ddlgl6.DataSource = glj
                ddlgl7.DataSourceID = ""
                ddlgl7.DataSource = glj
                ddlgl8.DataSourceID = ""
                ddlgl8.DataSource = glj
                ddlgl9.DataSourceID = ""
                ddlgl9.DataSource = glj
                ddlgl10.DataSourceID = ""
                ddlgl10.DataSource = glj
                ddlgl11.DataSourceID = ""
                ddlgl11.DataSource = glj
                ddlgl12.DataSourceID = ""
                ddlgl12.DataSource = glj
                ddlgl13.DataSourceID = ""
                ddlgl13.DataSource = glj
                ddlgl14.DataSourceID = ""
                ddlgl14.DataSource = glj
                ddlgl15.DataSourceID = ""
                ddlgl15.DataSource = glj
                ddlgl16.DataSourceID = ""
                ddlgl16.DataSource = glj
                ddlgl17.DataSourceID = ""
                ddlgl17.DataSource = glj
                ddlgl18.DataSourceID = ""
                ddlgl18.DataSource = glj
                ddlgl19.DataSourceID = ""
                ddlgl19.DataSource = glj
                ddlgl20.DataSourceID = ""
                ddlgl20.DataSource = glj
                ddlgl21.DataSourceID = ""
                ddlgl21.DataSource = glj
                ddlgl22.DataSourceID = ""
                ddlgl22.DataSource = glj
                ddlgl23.DataSourceID = ""
                ddlgl23.DataSource = glj
                ddlgl24.DataSourceID = ""
                ddlgl24.DataSource = glj
                ddlgl25.DataSourceID = ""
                ddlgl25.DataSource = glj
                ddlgl26.DataSourceID = ""
                ddlgl26.DataSource = glj
                ddlgl27.DataSourceID = ""
                ddlgl27.DataSource = glj
                ddlgl28.DataSourceID = ""
                ddlgl28.DataSource = glj
                ddlgl29.DataSourceID = ""
                ddlgl29.DataSource = glj
                ddlgl30.DataSourceID = ""
                ddlgl30.DataSource = glj
            ElseIf dt.Rows(0)("purgroup") = "REW" Then
                txtacctcat.Text = "R"
                ddlgl1.DataSourceID = ""
                ddlgl1.DataSource = GLr
                ddlgl2.DataSourceID = ""
                ddlgl2.DataSource = GLr
                ddlgl3.DataSourceID = ""
                ddlgl3.DataSource = GLr
                ddlgl4.DataSourceID = ""
                ddlgl4.DataSource = GLr
                ddlgl5.DataSourceID = ""
                ddlgl5.DataSource = GLr
                ddlgl6.DataSourceID = ""
                ddlgl6.DataSource = GLr
                ddlgl7.DataSourceID = ""
                ddlgl7.DataSource = GLr
                ddlgl8.DataSourceID = ""
                ddlgl8.DataSource = GLr
                ddlgl9.DataSourceID = ""
                ddlgl9.DataSource = GLr
                ddlgl10.DataSourceID = ""
                ddlgl10.DataSource = GLr
                ddlgl11.DataSourceID = ""
                ddlgl11.DataSource = GLr
                ddlgl12.DataSourceID = ""
                ddlgl12.DataSource = GLr
                ddlgl13.DataSourceID = ""
                ddlgl13.DataSource = GLr
                ddlgl14.DataSourceID = ""
                ddlgl14.DataSource = GLr
                ddlgl15.DataSourceID = ""
                ddlgl15.DataSource = GLr
                ddlgl16.DataSourceID = ""
                ddlgl16.DataSource = GLr
                ddlgl17.DataSourceID = ""
                ddlgl17.DataSource = GLr
                ddlgl18.DataSourceID = ""
                ddlgl18.DataSource = GLr
                ddlgl19.DataSourceID = ""
                ddlgl19.DataSource = GLr
                ddlgl20.DataSourceID = ""
                ddlgl20.DataSource = GLr
                ddlgl21.DataSourceID = ""
                ddlgl21.DataSource = GLr
                ddlgl22.DataSourceID = ""
                ddlgl22.DataSource = GLr
                ddlgl23.DataSourceID = ""
                ddlgl23.DataSource = GLr
                ddlgl24.DataSourceID = ""
                ddlgl24.DataSource = GLr
                ddlgl25.DataSourceID = ""
                ddlgl25.DataSource = GLr
                ddlgl26.DataSourceID = ""
                ddlgl26.DataSource = GLr
                ddlgl27.DataSourceID = ""
                ddlgl27.DataSource = GLr
                ddlgl28.DataSourceID = ""
                ddlgl28.DataSource = GLr
                ddlgl29.DataSourceID = ""
                ddlgl29.DataSource = GLr
                ddlgl30.DataSourceID = ""
                ddlgl30.DataSource = GLr
            Else
                txtacctcat.Text = "F"
                ddlgl1.DataSourceID = ""
                ddlgl1.DataSource = glf
                ddlgl2.DataSourceID = ""
                ddlgl2.DataSource = glf
                ddlgl3.DataSourceID = ""
                ddlgl3.DataSource = glf
                ddlgl4.DataSourceID = ""
                ddlgl4.DataSource = glf
                ddlgl5.DataSourceID = ""
                ddlgl5.DataSource = glf
                ddlgl6.DataSourceID = ""
                ddlgl6.DataSource = glf
                ddlgl7.DataSourceID = ""
                ddlgl7.DataSource = glf
                ddlgl8.DataSourceID = ""
                ddlgl8.DataSource = glf
                ddlgl9.DataSourceID = ""
                ddlgl9.DataSource = glf
                ddlgl10.DataSourceID = ""
                ddlgl10.DataSource = glf
                ddlgl11.DataSourceID = ""
                ddlgl11.DataSource = glf
                ddlgl12.DataSourceID = ""
                ddlgl12.DataSource = glf
                ddlgl13.DataSourceID = ""
                ddlgl13.DataSource = glf
                ddlgl14.DataSourceID = ""
                ddlgl14.DataSource = glf
                ddlgl15.DataSourceID = ""
                ddlgl15.DataSource = glf
                ddlgl16.DataSourceID = ""
                ddlgl16.DataSource = glf
                ddlgl17.DataSourceID = ""
                ddlgl17.DataSource = glf
                ddlgl18.DataSourceID = ""
                ddlgl18.DataSource = glf
                ddlgl19.DataSourceID = ""
                ddlgl19.DataSource = glf
                ddlgl20.DataSourceID = ""
                ddlgl20.DataSource = glf
                ddlgl21.DataSourceID = ""
                ddlgl21.DataSource = glf
                ddlgl22.DataSourceID = ""
                ddlgl22.DataSource = glf
                ddlgl23.DataSourceID = ""
                ddlgl23.DataSource = glf
                ddlgl24.DataSourceID = ""
                ddlgl24.DataSource = glf
                ddlgl25.DataSourceID = ""
                ddlgl25.DataSource = glf
                ddlgl26.DataSourceID = ""
                ddlgl26.DataSource = glf
                ddlgl27.DataSourceID = ""
                ddlgl27.DataSource = glf
                ddlgl28.DataSourceID = ""
                ddlgl28.DataSource = glf
                ddlgl29.DataSourceID = ""
                ddlgl29.DataSource = glf
                ddlgl30.DataSourceID = ""
                ddlgl30.DataSource = glf


            End If
            If result > "1" Then
                tot1 = dt.Rows(1)("unitprc") * dt.Rows(1)("unitqty")
                Panel2.Visible = True
                Txtshrt2.Text = dt.Rows(1)("shorttext")
                txtlng2.Text = dt.Rows(1)("longtext")
                ddlgl2.SelectedValue = dt.Rows(1)("glacct")
                txtqty2.Text = dt.Rows(1)("unitqty")
                txtprice2.Text = dt.Rows(1)("unitprc")
                ddluom2.SelectedValue = dt.Rows(1)("uom")
                txttotal2.Text = String.Format("${0:0.00}", tot1)
                ddltax2.SelectedValue = dt.Rows(1)("taxflag")
                'lbldelv2.Text = dt.Rows(1)("dlvdate")
                btnadd1.Visible = False
                If Not IsDBNull(dt.Rows(1)("venitem")) Then
                    txtvenmat2.Text = dt.Rows(1)("venitem")
                Else
                    txtvenmat2.Text = ""
                End If
                If Not IsDBNull(dt.Rows(1)("refpart")) Then
                    txttrackno2.Text = dt.Rows(1)("refpart")
                Else
                    txttrackno2.Text = ""
                End If
                If Not IsDBNull(dt.Rows(1)("longtext")) Then
                    txtlng2.Text = dt.Rows(1)("longtext")
                Else
                    txtlng2.Text = ""
                End If
            End If
            If result > "2" Then
                tot2 = dt.Rows(2)("unitprc") * dt.Rows(2)("unitqty")
                Panel3.Visible = True
                Txtshrt3.Text = dt.Rows(2)("shorttext")
                txtlng3.Text = dt.Rows(2)("longtext")
                ddlgl3.SelectedValue = dt.Rows(2)("glacct")
                txtqty3.Text = dt.Rows(2)("unitqty")
                txtprice3.Text = dt.Rows(2)("unitprc")
                ddluom3.SelectedValue = dt.Rows(2)("uom")
                txttotal3.Text = String.Format("${0:0.00}", tot2)
                ddltax3.SelectedValue = dt.Rows(2)("taxflag")
                'lbldelv3.Text = dt.Rows(2)("dlvdate")
                btnadd2.Visible = False
                btnrem1.Visible = False
                If Not IsDBNull(dt.Rows(2)("venitem")) Then
                    txtvenmat3.Text = dt.Rows(2)("venitem")
                Else
                    txtvenmat3.Text = ""
                End If
                If Not IsDBNull(dt.Rows(2)("refpart")) Then
                    txttrackno3.Text = dt.Rows(2)("refpart")
                Else
                    txttrackno3.Text = ""
                End If
                If Not IsDBNull(dt.Rows(2)("longtext")) Then
                    txtlng3.Text = dt.Rows(2)("longtext")
                Else
                    txtlng3.Text = ""
                End If
            End If
            If result > "3" Then
                tot3 = dt.Rows(3)("unitprc") * dt.Rows(3)("unitqty")
                Panel4.Visible = True
                Txtshrt4.Text = dt.Rows(3)("shorttext")
                txtlng4.Text = dt.Rows(3)("longtext")
                ddlgl4.SelectedValue = dt.Rows(3)("glacct")
                txtqty4.Text = dt.Rows(3)("unitqty")
                txtprice4.Text = dt.Rows(3)("unitprc")
                ddluom4.SelectedValue = dt.Rows(3)("uom")
                txttotal4.Text = String.Format("${0:0.00}", tot3)
                ddltax4.SelectedValue = dt.Rows(3)("taxflag")
                'lbldelv4.Text = dt.Rows(3)("dlvdate")
                btnadd3.Visible = False
                btnrem2.Visible = False
                If Not IsDBNull(dt.Rows(3)("venitem")) Then
                    txtvenmat4.Text = dt.Rows(3)("venitem")
                Else
                    txtvenmat4.Text = ""
                End If
                If Not IsDBNull(dt.Rows(3)("refpart")) Then
                    txttrackno4.Text = dt.Rows(3)("refpart")
                Else
                    txttrackno4.Text = ""
                End If
                If Not IsDBNull(dt.Rows(3)("longtext")) Then
                    txtlng4.Text = dt.Rows(3)("longtext")
                Else
                    txtlng4.Text = ""
                End If
            End If
            If result > "4" Then
                tot4 = dt.Rows(4)("unitprc") * dt.Rows(4)("unitqty")
                Panel5.Visible = True
                Txtshrt5.Text = dt.Rows(4)("shorttext")
                txtlng5.Text = dt.Rows(4)("longtext")
                ddlgl5.SelectedValue = dt.Rows(4)("glacct")
                txtqty5.Text = dt.Rows(4)("unitqty")
                txtprice5.Text = dt.Rows(4)("unitprc")
                ddluom5.SelectedValue = dt.Rows(4)("uom")
                txttotal5.Text = String.Format("${0:0.00}", tot4)
                ddltax5.SelectedValue = dt.Rows(4)("taxflag")
                'lbldelv5.Text = dt.Rows(4)("dlvdate")
                btnadd4.Visible = False
                btnrem3.Visible = False
                If Not IsDBNull(dt.Rows(4)("venitem")) Then
                    txtvenmat5.Text = dt.Rows(4)("venitem")
                Else
                    txtvenmat5.Text = ""
                End If
                If Not IsDBNull(dt.Rows(4)("refpart")) Then
                    txttrackno5.Text = dt.Rows(4)("refpart")
                Else
                    txttrackno5.Text = ""
                End If
                If Not IsDBNull(dt.Rows(4)("longtext")) Then
                    txtlng5.Text = dt.Rows(4)("longtext")
                Else
                    txtlng5.Text = ""
                End If
            End If
            If result > "5" Then
                tot5 = dt.Rows(5)("unitprc") * dt.Rows(5)("unitqty")
                Panel6.Visible = True
                Txtshrt6.Text = dt.Rows(5)("shorttext")
                txtlng6.Text = dt.Rows(5)("longtext")
                ddlgl6.SelectedValue = dt.Rows(5)("glacct")
                txtqty6.Text = dt.Rows(5)("unitqty")
                txtprice6.Text = dt.Rows(5)("unitprc")
                ddluom6.SelectedValue = dt.Rows(5)("uom")
                txttotal6.Text = String.Format("${0:0.00}", tot5)
                ddltax6.SelectedValue = dt.Rows(5)("taxflag")
                'lbldelv6.Text = dt.Rows(5)("dlvdate")
                btnadd5.Visible = False
                btnrem4.Visible = False
                If Not IsDBNull(dt.Rows(5)("venitem")) Then
                    txtvenmat6.Text = dt.Rows(5)("venitem")
                Else
                    txtvenmat6.Text = ""
                End If
                If Not IsDBNull(dt.Rows(5)("refpart")) Then
                    txttrackno6.Text = dt.Rows(5)("refpart")
                Else
                    txttrackno6.Text = ""
                End If
                If Not IsDBNull(dt.Rows(5)("longtext")) Then
                    txtlng6.Text = dt.Rows(5)("longtext")
                Else
                    txtlng6.Text = ""
                End If
            End If
            If result > "6" Then
                tot6 = dt.Rows(6)("unitprc") * dt.Rows(6)("unitqty")
                Panel7.Visible = True
                Txtshrt7.Text = dt.Rows(6)("shorttext")
                txtlng7.Text = dt.Rows(6)("longtext")
                ddlgl7.SelectedValue = dt.Rows(6)("glacct")
                txtqty7.Text = dt.Rows(6)("unitqty")
                txtprice7.Text = dt.Rows(6)("unitprc")
                ddluom7.SelectedValue = dt.Rows(6)("uom")
                txttotal7.Text = String.Format("${0:0.00}", tot6)
                ddltax7.SelectedValue = dt.Rows(6)("taxflag")
                'lbldelv7.Text = dt.Rows(6)("dlvdate")
                btnadd6.Visible = False
                btnrem5.Visible = False
                If Not IsDBNull(dt.Rows(6)("venitem")) Then
                    txtvenmat7.Text = dt.Rows(6)("venitem")
                Else
                    txtvenmat7.Text = ""
                End If
                If Not IsDBNull(dt.Rows(6)("refpart")) Then
                    txttrackno7.Text = dt.Rows(6)("refpart")
                Else
                    txttrackno7.Text = ""
                End If
                If Not IsDBNull(dt.Rows(6)("longtext")) Then
                    txtlng7.Text = dt.Rows(6)("longtext")
                Else
                    txtlng7.Text = ""
                End If
            End If
            If result > "7" Then
                tot7 = dt.Rows(7)("unitprc") * dt.Rows(7)("unitqty")
                Panel8.Visible = True
                Txtshrt8.Text = dt.Rows(7)("shorttext")
                txtlng8.Text = dt.Rows(7)("longtext")
                ddlgl8.SelectedValue = dt.Rows(7)("glacct")
                txtqty8.Text = dt.Rows(7)("unitqty")
                txtprice8.Text = dt.Rows(7)("unitprc")
                ddluom8.SelectedValue = dt.Rows(7)("uom")
                txttotal8.Text = String.Format("${0:0.00}", tot7)
                ddltax8.SelectedValue = dt.Rows(7)("taxflag")
                'lbldelv8.Text = dt.Rows(7)("dlvdate")
                btnadd7.Visible = False
                btnrem6.Visible = False
                If Not IsDBNull(dt.Rows(7)("venitem")) Then
                    txtvenmat8.Text = dt.Rows(7)("venitem")
                Else
                    txtvenmat8.Text = ""
                End If
                If Not IsDBNull(dt.Rows(7)("refpart")) Then
                    txttrackno8.Text = dt.Rows(7)("refpart")
                Else
                    txttrackno8.Text = ""
                End If
                If Not IsDBNull(dt.Rows(7)("longtext")) Then
                    txtlng8.Text = dt.Rows(7)("longtext")
                Else
                    txtlng8.Text = ""
                End If
            End If
            If result > "8" Then
                tot8 = dt.Rows(8)("unitprc") * dt.Rows(8)("unitqty")
                Panel9.Visible = True
                Txtshrt9.Text = dt.Rows(8)("shorttext")
                txtlng9.Text = dt.Rows(8)("longtext")
                ddlgl9.SelectedValue = dt.Rows(8)("glacct")
                txtqty9.Text = dt.Rows(8)("unitqty")
                txtprice9.Text = dt.Rows(8)("unitprc")
                ddluom9.SelectedValue = dt.Rows(8)("uom")
                txttotal9.Text = String.Format("${0:0.00}", tot8)
                ddltax9.SelectedValue = dt.Rows(8)("taxflag")
                'lbldelv9.Text = dt.Rows(8)("dlvdate")
                btnadd8.Visible = False
                btnrem7.Visible = False
                If Not IsDBNull(dt.Rows(8)("venitem")) Then
                    txtvenmat9.Text = dt.Rows(8)("venitem")
                Else
                    txtvenmat9.Text = ""
                End If
                If Not IsDBNull(dt.Rows(8)("refpart")) Then
                    txttrackno9.Text = dt.Rows(8)("refpart")
                Else
                    txttrackno9.Text = ""
                End If
                If Not IsDBNull(dt.Rows(8)("longtext")) Then
                    txtlng9.Text = dt.Rows(8)("longtext")
                Else
                    txtlng9.Text = ""
                End If
            End If
            If result > "9" Then
                tot9 = dt.Rows(9)("unitprc") * dt.Rows(9)("unitqty")
                Panel10.Visible = True
                Txtshrt10.Text = dt.Rows(9)("shorttext")
                txtlng10.Text = dt.Rows(9)("longtext")
                ddlgl10.SelectedValue = dt.Rows(9)("glacct")
                txtqty10.Text = dt.Rows(9)("unitqty")
                txtprice10.Text = dt.Rows(9)("unitprc")
                ddluom10.SelectedValue = dt.Rows(9)("uom")
                txttotal10.Text = String.Format("${0:0.00}", tot9)
                ddltax10.SelectedValue = dt.Rows(9)("taxflag")
                'lbldelv10.Text = dt.Rows(9)("dlvdate")
                btnadd9.Visible = False
                btnrem8.Visible = False
                If Not IsDBNull(dt.Rows(9)("venitem")) Then
                    txtvenmat10.Text = dt.Rows(9)("venitem")
                Else
                    txtvenmat10.Text = ""
                End If
                If Not IsDBNull(dt.Rows(9)("refpart")) Then
                    txttrackno10.Text = dt.Rows(9)("refpart")
                Else
                    txttrackno10.Text = ""
                End If
                If Not IsDBNull(dt.Rows(9)("longtext")) Then
                    txtlng10.Text = dt.Rows(9)("longtext")
                Else
                    txtlng10.Text = ""
                End If
            End If
            If result > "10" Then
                tot10 = dt.Rows(10)("unitprc") * dt.Rows(10)("unitqty")
                Panel11.Visible = True
                Txtshrt11.Text = dt.Rows(10)("shorttext")
                txtlng11.Text = dt.Rows(10)("longtext")
                ddlgl11.SelectedValue = dt.Rows(10)("glacct")
                txtqty11.Text = dt.Rows(10)("unitqty")
                txtprice11.Text = dt.Rows(10)("unitprc")
                ddluom11.SelectedValue = dt.Rows(10)("uom")
                txttotal11.Text = String.Format("${0:0.00}", tot10)
                ddltax11.SelectedValue = dt.Rows(10)("taxflag")
                'lbldelv11.Text = dt.Rows(10)("dlvdate")
                btnadd10.Visible = False
                btnrem9.Visible = False
                If Not IsDBNull(dt.Rows(10)("venitem")) Then
                    txtvenmat11.Text = dt.Rows(10)("venitem")
                Else
                    txtvenmat11.Text = ""
                End If
                If Not IsDBNull(dt.Rows(10)("refpart")) Then
                    txttrackno11.Text = dt.Rows(10)("refpart")
                Else
                    txttrackno11.Text = ""
                End If
                If Not IsDBNull(dt.Rows(10)("longtext")) Then
                    txtlng11.Text = dt.Rows(10)("longtext")
                Else
                    txtlng11.Text = ""
                End If
            End If
            If result > "11" Then
                tot11 = dt.Rows(11)("unitprc") * dt.Rows(11)("unitqty")
                Panel12.Visible = True
                Txtshrt12.Text = dt.Rows(11)("shorttext")
                txtlng12.Text = dt.Rows(11)("longtext")
                ddlgl12.SelectedValue = dt.Rows(11)("glacct")
                txtqty12.Text = dt.Rows(11)("unitqty")
                txtprice12.Text = dt.Rows(11)("unitprc")
                ddluom12.SelectedValue = dt.Rows(11)("uom")
                txttotal12.Text = String.Format("${0:0.00}", tot11)
                ddltax12.SelectedValue = dt.Rows(11)("taxflag")
                'lbldelv12.Text = dt.Rows(11)("dlvdate")
                btnadd11.Visible = False
                btnrem10.Visible = False
                If Not IsDBNull(dt.Rows(11)("venitem")) Then
                    txtvenmat12.Text = dt.Rows(11)("venitem")
                Else
                    txtvenmat12.Text = ""
                End If
                If Not IsDBNull(dt.Rows(11)("refpart")) Then
                    txttrackno12.Text = dt.Rows(11)("refpart")
                Else
                    txttrackno12.Text = ""
                End If
                If Not IsDBNull(dt.Rows(11)("longtext")) Then
                    txtlng12.Text = dt.Rows(11)("longtext")
                Else
                    txtlng12.Text = ""
                End If
            End If
            If result > "12" Then
                tot12 = dt.Rows(12)("unitprc") * dt.Rows(12)("unitqty")
                Panel13.Visible = True
                Txtshrt13.Text = dt.Rows(12)("shorttext")
                txtlng13.Text = dt.Rows(12)("longtext")
                ddlgl13.SelectedValue = dt.Rows(12)("glacct")
                txtqty13.Text = dt.Rows(12)("unitqty")
                txtprice13.Text = dt.Rows(12)("unitprc")
                ddluom13.SelectedValue = dt.Rows(12)("uom")
                txttotal13.Text = String.Format("${0:0.00}", tot12)
                ddltax13.SelectedValue = dt.Rows(12)("taxflag")
                'lbldelv13.Text = dt.Rows(12)("dlvdate")
                btnadd12.Visible = False
                btnrem11.Visible = False
                If Not IsDBNull(dt.Rows(12)("venitem")) Then
                    txtvenmat13.Text = dt.Rows(12)("venitem")
                Else
                    txtvenmat13.Text = ""
                End If
                If Not IsDBNull(dt.Rows(12)("refpart")) Then
                    txttrackno13.Text = dt.Rows(12)("refpart")
                Else
                    txttrackno13.Text = ""
                End If
                If Not IsDBNull(dt.Rows(12)("longtext")) Then
                    txtlng13.Text = dt.Rows(12)("longtext")
                Else
                    txtlng13.Text = ""
                End If
            End If
            If result > "13" Then
                tot13 = dt.Rows(13)("unitprc") * dt.Rows(13)("unitqty")
                Panel14.Visible = True
                Txtshrt14.Text = dt.Rows(13)("shorttext")
                txtlng14.Text = dt.Rows(13)("longtext")
                ddlgl14.SelectedValue = dt.Rows(13)("glacct")
                txtqty14.Text = dt.Rows(13)("unitqty")
                txtprice14.Text = dt.Rows(13)("unitprc")
                ddluom14.SelectedValue = dt.Rows(13)("uom")
                txttotal14.Text = String.Format("${0:0.00}", tot13)
                ddltax14.SelectedValue = dt.Rows(13)("taxflag")
                'lbldelv14.Text = dt.Rows(13)("dlvdate")
                btnadd13.Visible = False
                btnrem12.Visible = False
                If Not IsDBNull(dt.Rows(13)("venitem")) Then
                    txtvenmat14.Text = dt.Rows(13)("venitem")
                Else
                    txtvenmat14.Text = ""
                End If
                If Not IsDBNull(dt.Rows(13)("refpart")) Then
                    txttrackno14.Text = dt.Rows(13)("refpart")
                Else
                    txttrackno14.Text = ""
                End If
                If Not IsDBNull(dt.Rows(13)("longtext")) Then
                    txtlng14.Text = dt.Rows(13)("longtext")
                Else
                    txtlng14.Text = ""
                End If
            End If
            If result > "14" Then
                tot14 = dt.Rows(14)("unitprc") * dt.Rows(14)("unitqty")
                Panel15.Visible = True
                Txtshrt15.Text = dt.Rows(14)("shorttext")
                txtlng15.Text = dt.Rows(14)("longtext")
                ddlgl15.SelectedValue = dt.Rows(14)("glacct")
                txtqty15.Text = dt.Rows(14)("unitqty")
                txtprice15.Text = dt.Rows(14)("unitprc")
                ddluom15.SelectedValue = dt.Rows(14)("uom")
                txttotal15.Text = String.Format("${0:0.00}", tot14)
                ddltax15.SelectedValue = dt.Rows(14)("taxflag")
                'lbldelv15.Text = dt.Rows(14)("dlvdate")
                btnadd14.Visible = False
                btnrem13.Visible = False
                If Not IsDBNull(dt.Rows(14)("venitem")) Then
                    txtvenmat15.Text = dt.Rows(14)("venitem")
                Else
                    txtvenmat15.Text = ""
                End If
                If Not IsDBNull(dt.Rows(14)("refpart")) Then
                    txttrackno15.Text = dt.Rows(14)("refpart")
                Else
                    txttrackno15.Text = ""
                End If
                If Not IsDBNull(dt.Rows(14)("longtext")) Then
                    txtlng15.Text = dt.Rows(14)("longtext")
                Else
                    txtlng15.Text = ""
                End If
            End If
            If result > "15" Then
                tot15 = dt.Rows(15)("unitprc") * dt.Rows(15)("unitqty")
                Panel16.Visible = True
                Txtshrt16.Text = dt.Rows(15)("shorttext")
                txtlng16.Text = dt.Rows(15)("longtext")
                ddlgl16.SelectedValue = dt.Rows(15)("glacct")
                txtqty16.Text = dt.Rows(15)("unitqty")
                txtprice16.Text = dt.Rows(15)("unitprc")
                ddluom16.SelectedValue = dt.Rows(15)("uom")
                txttotal16.Text = String.Format("${0:0.00}", tot15)
                ddltax16.SelectedValue = dt.Rows(15)("taxflag")
                'lbldelv16.Text = dt.Rows(15)("dlvdate")
                btnadd15.Visible = False
                btnrem14.Visible = False
                If Not IsDBNull(dt.Rows(15)("venitem")) Then
                    txtvenmat16.Text = dt.Rows(15)("venitem")
                Else
                    txtvenmat16.Text = ""
                End If
                If Not IsDBNull(dt.Rows(15)("refpart")) Then
                    txttrackno16.Text = dt.Rows(15)("refpart")
                Else
                    txttrackno16.Text = ""
                End If
                If Not IsDBNull(dt.Rows(15)("longtext")) Then
                    txtlng16.Text = dt.Rows(15)("longtext")
                Else
                    txtlng16.Text = ""
                End If
            End If
            If result > "16" Then
                tot16 = dt.Rows(16)("unitprc") * dt.Rows(16)("unitqty")
                Panel17.Visible = True
                Txtshrt17.Text = dt.Rows(16)("shorttext")
                txtlng17.Text = dt.Rows(16)("longtext")
                ddlgl17.SelectedValue = dt.Rows(16)("glacct")
                txtqty17.Text = dt.Rows(16)("unitqty")
                txtprice17.Text = dt.Rows(16)("unitprc")
                ddluom17.SelectedValue = dt.Rows(16)("uom")
                txttotal17.Text = String.Format("${0:0.00}", tot16)
                ddltax17.SelectedValue = dt.Rows(16)("taxflag")
                'lbldelv17.Text = dt.Rows(16)("dlvdate")
                btnadd16.Visible = False
                btnrem15.Visible = False
                If Not IsDBNull(dt.Rows(16)("venitem")) Then
                    txtvenmat17.Text = dt.Rows(16)("venitem")
                Else
                    txtvenmat17.Text = ""
                End If
                If Not IsDBNull(dt.Rows(16)("refpart")) Then
                    txttrackno17.Text = dt.Rows(16)("refpart")
                Else
                    txttrackno17.Text = ""
                End If
                If Not IsDBNull(dt.Rows(16)("longtext")) Then
                    txtlng17.Text = dt.Rows(16)("longtext")
                Else
                    txtlng17.Text = ""
                End If
            End If
            If result > "17" Then
                tot17 = dt.Rows(17)("unitprc") * dt.Rows(17)("unitqty")
                Panel18.Visible = True
                Txtshrt18.Text = dt.Rows(17)("shorttext")
                txtlng18.Text = dt.Rows(17)("longtext")
                ddlgl18.SelectedValue = dt.Rows(17)("glacct")
                txtqty18.Text = dt.Rows(17)("unitqty")
                txtprice18.Text = dt.Rows(17)("unitprc")
                ddluom18.SelectedValue = dt.Rows(17)("uom")
                txttotal18.Text = String.Format("${0:0.00}", tot17)
                ddltax18.SelectedValue = dt.Rows(17)("taxflag")
                'lbldelv18.Text = dt.Rows(17)("dlvdate")
                btnadd17.Visible = False
                btnrem16.Visible = False
                If Not IsDBNull(dt.Rows(17)("venitem")) Then
                    txtvenmat18.Text = dt.Rows(17)("venitem")
                Else
                    txtvenmat18.Text = ""
                End If
                If Not IsDBNull(dt.Rows(17)("refpart")) Then
                    txttrackno18.Text = dt.Rows(17)("refpart")
                Else
                    txttrackno18.Text = ""
                End If
                If Not IsDBNull(dt.Rows(17)("longtext")) Then
                    txtlng18.Text = dt.Rows(17)("longtext")
                Else
                    txtlng18.Text = ""
                End If
            End If
            If result > "18" Then
                tot18 = dt.Rows(18)("unitprc") * dt.Rows(18)("unitqty")
                Panel19.Visible = True
                Txtshrt19.Text = dt.Rows(18)("shorttext")
                txtlng19.Text = dt.Rows(18)("longtext")
                ddlgl19.SelectedValue = dt.Rows(18)("glacct")
                txtqty19.Text = dt.Rows(18)("unitqty")
                txtprice19.Text = dt.Rows(18)("unitprc")
                ddluom19.SelectedValue = dt.Rows(18)("uom")
                txttotal19.Text = String.Format("${0:0.00}", tot18)
                ddltax19.SelectedValue = dt.Rows(18)("taxflag")
                'lbldelv19.Text = dt.Rows(18)("dlvdate")
                btnadd18.Visible = False
                btnrem17.Visible = False
                If Not IsDBNull(dt.Rows(18)("venitem")) Then
                    txtvenmat19.Text = dt.Rows(18)("venitem")
                Else
                    txtvenmat19.Text = ""
                End If
                If Not IsDBNull(dt.Rows(18)("refpart")) Then
                    txttrackno19.Text = dt.Rows(18)("refpart")
                Else
                    txttrackno19.Text = ""
                End If
                If Not IsDBNull(dt.Rows(18)("longtext")) Then
                    txtlng19.Text = dt.Rows(18)("longtext")
                Else
                    txtlng19.Text = ""
                End If
            End If
            If result > "19" Then
                tot19 = dt.Rows(19)("unitprc") * dt.Rows(19)("unitqty")
                Panel20.Visible = True
                Txtshrt20.Text = dt.Rows(19)("shorttext")
                txtlng20.Text = dt.Rows(19)("longtext")
                ddlgl20.SelectedValue = dt.Rows(19)("glacct")
                txtqty20.Text = dt.Rows(19)("unitqty")
                txtprice20.Text = dt.Rows(19)("unitprc")
                ddluom20.SelectedValue = dt.Rows(19)("uom")
                txttotal20.Text = String.Format("${0:0.00}", tot19)
                ddltax20.SelectedValue = dt.Rows(19)("taxflag")
                'lbldelv20.Text = dt.Rows(19)("dlvdate")
                btnadd19.Visible = False
                btnrem18.Visible = False
                If Not IsDBNull(dt.Rows(19)("venitem")) Then
                    txtvenmat20.Text = dt.Rows(19)("venitem")
                Else
                    txtvenmat20.Text = ""
                End If
                If Not IsDBNull(dt.Rows(19)("refpart")) Then
                    txttrackno20.Text = dt.Rows(19)("refpart")
                Else
                    txttrackno20.Text = ""
                End If
                If Not IsDBNull(dt.Rows(19)("longtext")) Then
                    txtlng20.Text = dt.Rows(19)("longtext")
                Else
                    txtlng20.Text = ""
                End If
            End If
            If result > "20" Then
                tot20 = dt.Rows(20)("unitprc") * dt.Rows(20)("unitqty")
                Panel21.Visible = True
                Txtshrt21.Text = dt.Rows(20)("shorttext")
                txtlng21.Text = dt.Rows(20)("longtext")
                ddlgl21.SelectedValue = dt.Rows(20)("glacct")
                txtqty21.Text = dt.Rows(20)("unitqty")
                txtprice21.Text = dt.Rows(20)("unitprc")
                ddluom21.SelectedValue = dt.Rows(20)("uom")
                txttotal21.Text = String.Format("${0:0.00}", tot20)
                ddltax21.SelectedValue = dt.Rows(20)("taxflag")
                'lbldelv21.Text = dt.Rows(20)("dlvdate")
                btnadd20.Visible = False
                btnrem19.Visible = False
                If Not IsDBNull(dt.Rows(20)("venitem")) Then
                    txtvenmat21.Text = dt.Rows(20)("venitem")
                Else
                    txtvenmat21.Text = ""
                End If
                If Not IsDBNull(dt.Rows(20)("refpart")) Then
                    txttrackno21.Text = dt.Rows(20)("refpart")
                Else
                    txttrackno21.Text = ""
                End If
                If Not IsDBNull(dt.Rows(20)("longtext")) Then
                    txtlng21.Text = dt.Rows(20)("longtext")
                Else
                    txtlng21.Text = ""
                End If
            End If
            If result > "21" Then
                tot21 = dt.Rows(21)("unitprc") * dt.Rows(21)("unitqty")
                Panel22.Visible = True
                Txtshrt22.Text = dt.Rows(21)("shorttext")
                txtlng22.Text = dt.Rows(21)("longtext")
                ddlgl22.SelectedValue = dt.Rows(21)("glacct")
                txtqty22.Text = dt.Rows(21)("unitqty")
                txtprice22.Text = dt.Rows(21)("unitprc")
                ddluom22.SelectedValue = dt.Rows(21)("uom")
                txttotal22.Text = String.Format("${0:0.00}", tot21)
                ddltax22.SelectedValue = dt.Rows(21)("taxflag")
                'lbldelv22.Text = dt.Rows(21)("dlvdate")
                btnadd21.Visible = False
                btnrem20.Visible = False
                If Not IsDBNull(dt.Rows(21)("venitem")) Then
                    txtvenmat22.Text = dt.Rows(21)("venitem")
                Else
                    txtvenmat22.Text = ""
                End If
                If Not IsDBNull(dt.Rows(21)("refpart")) Then
                    txttrackno22.Text = dt.Rows(21)("refpart")
                Else
                    txttrackno22.Text = ""
                End If
                If Not IsDBNull(dt.Rows(21)("longtext")) Then
                    txtlng22.Text = dt.Rows(21)("longtext")
                Else
                    txtlng22.Text = ""
                End If
            End If
            If result > "22" Then
                tot22 = dt.Rows(22)("unitprc") * dt.Rows(22)("unitqty")
                Panel23.Visible = True
                Txtshrt23.Text = dt.Rows(22)("shorttext")
                txtlng23.Text = dt.Rows(22)("longtext")
                ddlgl23.SelectedValue = dt.Rows(22)("glacct")
                txtqty23.Text = dt.Rows(22)("unitqty")
                txtprice23.Text = dt.Rows(22)("unitprc")
                ddluom23.SelectedValue = dt.Rows(22)("uom")
                txttotal23.Text = String.Format("${0:0.00}", tot22)
                ddltax23.SelectedValue = dt.Rows(22)("taxflag")
                'lbldelv23.Text = dt.Rows(22)("dlvdate")
                btnadd22.Visible = False
                btnrem21.Visible = False
                If Not IsDBNull(dt.Rows(22)("venitem")) Then
                    txtvenmat23.Text = dt.Rows(22)("venitem")
                Else
                    txtvenmat23.Text = ""
                End If
                If Not IsDBNull(dt.Rows(22)("refpart")) Then
                    txttrackno23.Text = dt.Rows(22)("refpart")
                Else
                    txttrackno23.Text = ""
                End If
                If Not IsDBNull(dt.Rows(22)("longtext")) Then
                    txtlng23.Text = dt.Rows(22)("longtext")
                Else
                    txtlng23.Text = ""
                End If
            End If
            If result > "23" Then
                tot23 = dt.Rows(23)("unitprc") * dt.Rows(23)("unitqty")
                Panel24.Visible = True
                Txtshrt24.Text = dt.Rows(23)("shorttext")
                txtlng24.Text = dt.Rows(23)("longtext")
                ddlgl24.SelectedValue = dt.Rows(23)("glacct")
                txtqty24.Text = dt.Rows(23)("unitqty")
                txtprice24.Text = dt.Rows(23)("unitprc")
                ddluom24.SelectedValue = dt.Rows(23)("uom")
                txttotal24.Text = String.Format("${0:0.00}", tot23)
                ddltax24.SelectedValue = dt.Rows(23)("taxflag")
                'lbldelv24.Text = dt.Rows(23)("dlvdate")
                btnadd23.Visible = False
                btnrem22.Visible = False
                If Not IsDBNull(dt.Rows(23)("venitem")) Then
                    txtvenmat24.Text = dt.Rows(23)("venitem")
                Else
                    txtvenmat24.Text = ""
                End If
                If Not IsDBNull(dt.Rows(23)("refpart")) Then
                    txttrackno24.Text = dt.Rows(23)("refpart")
                Else
                    txttrackno24.Text = ""
                End If
                If Not IsDBNull(dt.Rows(23)("longtext")) Then
                    txtlng24.Text = dt.Rows(23)("longtext")
                Else
                    txtlng24.Text = ""
                End If

            End If
            If result > "24" Then
                tot24 = dt.Rows(24)("unitprc") * dt.Rows(24)("unitqty")
                Panel25.Visible = True
                Txtshrt25.Text = dt.Rows(24)("shorttext")
                txtlng25.Text = dt.Rows(24)("longtext")
                ddlgl25.SelectedValue = dt.Rows(24)("glacct")
                txtqty25.Text = dt.Rows(24)("unitqty")
                txtprice25.Text = dt.Rows(24)("unitprc")
                ddluom25.SelectedValue = dt.Rows(24)("uom")
                txttotal25.Text = String.Format("${0:0.00}", tot24)
                ddltax25.SelectedValue = dt.Rows(24)("taxflag")
                'lbldelv25.Text = dt.Rows(24)("dlvdate")
                btnadd24.Visible = False
                btnrem23.Visible = False
                If Not IsDBNull(dt.Rows(24)("venitem")) Then
                    txtvenmat25.Text = dt.Rows(24)("venitem")
                Else
                    txtvenmat25.Text = ""
                End If
                If Not IsDBNull(dt.Rows(24)("refpart")) Then
                    txttrackno25.Text = dt.Rows(24)("refpart")
                Else
                    txttrackno25.Text = ""
                End If
                If Not IsDBNull(dt.Rows(24)("longtext")) Then
                    txtlng25.Text = dt.Rows(24)("longtext")
                Else
                    txtlng25.Text = ""
                End If
            End If
            If result > "25" Then
                tot25 = dt.Rows(25)("unitprc") * dt.Rows(25)("unitqty")
                Panel26.Visible = True
                Txtshrt26.Text = dt.Rows(25)("shorttext")
                txtlng26.Text = dt.Rows(25)("longtext")
                ddlgl26.SelectedValue = dt.Rows(25)("glacct")
                txtqty26.Text = dt.Rows(25)("unitqty")
                txtprice26.Text = dt.Rows(25)("unitprc")
                ddluom26.SelectedValue = dt.Rows(25)("uom")
                txttotal26.Text = String.Format("${0:0.00}", tot25)
                ddltax26.SelectedValue = dt.Rows(25)("taxflag")
                'lbldelv26.Text = dt.Rows(25)("dlvdate")
                btnadd25.Visible = False
                btnrem24.Visible = False
                If Not IsDBNull(dt.Rows(25)("venitem")) Then
                    txtvenmat26.Text = dt.Rows(25)("venitem")
                Else
                    txtvenmat26.Text = ""
                End If
                If Not IsDBNull(dt.Rows(25)("refpart")) Then
                    txttrackno26.Text = dt.Rows(25)("refpart")
                Else
                    txttrackno26.Text = ""
                End If
                If Not IsDBNull(dt.Rows(25)("longtext")) Then
                    txtlng26.Text = dt.Rows(25)("longtext")
                Else
                    txtlng26.Text = ""
                End If
            End If
            If result > "26" Then
                tot26 = dt.Rows(26)("unitprc") * dt.Rows(26)("unitqty")
                Panel27.Visible = True
                Txtshrt27.Text = dt.Rows(26)("shorttext")
                txtlng27.Text = dt.Rows(26)("longtext")
                ddlgl27.SelectedValue = dt.Rows(26)("glacct")
                txtqty27.Text = dt.Rows(26)("unitqty")
                txtprice27.Text = dt.Rows(26)("unitprc")
                ddluom27.SelectedValue = dt.Rows(26)("uom")
                txttotal27.Text = String.Format("${0:0.00}", tot26)
                ddltax27.SelectedValue = dt.Rows(26)("taxflag")
                'lbldelv27.Text = dt.Rows(26)("dlvdate")
                btnadd26.Visible = False
                btnrem25.Visible = False
                If Not IsDBNull(dt.Rows(26)("venitem")) Then
                    txtvenmat27.Text = dt.Rows(26)("venitem")
                Else
                    txtvenmat27.Text = ""
                End If
                If Not IsDBNull(dt.Rows(26)("refpart")) Then
                    txttrackno27.Text = dt.Rows(26)("refpart")
                Else
                    txttrackno27.Text = ""
                End If
                If Not IsDBNull(dt.Rows(26)("longtext")) Then
                    txtlng27.Text = dt.Rows(26)("longtext")
                Else
                    txtlng27.Text = ""
                End If
            End If
            If result > "27" Then
                tot27 = dt.Rows(27)("unitprc") * dt.Rows(27)("unitqty")
                Panel28.Visible = True
                Txtshrt28.Text = dt.Rows(27)("shorttext")
                txtlng28.Text = dt.Rows(27)("longtext")
                ddlgl28.SelectedValue = dt.Rows(27)("glacct")
                txtqty28.Text = dt.Rows(27)("unitqty")
                txtprice28.Text = dt.Rows(27)("unitprc")
                ddluom28.SelectedValue = dt.Rows(27)("uom")
                txttotal28.Text = String.Format("${0:0.00}", tot27)
                ddltax28.SelectedValue = dt.Rows(27)("taxflag")
                'lbldelv28.Text = dt.Rows(27)("dlvdate")
                btnadd27.Visible = False
                btnrem26.Visible = False
                If Not IsDBNull(dt.Rows(27)("venitem")) Then
                    txtvenmat28.Text = dt.Rows(27)("venitem")
                Else
                    txtvenmat28.Text = ""
                End If
                If Not IsDBNull(dt.Rows(27)("refpart")) Then
                    txttrackno28.Text = dt.Rows(27)("refpart")
                Else
                    txttrackno28.Text = ""
                End If
                If Not IsDBNull(dt.Rows(27)("longtext")) Then
                    txtlng28.Text = dt.Rows(27)("longtext")
                Else
                    txtlng28.Text = ""
                End If
            End If
            If result > "28" Then
                tot28 = dt.Rows(28)("unitprc") * dt.Rows(28)("unitqty")
                Panel29.Visible = True
                Txtshrt29.Text = dt.Rows(28)("shorttext")
                txtlng29.Text = dt.Rows(28)("longtext")
                ddlgl29.SelectedValue = dt.Rows(28)("glacct")
                txtqty29.Text = dt.Rows(28)("unitqty")
                txtprice29.Text = dt.Rows(28)("unitprc")
                ddluom29.SelectedValue = dt.Rows(28)("uom")
                txttotal29.Text = String.Format("${0:0.00}", tot28)
                ddltax29.SelectedValue = dt.Rows(28)("taxflag")
                'lbldelv29.Text = dt.Rows(28)("dlvdate")
                btnadd28.Visible = False
                btnrem27.Visible = False
                If Not IsDBNull(dt.Rows(28)("venitem")) Then
                    txtvenmat29.Text = dt.Rows(28)("venitem")
                Else
                    txtvenmat29.Text = ""
                End If
                If Not IsDBNull(dt.Rows(28)("refpart")) Then
                    txttrackno29.Text = dt.Rows(28)("refpart")
                Else
                    txttrackno29.Text = ""
                End If
                If Not IsDBNull(dt.Rows(28)("longtext")) Then
                    txtlng29.Text = dt.Rows(28)("longtext")
                Else
                    txtlng29.Text = ""
                End If
            End If
            If result > "29" Then
                tot29 = dt.Rows(29)("unitprc") * dt.Rows(29)("unitqty")
                Panel30.Visible = True
                Txtshrt30.Text = dt.Rows(29)("shorttext")
                txtlng30.Text = dt.Rows(29)("longtext")
                ddlgl30.SelectedValue = dt.Rows(29)("glacct")
                txtqty30.Text = dt.Rows(29)("unitqty")
                txtprice30.Text = dt.Rows(29)("unitprc")
                ddluom30.SelectedValue = dt.Rows(29)("uom")
                txttotal30.Text = String.Format("${0:0.00}", tot29)
                ddltax30.SelectedValue = dt.Rows(29)("taxflag")
                'lbldelv30.Text = dt.Rows(29)("dlvdate")
                btnadd29.Visible = False
                btnrem28.Visible = False
                If Not IsDBNull(dt.Rows(29)("venitem")) Then
                    txtvenmat30.Text = dt.Rows(29)("venitem")
                Else
                    txtvenmat30.Text = ""
                End If
                If Not IsDBNull(dt.Rows(29)("refpart")) Then
                    txttrackno30.Text = dt.Rows(29)("refpart")
                Else
                    txttrackno30.Text = ""
                End If
                If Not IsDBNull(dt.Rows(29)("longtext")) Then
                    txtlng30.Text = dt.Rows(29)("longtext")
                Else
                    txtlng30.Text = ""
                End If
            End If
            con.Close()
        End If
        'ddlccenter.databind()


        'cmd.Connection = con
        'cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
        'Dim result As Object = cmd.ExecuteScalar
        'lblresult.Text = String.Format(result) + 1
        'cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.Text & "', '" & ddlcpfr.SelectedValue & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "','" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & Txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "')"
        'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate, subdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddlcpfr.Text & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "','" & DateTime.Now & "')"
        'cmd.ExecuteNonQuery()


    End Sub
    Protected Sub ddlccenter_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlccenter.DataBound
        ddlccenter.Items.Insert(0, New ListItem("---Select Cost Center---", "---Select Cost Center---"))
        'ddlccenter.SelectedValue = "---Select Cost Center---"
        ddlccenter.items.insert(0, New ListItem("", ""))
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        ddlccenter.databind()
        If RadioButtonList1.SelectedValue = "MRO" Then
            ddlccenter.visible = True
            valddlccenter.visible = True
            valddlccenterblnk.visible = True
            ddlccenter.selectedvalue = "---Select Cost Center---"
            lblccenter.visible = True
            'ddcpfr.DataSource = CPFR
            'ddcpfr.DataSourceID = ""
            'ddlcpfr.DataBind()
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = gl
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gl
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = gl
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = gl
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = gl
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = gl
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = gl
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = gl
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = gl
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = gl
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = gl
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = gl
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = gl
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = gl
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = gl
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = gl
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = gl
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = gl
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = gl
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = gl
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = gl
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = gl
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = gl
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = gl
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = gl
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = gl
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = gl
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = gl
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = gl
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = gl
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.Visible = False
            ddcpfr.selectedvalue = ""
            ddlcpfr.Visible = False
            txtacctcat.Text = "K"
            ValCPFR.Visible = False
            valCPFRblnk.Visible = False
            lblgroup.Text = "MRO"
        ElseIf RadioButtonList1.SelectedValue = "IO1" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            lblgroup.Text = "IO1"
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glf
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glf
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glf
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glf
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glf
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glf
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glf
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glf
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glf
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glf
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glf
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glf
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glf
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glf
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glf
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glf
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glf
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glf
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glf
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glf
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glf
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glf
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glf
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glf
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glf
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glf
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glf
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glf
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glf
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glf
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.DataSource = cpfrio1
            ddcpfr.DataSourceID = ""
            ddcpfr.DataBind()
            ddcpfr.Visible = True
            ddlcpfr.Visible = True
            txtacctcat.Text = "F"
            ValCPFR.Visible = True
            valCPFRblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO2" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            lblgroup.Text = "IO2"
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glf
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glf
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glf
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glf
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glf
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glf
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glf
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glf
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glf
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glf
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glf
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glf
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glf
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glf
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glf
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glf
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glf
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glf
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glf
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glf
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glf
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glf
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glf
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glf
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glf
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glf
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glf
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glf
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glf
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glf
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.DataSource = cpfrio2
            ddcpfr.DataSourceID = ""
            ddcpfr.DataBind()
            ddcpfr.Visible = True
            ddlcpfr.Visible = True
            txtacctcat.Text = "F"
            ValCPFR.Visible = True
            valCPFRblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO3" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            lblgroup.Text = "IO3"
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glf
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glf
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glf
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glf
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glf
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glf
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glf
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glf
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glf
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glf
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glf
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glf
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glf
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glf
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glf
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glf
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glf
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glf
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glf
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glf
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glf
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glf
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glf
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glf
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glf
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glf
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glf
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glf
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glf
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glf
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.DataSource = cpfrio3
            ddcpfr.DataSourceID = ""
            ddcpfr.DataBind()
            ddcpfr.Visible = True
            ddlcpfr.Visible = True
            txtacctcat.Text = "F"
            ValCPFR.Visible = True
            valCPFRblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO4" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            lblgroup.Text = "IO4"
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glh
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glh
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glh
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glh
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glh
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glh
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glh
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glh
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glh
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glh
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glh
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glh
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glh
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glh
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glh
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glh
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glh
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glh
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glh
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glh
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glh
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glh
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glh
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glh
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glh
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glh
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glh
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glh
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glh
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glh
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.DataSource = cpfrio4
            ddcpfr.DataSourceID = ""
            ddcpfr.DataBind()
            ddcpfr.Visible = True
            ddlcpfr.Visible = True
            txtacctcat.Text = "H"
            ValCPFR.Visible = True
            valCPFRblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO5" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            lblgroup.Text = "IO5"
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = gli
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gli
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = gli
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = gli
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = gli
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = gli
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = gli
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = gli
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = gli
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = gli
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = gli
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = gli
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = gli
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = gli
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = gli
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = gli
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = gli
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = gli
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = gli
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = gli
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = gli
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = gli
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = gli
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = gli
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = gli
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = gli
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = gli
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = gli
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = gli
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = gli
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.DataSource = cpfrio5
            ddcpfr.DataSourceID = ""
            ddcpfr.DataBind()
            ddcpfr.Visible = True
            ddlcpfr.Visible = True
            txtacctcat.Text = "I"
            ValCPFR.Visible = True
            valCPFRblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "IO6" Then
            ddlccenter.selectedvalue = ""
            ddlccenter.visible = False
            valddlccenter.visible = False
            valddlccenterblnk.visible = False
            lblccenter.visible = False
            lblgroup.Text = "IO6"
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glj
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = glj
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = glj
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = glj
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = glj
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = glj
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = glj
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = glj
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = glj
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = glj
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = glj
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = glj
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = glj
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = glj
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = glj
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = glj
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = glj
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = glj
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = glj
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = glj
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = glj
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = glj
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = glj
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = glj
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = glj
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = glj
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = glj
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = glj
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = glj
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = glj
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.DataSource = cpfrio6
            ddcpfr.DataSourceID = ""
            ddcpfr.DataBind()
            ddcpfr.Visible = True
            ddlcpfr.Visible = True
            txtacctcat.Text = "J"
            ValCPFR.Visible = True
            valCPFRblnk.Visible = True
        ElseIf RadioButtonList1.SelectedValue = "REW" Then
            ddlccenter.SelectedValue = ""
            ddlccenter.Visible = False
            valddlccenter.Visible = False
            valddlccenterblnk.Visible = False
            lblccenter.Visible = False
            lblgroup.Text = "REW"
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = GLr
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = GLr
            ddlgl3.DataSourceID = ""
            ddlgl3.DataSource = GLr
            ddlgl4.DataSourceID = ""
            ddlgl4.DataSource = GLr
            ddlgl5.DataSourceID = ""
            ddlgl5.DataSource = GLr
            ddlgl6.DataSourceID = ""
            ddlgl6.DataSource = GLr
            ddlgl7.DataSourceID = ""
            ddlgl7.DataSource = GLr
            ddlgl8.DataSourceID = ""
            ddlgl8.DataSource = GLr
            ddlgl9.DataSourceID = ""
            ddlgl9.DataSource = GLr
            ddlgl10.DataSourceID = ""
            ddlgl10.DataSource = GLr
            ddlgl11.DataSourceID = ""
            ddlgl11.DataSource = GLr
            ddlgl12.DataSourceID = ""
            ddlgl12.DataSource = GLr
            ddlgl13.DataSourceID = ""
            ddlgl13.DataSource = GLr
            ddlgl14.DataSourceID = ""
            ddlgl14.DataSource = GLr
            ddlgl15.DataSourceID = ""
            ddlgl15.DataSource = GLr
            ddlgl16.DataSourceID = ""
            ddlgl16.DataSource = GLr
            ddlgl17.DataSourceID = ""
            ddlgl17.DataSource = GLr
            ddlgl18.DataSourceID = ""
            ddlgl18.DataSource = GLr
            ddlgl19.DataSourceID = ""
            ddlgl19.DataSource = GLr
            ddlgl20.DataSourceID = ""
            ddlgl20.DataSource = GLr
            ddlgl21.DataSourceID = ""
            ddlgl21.DataSource = GLr
            ddlgl22.DataSourceID = ""
            ddlgl22.DataSource = GLr
            ddlgl23.DataSourceID = ""
            ddlgl23.DataSource = GLr
            ddlgl24.DataSourceID = ""
            ddlgl24.DataSource = GLr
            ddlgl25.DataSourceID = ""
            ddlgl25.DataSource = GLr
            ddlgl26.DataSourceID = ""
            ddlgl26.DataSource = GLr
            ddlgl27.DataSourceID = ""
            ddlgl27.DataSource = GLr
            ddlgl28.DataSourceID = ""
            ddlgl28.DataSource = GLr
            ddlgl29.DataSourceID = ""
            ddlgl29.DataSource = GLr
            ddlgl30.DataSourceID = ""
            ddlgl30.DataSource = GLr
            ddlgl1.DataBind()
            ddlgl2.DataBind()
            ddlgl3.DataBind()
            ddlgl4.DataBind()
            ddlgl5.DataBind()
            ddlgl6.DataBind()
            ddlgl7.DataBind()
            ddlgl8.DataBind()
            ddlgl9.DataBind()
            ddlgl10.DataBind()
            ddlgl11.DataBind()
            ddlgl12.DataBind()
            ddlgl13.DataBind()
            ddlgl14.DataBind()
            ddlgl15.DataBind()
            ddlgl16.DataBind()
            ddlgl17.DataBind()
            ddlgl18.DataBind()
            ddlgl19.DataBind()
            ddlgl20.DataBind()
            ddlgl21.DataBind()
            ddlgl22.DataBind()
            ddlgl23.DataBind()
            ddlgl24.DataBind()
            ddlgl25.DataBind()
            ddlgl26.DataBind()
            ddlgl27.DataBind()
            ddlgl28.DataBind()
            ddlgl29.DataBind()
            ddlgl30.DataBind()
            ddcpfr.DataSource = CPFRrew
            ddcpfr.DataSourceID = ""
            ddcpfr.DataBind()
            ddcpfr.Visible = True
            ddlcpfr.Visible = True
            txtacctcat.Text = "R"
            ValCPFR.Visible = True
            valCPFRblnk.Visible = True
        End If
    End Sub
    Protected Sub ddlgl1_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl1.DataBound

            ddlgl1.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl2_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl2.DataBound
        ddlgl2.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))
        If RadioButtonList1.SelectedValue = "MRO" Then
            ddlgl1.DataSourceID = ""
            ddlgl1.DataSource = glj

        End If


    End Sub
    Protected Sub ddlgl3_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl3.DataBound
        ddlgl3.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))



    End Sub
    Protected Sub ddlgl4_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl4.DataBound
        ddlgl4.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl5_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl5.DataBound
        ddlgl5.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl6_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl6.DataBound
        ddlgl6.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl7_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl7.DataBound
        ddlgl7.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl8_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl8.DataBound
        ddlgl8.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl9_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl9.DataBound
        ddlgl9.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl10_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl10.DataBound
        ddlgl10.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl11_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl11.DataBound
        ddlgl11.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl12_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl12.DataBound
        ddlgl12.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl13_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl13.DataBound
        ddlgl13.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl14_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl14.DataBound
        ddlgl14.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl15_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl15.DataBound
        ddlgl15.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl16_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl16.DataBound
        ddlgl16.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub

    Protected Sub ddlgl17_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl17.DataBound
        ddlgl17.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl18_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl18.DataBound
        ddlgl18.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl19_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl19.DataBound
        ddlgl19.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl20_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl20.DataBound
        ddlgl20.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl21_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl21.DataBound
        ddlgl21.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl22_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl22.DataBound
        ddlgl22.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl23_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl23.DataBound
        ddlgl23.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl24_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl24.DataBound
        ddlgl24.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl25_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl25.DataBound
        ddlgl25.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl26_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl26.DataBound
        ddlgl26.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl27_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl27.DataBound
        ddlgl27.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl28_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl28.DataBound
        ddlgl28.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl29_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl29.DataBound
        ddlgl29.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub
    Protected Sub ddlgl30_DataBound(sender As Object, e As System.EventArgs) Handles ddlgl30.DataBound
        ddlgl30.Items.Insert(0, New ListItem("--- Select Account ---", "--- Select Account ---"))


    End Sub

    Protected Sub btnadd1_Click(sender As Object, e As System.EventArgs) Handles btnadd1.Click
        Panel2.Visible = True
        btnadd1.Visible = False
        'ddlgl2.DataBind()
        txtprice2.Text = ""
        If RadioButtonList1.SelectedValue = "MRO" Then
            ddlgl2.DataSourceID = ""
            ddlgl2.DataSource = gl
            ddlgl2.DataBind()
        End If

    End Sub

    Protected Sub btnadd2_Click(sender As Object, e As System.EventArgs) Handles btnadd2.Click
        Panel3.Visible = True
        btnadd2.Visible = False
        ddlgl3.DataBind()
        txtprice3.Text = ""
        btnrem1.Visible = False
    End Sub

    Protected Sub btnadd3_Click(sender As Object, e As System.EventArgs) Handles btnadd3.Click
        Panel4.Visible = True
        btnadd3.Visible = False
        ddlgl4.DataBind()
        txtprice4.Text = ""
        btnrem2.Visible = False
    End Sub

    Protected Sub btnadd4_Click(sender As Object, e As System.EventArgs) Handles btnadd4.Click
        Panel5.Visible = True
        btnadd4.Visible = False
        ddlgl5.DataBind()
        txtprice5.Text = ""
        btnrem3.Visible = False
    End Sub

    Protected Sub btnadd5_Click(sender As Object, e As System.EventArgs) Handles btnadd5.Click
        Panel6.Visible = True
        btnadd5.Visible = False
        ddlgl6.DataBind()
        txtprice6.Text = ""
        btnrem4.Visible = False
    End Sub

    Protected Sub btnadd6_Click(sender As Object, e As System.EventArgs) Handles btnadd6.Click
        Panel7.Visible = True
        btnadd6.Visible = False
        ddlgl7.DataBind()
        txtprice7.Text = ""
        btnrem5.Visible = False
    End Sub

    Protected Sub btnadd7_Click(sender As Object, e As System.EventArgs) Handles btnadd7.Click
        Panel8.Visible = True
        btnadd7.Visible = False
        ddlgl8.DataBind()
        txtprice8.Text = ""
        btnrem6.Visible = False
    End Sub

    Protected Sub btnadd8_Click(sender As Object, e As System.EventArgs) Handles btnadd8.Click
        Panel9.Visible = True
        btnadd8.Visible = False
        ddlgl9.DataBind()
        txtprice9.Text = ""
        btnrem7.Visible = False
    End Sub

    Protected Sub btnadd9_Click(sender As Object, e As System.EventArgs) Handles btnadd9.Click
        Panel10.Visible = True
        btnadd9.Visible = False
        ddlgl10.DataBind()
        txtprice10.Text = ""
        btnrem8.Visible = False
    End Sub

    Protected Sub btnadd10_Click(sender As Object, e As System.EventArgs) Handles btnadd10.Click
        Panel11.Visible = True
        btnadd10.Visible = False
        ddlgl11.DataBind()
        txtprice11.Text = ""
        btnrem9.Visible = False
    End Sub

    Protected Sub btnadd11_Click(sender As Object, e As System.EventArgs) Handles btnadd11.Click
        Panel12.Visible = True
        btnadd11.Visible = False
        ddlgl12.DataBind()
        txtprice12.Text = ""
        btnrem10.Visible = False
    End Sub

    Protected Sub btnadd12_Click(sender As Object, e As System.EventArgs) Handles btnadd12.Click
        Panel13.Visible = True
        btnadd12.Visible = False
        ddlgl13.DataBind()
        txtprice13.Text = ""
        btnrem11.Visible = False
    End Sub

    Protected Sub btnadd13_Click(sender As Object, e As System.EventArgs) Handles btnadd13.Click
        Panel14.Visible = True
        btnadd13.Visible = False
        ddlgl14.DataBind()
        txtprice14.Text = ""
        btnrem12.Visible = False
    End Sub

    Protected Sub btnadd14_Click(sender As Object, e As System.EventArgs) Handles btnadd14.Click
        Panel15.Visible = True
        btnadd14.Visible = False
        ddlgl15.DataBind()
        txtprice15.Text = ""
        btnrem13.Visible = False
    End Sub

    Protected Sub btnadd15_Click(sender As Object, e As System.EventArgs) Handles btnadd15.Click
        Panel16.Visible = True
        btnadd15.Visible = False
        ddlgl16.DataBind()
        txtprice16.Text = ""
        btnrem14.Visible = False
    End Sub

    Protected Sub btnadd16_Click(sender As Object, e As System.EventArgs) Handles btnadd16.Click
        Panel17.Visible = True
        btnadd16.Visible = False
        ddlgl17.DataBind()
        txtprice17.Text = ""
        btnrem15.Visible = False
    End Sub

    Protected Sub btnadd17_Click(sender As Object, e As System.EventArgs) Handles btnadd17.Click
        Panel18.Visible = True
        btnadd17.Visible = False
        ddlgl18.DataBind()
        txtprice18.Text = ""
        btnrem16.Visible = False
    End Sub

    Protected Sub btnadd18_Click(sender As Object, e As System.EventArgs) Handles btnadd18.Click
        Panel19.Visible = True
        btnadd18.Visible = False
        ddlgl19.DataBind()
        txtprice19.Text = ""
        btnrem17.Visible = False
    End Sub

    Protected Sub btnadd19_Click(sender As Object, e As System.EventArgs) Handles btnadd19.Click
        Panel20.Visible = True
        btnadd19.Visible = False
        ddlgl20.DataBind()
        txtprice20.Text = ""
        btnrem18.Visible = False
    End Sub

    Protected Sub btnadd20_Click(sender As Object, e As System.EventArgs) Handles btnadd20.Click
        Panel21.Visible = True
        btnadd20.Visible = False
        ddlgl21.DataBind()
        txtprice21.Text = ""
        btnrem19.Visible = False
    End Sub

    Protected Sub btnadd21_Click(sender As Object, e As System.EventArgs) Handles btnadd21.Click
        Panel22.Visible = True
        btnadd21.Visible = False
        ddlgl22.DataBind()
        txtprice22.Text = ""
        btnrem20.Visible = False
    End Sub

    Protected Sub btnadd22_Click(sender As Object, e As System.EventArgs) Handles btnadd22.Click
        Panel23.Visible = True
        btnadd22.Visible = False
        ddlgl23.DataBind()
        txtprice23.Text = ""
        btnrem21.Visible = False
    End Sub

    Protected Sub btnadd23_Click(sender As Object, e As System.EventArgs) Handles btnadd23.Click
        Panel24.Visible = True
        btnadd23.Visible = False
        ddlgl24.DataBind()
        txtprice24.Text = ""
        btnrem22.Visible = False
    End Sub

    Protected Sub btnadd24_Click(sender As Object, e As System.EventArgs) Handles btnadd24.Click
        Panel25.Visible = True
        btnadd24.Visible = False
        ddlgl25.DataBind()
        txtprice25.Text = ""
        btnrem23.Visible = False
    End Sub

    Protected Sub btnadd25_Click(sender As Object, e As System.EventArgs) Handles btnadd25.Click
        Panel26.Visible = True
        btnadd25.Visible = False
        ddlgl26.DataBind()
        txtprice26.Text = ""
        btnrem24.Visible = False
    End Sub

    Protected Sub btnadd26_Click(sender As Object, e As System.EventArgs) Handles btnadd26.Click
        Panel27.Visible = True
        btnadd26.Visible = False
        ddlgl27.DataBind()
        txtprice27.Text = ""
        btnrem25.Visible = False
    End Sub

    Protected Sub btnadd27_Click(sender As Object, e As System.EventArgs) Handles btnadd27.Click
        Panel28.Visible = True
        btnadd27.Visible = False
        ddlgl28.DataBind()
        txtprice28.Text = ""
        btnrem26.Visible = False
    End Sub

    Protected Sub btnadd28_Click(sender As Object, e As System.EventArgs) Handles btnadd28.Click
        Panel29.Visible = True
        btnadd28.Visible = False
        ddlgl29.DataBind()
        txtprice29.Text = ""
        btnrem27.Visible = False
    End Sub

    Protected Sub btnadd29_Click(sender As Object, e As System.EventArgs) Handles btnadd29.Click
        Panel30.Visible = True
        btnadd29.Visible = False
        ddlgl30.DataBind()
        txtprice30.Text = ""
        btnrem28.Visible = False
    End Sub

    Protected Sub btnrem1_Click(sender As Object, e As System.EventArgs) Handles btnrem1.Click
        Panel2.Visible = False
        btnadd1.Visible = True
        ddlgl2.Items.Remove("---Select Account---")
        txtprice2.Text = "0"
    End Sub

    Protected Sub btnrem2_Click(sender As Object, e As System.EventArgs) Handles btnrem2.Click
        Panel3.Visible = False
        btnadd2.Visible = True
        btnrem1.Visible = True
        ddlgl3.Items.Remove("---Select Account---")
        txtprice3.Text = "0"
    End Sub

    Protected Sub btnrem3_Click(sender As Object, e As System.EventArgs) Handles btnrem3.Click
        Panel4.Visible = False
        btnadd3.Visible = True
        btnrem2.Visible = True
        ddlgl4.Items.Remove("---Select Account---")
        txtprice4.Text = "0"
    End Sub

    Protected Sub btnrem4_Click(sender As Object, e As System.EventArgs) Handles btnrem4.Click
        Panel5.Visible = False
        btnadd4.Visible = True
        btnrem3.Visible = True
        ddlgl5.Items.Remove("---Select Account---")
        txtprice5.Text = "0"
    End Sub

    Protected Sub btnrem5_Click(sender As Object, e As System.EventArgs) Handles btnrem5.Click
        Panel6.Visible = False
        btnadd5.Visible = True
        btnrem4.Visible = True
        ddlgl6.Items.Remove("---Select Account---")
        txtprice6.Text = "0"
    End Sub

    Protected Sub btnrem6_Click(sender As Object, e As System.EventArgs) Handles btnrem6.Click
        Panel7.Visible = False
        btnadd6.Visible = True
        btnrem5.Visible = True
        ddlgl7.Items.Remove("---Select Account---")
        txtprice7.Text = "0"
    End Sub

    Protected Sub btnrem7_Click(sender As Object, e As System.EventArgs) Handles btnrem7.Click
        Panel8.Visible = False
        btnadd7.Visible = True
        btnrem6.Visible = True
        ddlgl8.Items.Remove("---Select Account---")
        txtprice8.Text = "0"
    End Sub

    Protected Sub btnrem8_Click(sender As Object, e As System.EventArgs) Handles btnrem8.Click
        Panel9.Visible = False
        btnadd8.Visible = True
        btnrem7.Visible = True
        ddlgl9.Items.Remove("---Select Account---")
        txtprice9.Text = "0"
    End Sub

    Protected Sub btnrem9_Click(sender As Object, e As System.EventArgs) Handles btnrem9.Click
        Panel10.Visible = False
        btnadd9.Visible = True
        btnrem8.Visible = True
        ddlgl10.Items.Remove("---Select Account---")
        txtprice10.Text = "0"
    End Sub

    Protected Sub btnrem10_Click(sender As Object, e As System.EventArgs) Handles btnrem10.Click
        Panel11.Visible = False
        btnadd10.Visible = True
        btnrem9.Visible = True
        ddlgl11.Items.Remove("---Select Account---")
        txtprice11.Text = "0"
    End Sub

    Protected Sub btnrem11_Click(sender As Object, e As System.EventArgs) Handles btnrem11.Click
        Panel12.Visible = False
        btnadd11.Visible = True
        btnrem10.Visible = True
        ddlgl12.Items.Remove("---Select Account---")
        txtprice12.Text = "0"
    End Sub

    Protected Sub btnrem12_Click(sender As Object, e As System.EventArgs) Handles btnrem12.Click
        Panel13.Visible = False
        btnadd12.Visible = True
        btnrem11.Visible = True
        ddlgl13.Items.Remove("---Select Account---")
        txtprice13.Text = "0"
    End Sub

    Protected Sub btnrem13_Click(sender As Object, e As System.EventArgs) Handles btnrem13.Click
        Panel14.Visible = False
        btnadd13.Visible = True
        btnrem12.Visible = True
        ddlgl14.Items.Remove("---Select Account---")
        txtprice14.Text = "0"
    End Sub

    Protected Sub btnrem14_Click(sender As Object, e As System.EventArgs) Handles btnrem14.Click
        Panel15.Visible = False
        btnadd14.Visible = True
        btnrem13.Visible = True
        ddlgl12.Items.Remove("---Select Account---")
        txtprice15.Text = "0"
    End Sub

    Protected Sub btnrem15_Click(sender As Object, e As System.EventArgs) Handles btnrem15.Click
        Panel16.Visible = False
        btnadd15.Visible = True
        btnrem14.Visible = True
        ddlgl16.Items.Remove("---Select Account---")
        txtprice16.Text = "0"
    End Sub

    Protected Sub btnrem16_Click(sender As Object, e As System.EventArgs) Handles btnrem16.Click
        Panel17.Visible = False
        btnadd16.Visible = True
        btnrem15.Visible = True
        ddlgl17.Items.Remove("---Select Account---")
        txtprice17.Text = "0"
    End Sub

    Protected Sub btnrem17_Click(sender As Object, e As System.EventArgs) Handles btnrem17.Click
        Panel18.Visible = False
        btnadd17.Visible = True
        btnrem16.Visible = True
        ddlgl18.Items.Remove("---Select Account---")
        txtprice18.Text = "0"
    End Sub

    Protected Sub btnrem18_Click(sender As Object, e As System.EventArgs) Handles btnrem18.Click
        Panel19.Visible = False
        btnadd18.Visible = True
        btnrem17.Visible = True
        ddlgl19.Items.Remove("---Select Account---")
        txtprice19.Text = "0"
    End Sub

    Protected Sub btnrem19_Click(sender As Object, e As System.EventArgs) Handles btnrem19.Click
        Panel20.Visible = False
        btnadd19.Visible = True
        btnrem18.Visible = True
        ddlgl20.Items.Remove("---Select Account---")
        txtprice20.Text = "0"
    End Sub

    Protected Sub btnrem20_Click(sender As Object, e As System.EventArgs) Handles btnrem20.Click
        Panel21.Visible = False
        btnadd20.Visible = True
        btnrem19.Visible = True
        ddlgl21.Items.Remove("---Select Account---")
        txtprice21.Text = "0"
    End Sub

    Protected Sub btnrem21_Click(sender As Object, e As System.EventArgs) Handles btnrem21.Click
        Panel22.Visible = False
        btnadd21.Visible = True
        btnrem20.Visible = True
        ddlgl22.Items.Remove("---Select Account---")
        txtprice22.Text = "0"
    End Sub

    Protected Sub btnrem22_Click(sender As Object, e As System.EventArgs) Handles btnrem22.Click
        Panel23.Visible = False
        btnadd22.Visible = True
        btnrem21.Visible = True
        ddlgl23.Items.Remove("---Select Account---")
        txtprice23.Text = "0"
    End Sub

    Protected Sub btnrem23_Click(sender As Object, e As System.EventArgs) Handles btnrem23.Click
        Panel24.Visible = False
        btnadd23.Visible = True
        btnrem22.Visible = True
        ddlgl24.Items.Remove("---Select Account---")
        txtprice24.Text = "0"
    End Sub

    Protected Sub btnrem24_Click(sender As Object, e As System.EventArgs) Handles btnrem24.Click
        Panel25.Visible = False
        btnadd24.Visible = True
        btnrem23.Visible = True
        ddlgl25.Items.Remove("---Select Account---")
        txtprice25.Text = "0"
    End Sub

    Protected Sub btnrem25_Click(sender As Object, e As System.EventArgs) Handles btnrem25.Click
        Panel26.Visible = False
        btnadd25.Visible = True
        btnrem24.Visible = True
        ddlgl26.Items.Remove("---Select Account---")
        txtprice26.Text = "0"
    End Sub

    Protected Sub btnrem26_Click(sender As Object, e As System.EventArgs) Handles btnrem26.Click
        Panel27.Visible = False
        btnadd26.Visible = True
        btnrem25.Visible = True
        ddlgl27.Items.Remove("---Select Account---")
        txtprice27.Text = "0"
    End Sub

    Protected Sub btnrem27_Click(sender As Object, e As System.EventArgs) Handles btnrem27.Click
        Panel28.Visible = False
        btnadd27.Visible = True
        btnrem26.Visible = True
        ddlgl28.Items.Remove("---Select Account---")
        txtprice28.Text = "0"
    End Sub

    Protected Sub btnrem28_Click(sender As Object, e As System.EventArgs) Handles btnrem28.Click
        Panel29.Visible = False
        btnadd28.Visible = True
        btnrem27.Visible = True
        ddlgl29.Items.Remove("---Select Account---")
        txtprice29.Text = "0"
    End Sub

    Protected Sub btnrem29_Click(sender As Object, e As System.EventArgs) Handles btnrem29.Click
        Panel30.Visible = False
        btnadd29.Visible = True
        btnrem28.Visible = True
        ddlgl30.Items.Remove("---Select Account---")
        txtprice30.Text = "0"
    End Sub



    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Button1.Enabled = False
        If Page.IsValid Then

            Try


                Dim con As New SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
                Dim cmd As New SqlCommand
                Dim FQDN As String = User.Identity.Name
                Dim usrnm As String = FQDN.Remove(0, 8)
                Dim email As String = usrnm + "@ymmc.yamaha-motor.com"
                Dim dlvdate1 As DateTime = txtdate1.Text
                Dim s1 As String
                Dim dlvdate2 As DateTime = txtdate2.Text
                Dim s2 As String
                Dim dlvdate3 As DateTime = txtdate2.Text
                Dim s3 As String
                Dim dlvdate4 As DateTime = txtdate2.Text
                Dim s4 As String
                Dim dlvdate5 As DateTime = txtdate2.Text
                Dim s5 As String
                Dim dlvdate6 As DateTime = txtdate2.Text
                Dim s6 As String
                Dim dlvdate7 As DateTime = txtdate2.Text
                Dim s7 As String
                Dim dlvdate8 As DateTime = txtdate2.Text
                Dim s8 As String
                Dim dlvdate9 As DateTime = txtdate2.Text
                Dim s9 As String
                Dim dlvdate10 As DateTime = txtdate2.Text
                Dim s10 As String
                Dim dlvdate11 As DateTime = txtdate1.Text
                Dim s11 As String
                Dim dlvdate12 As DateTime = txtdate2.Text
                Dim s12 As String
                Dim dlvdate13 As DateTime = txtdate2.Text
                Dim s13 As String
                Dim dlvdate14 As DateTime = txtdate2.Text
                Dim s14 As String
                Dim dlvdate15 As DateTime = txtdate2.Text
                Dim s15 As String
                Dim dlvdate16 As DateTime = txtdate2.Text
                Dim s16 As String
                Dim dlvdate17 As DateTime = txtdate2.Text
                Dim s17 As String
                Dim dlvdate18 As DateTime = txtdate2.Text
                Dim s18 As String
                Dim dlvdate19 As DateTime = txtdate2.Text
                Dim s19 As String
                Dim dlvdate20 As DateTime = txtdate2.Text
                Dim s20 As String
                Dim dlvdate21 As DateTime = txtdate1.Text
                Dim s21 As String
                Dim dlvdate22 As DateTime = txtdate2.Text
                Dim s22 As String
                Dim dlvdate23 As DateTime = txtdate2.Text
                Dim s23 As String
                Dim dlvdate24 As DateTime = txtdate2.Text
                Dim s24 As String
                Dim dlvdate25 As DateTime = txtdate2.Text
                Dim s25 As String
                Dim dlvdate26 As DateTime = txtdate2.Text
                Dim s26 As String
                Dim dlvdate27 As DateTime = txtdate2.Text
                Dim s27 As String
                Dim dlvdate28 As DateTime = txtdate2.Text
                Dim s28 As String
                Dim dlvdate29 As DateTime = txtdate2.Text
                Dim s29 As String
                Dim dlvdate30 As DateTime = txtdate2.Text
                Dim s30 As String

                s1 = dlvdate1.ToString("yyyyMMdd")
                s2 = dlvdate2.ToString("yyyyMMdd")
                s3 = dlvdate1.ToString("yyyyMMdd")
                s4 = dlvdate2.ToString("yyyyMMdd")
                s5 = dlvdate2.ToString("yyyyMMdd")
                s6 = dlvdate1.ToString("yyyyMMdd")
                s7 = dlvdate2.ToString("yyyyMMdd")
                s8 = dlvdate1.ToString("yyyyMMdd")
                s9 = dlvdate2.ToString("yyyyMMdd")
                s10 = dlvdate2.ToString("yyyyMMdd")
                s11 = dlvdate1.ToString("yyyyMMdd")
                s12 = dlvdate2.ToString("yyyyMMdd")
                s13 = dlvdate1.ToString("yyyyMMdd")
                s14 = dlvdate2.ToString("yyyyMMdd")
                s15 = dlvdate2.ToString("yyyyMMdd")
                s16 = dlvdate1.ToString("yyyyMMdd")
                s17 = dlvdate2.ToString("yyyyMMdd")
                s18 = dlvdate1.ToString("yyyyMMdd")
                s19 = dlvdate2.ToString("yyyyMMdd")
                s20 = dlvdate2.ToString("yyyyMMdd")
                s21 = dlvdate1.ToString("yyyyMMdd")
                s22 = dlvdate2.ToString("yyyyMMdd")
                s23 = dlvdate1.ToString("yyyyMMdd")
                s24 = dlvdate2.ToString("yyyyMMdd")
                s25 = dlvdate2.ToString("yyyyMMdd")
                s26 = dlvdate1.ToString("yyyyMMdd")
                s27 = dlvdate2.ToString("yyyyMMdd")
                s28 = dlvdate1.ToString("yyyyMMdd")
                s29 = dlvdate2.ToString("yyyyMMdd")
                s30 = dlvdate2.ToString("yyyyMMdd")

                Dim prc1string As String = txtprice1.Text
                Dim prc1 As Decimal = Convert.ToDecimal(prc1string)
                Dim prcdec1 As String = prc1.ToString("0.00")
                Dim prc2string As String = txtprice2.Text
                Dim prc2 As Decimal = Convert.ToDecimal(prc2string)
                Dim prcdec2 As String = prc2.ToString("0.00")
                Dim prc3string As String = txtprice3.Text
                Dim prc3 As Decimal = Convert.ToDecimal(prc3string)
                Dim prcdec3 As String = prc3.ToString("0.00")
                Dim prc4string As String = txtprice4.Text
                Dim prc4 As Decimal = Convert.ToDecimal(prc4string)
                Dim prcdec4 As String = prc4.ToString("0.00")
                Dim prc5string As String = txtprice5.Text
                Dim prc5 As Decimal = Convert.ToDecimal(prc5string)
                Dim prcdec5 As String = prc5.ToString("0.00")
                Dim prc6string As String = txtprice6.Text
                Dim prc6 As Decimal = Convert.ToDecimal(prc6string)
                Dim prcdec6 As String = prc6.ToString("0.00")
                Dim prc7string As String = txtprice7.Text
                Dim prc7 As Decimal = Convert.ToDecimal(prc7string)
                Dim prcdec7 As String = prc7.ToString("0.00")
                Dim prc8string As String = txtprice8.Text
                Dim prc8 As Decimal = Convert.ToDecimal(prc8string)
                Dim prcdec8 As String = prc8.ToString("0.00")
                Dim prc9string As String = txtprice9.Text
                Dim prc9 As Decimal = Convert.ToDecimal(prc9string)
                Dim prcdec9 As String = prc9.ToString("0.00")
                Dim prc10string As String = txtprice10.Text
                Dim prc10 As Decimal = Convert.ToDecimal(prc10string)
                Dim prcdec10 As String = prc10.ToString("0.00")
                Dim prc11string As String = txtprice11.Text
                Dim prc11 As Decimal = Convert.ToDecimal(prc11string)
                Dim prcdec11 As String = prc11.ToString("0.00")
                Dim prc12string As String = txtprice12.Text
                Dim prc12 As Decimal = Convert.ToDecimal(prc12string)
                Dim prcdec12 As String = prc12.ToString("0.00")
                Dim prc13string As String = txtprice13.Text
                Dim prc13 As Decimal = Convert.ToDecimal(prc13string)
                Dim prcdec13 As String = prc13.ToString("0.00")
                Dim prc14string As String = txtprice14.Text
                Dim prc14 As Decimal = Convert.ToDecimal(prc14string)
                Dim prcdec14 As String = prc14.ToString("0.00")
                Dim prc15string As String = txtprice15.Text
                Dim prc15 As Decimal = Convert.ToDecimal(prc15string)
                Dim prcdec15 As String = prc15.ToString("0.00")
                Dim prc16string As String = txtprice16.Text
                Dim prc16 As Decimal = Convert.ToDecimal(prc16string)
                Dim prcdec16 As String = prc16.ToString("0.00")
                Dim prc17string As String = txtprice17.Text
                Dim prc17 As Decimal = Convert.ToDecimal(prc17string)
                Dim prcdec17 As String = prc17.ToString("0.00")
                Dim prc18string As String = txtprice18.Text
                Dim prc18 As Decimal = Convert.ToDecimal(prc18string)
                Dim prcdec18 As String = prc18.ToString("0.00")
                Dim prc19string As String = txtprice19.Text
                Dim prc19 As Decimal = Convert.ToDecimal(prc19string)
                Dim prcdec19 As String = prc19.ToString("0.00")
                Dim prc20string As String = txtprice20.Text
                Dim prc20 As Decimal = Convert.ToDecimal(prc20string)
                Dim prcdec20 As String = prc20.ToString("0.00")
                Dim prc21string As String = txtprice21.Text
                Dim prc21 As Decimal = Convert.ToDecimal(prc21string)
                Dim prcdec21 As String = prc21.ToString("0.00")
                Dim prc22string As String = txtprice22.Text
                Dim prc22 As Decimal = Convert.ToDecimal(prc22string)
                Dim prcdec22 As String = prc22.ToString("0.00")
                Dim prc23string As String = txtprice23.Text
                Dim prc23 As Decimal = Convert.ToDecimal(prc23string)
                Dim prcdec23 As String = prc23.ToString("0.00")
                Dim prc24string As String = txtprice24.Text
                Dim prc24 As Decimal = Convert.ToDecimal(prc24string)
                Dim prcdec24 As String = prc24.ToString("0.00")
                Dim prc25string As String = txtprice25.Text
                Dim prc25 As Decimal = Convert.ToDecimal(prc25string)
                Dim prcdec25 As String = prc25.ToString("0.00")
                Dim prc26string As String = txtprice26.Text
                Dim prc26 As Decimal = Convert.ToDecimal(prc26string)
                Dim prcdec26 As String = prc26.ToString("0.00")
                Dim prc27string As String = txtprice27.Text
                Dim prc27 As Decimal = Convert.ToDecimal(prc27string)
                Dim prcdec27 As String = prc27.ToString("0.00")
                Dim prc28string As String = txtprice28.Text
                Dim prc28 As Decimal = Convert.ToDecimal(prc28string)
                Dim prcdec28 As String = prc28.ToString("0.00")
                Dim prc29string As String = txtprice29.Text
                Dim prc29 As Decimal = Convert.ToDecimal(prc29string)
                Dim prcdec29 As String = prc29.ToString("0.00")
                Dim prc30string As String = txtprice30.Text
                Dim prc30 As Decimal = Convert.ToDecimal(prc30string)
                Dim prcdec30 As String = prc30.ToString("0.00")

                txthead.Text = txthead.Text.Replace("'", "''")

                txtlng1.Text = txtlng1.Text.Replace("'", "''")
                txtlng2.Text = txtlng2.Text.Replace("'", "''")
                txtlng3.Text = txtlng3.Text.Replace("'", "''")
                txtlng4.Text = txtlng4.Text.Replace("'", "''")
                txtlng5.Text = txtlng5.Text.Replace("'", "''")
                txtlng6.Text = txtlng6.Text.Replace("'", "''")
                txtlng7.Text = txtlng7.Text.Replace("'", "''")
                txtlng8.Text = txtlng8.Text.Replace("'", "''")
                txtlng9.Text = txtlng9.Text.Replace("'", "''")
                txtlng10.Text = txtlng10.Text.Replace("'", "''")
                txtlng11.Text = txtlng11.Text.Replace("'", "''")
                txtlng12.Text = txtlng12.Text.Replace("'", "''")
                txtlng13.Text = txtlng13.Text.Replace("'", "''")
                txtlng14.Text = txtlng14.Text.Replace("'", "''")
                txtlng15.Text = txtlng15.Text.Replace("'", "''")
                txtlng16.Text = txtlng16.Text.Replace("'", "''")
                txtlng17.Text = txtlng17.Text.Replace("'", "''")
                txtlng18.Text = txtlng18.Text.Replace("'", "''")
                txtlng19.Text = txtlng19.Text.Replace("'", "''")
                txtlng20.Text = txtlng20.Text.Replace("'", "''")
                txtlng21.Text = txtlng21.Text.Replace("'", "''")
                txtlng22.Text = txtlng22.Text.Replace("'", "''")
                txtlng23.Text = txtlng23.Text.Replace("'", "''")
                txtlng24.Text = txtlng24.Text.Replace("'", "''")
                txtlng25.Text = txtlng25.Text.Replace("'", "''")
                txtlng26.Text = txtlng26.Text.Replace("'", "''")
                txtlng27.Text = txtlng27.Text.Replace("'", "''")
                txtlng28.Text = txtlng28.Text.Replace("'", "''")
                txtlng29.Text = txtlng29.Text.Replace("'", "''")
                txtlng30.Text = txtlng30.Text.Replace("'", "''")

                Txtshrt1.Text = Txtshrt1.Text.Replace("'", "''")
                Txtshrt2.Text = Txtshrt2.Text.Replace("'", "''")
                Txtshrt3.Text = Txtshrt3.Text.Replace("'", "''")
                Txtshrt4.Text = Txtshrt4.Text.Replace("'", "''")
                Txtshrt5.Text = Txtshrt5.Text.Replace("'", "''")
                Txtshrt6.Text = Txtshrt6.Text.Replace("'", "''")
                Txtshrt7.Text = Txtshrt7.Text.Replace("'", "''")
                Txtshrt8.Text = Txtshrt8.Text.Replace("'", "''")
                Txtshrt9.Text = Txtshrt9.Text.Replace("'", "''")
                Txtshrt10.Text = Txtshrt10.Text.Replace("'", "''")
                Txtshrt11.Text = Txtshrt11.Text.Replace("'", "''")
                Txtshrt12.Text = Txtshrt12.Text.Replace("'", "''")
                Txtshrt13.Text = Txtshrt13.Text.Replace("'", "''")
                Txtshrt14.Text = Txtshrt14.Text.Replace("'", "''")
                Txtshrt15.Text = Txtshrt15.Text.Replace("'", "''")
                Txtshrt16.Text = Txtshrt16.Text.Replace("'", "''")
                Txtshrt17.Text = Txtshrt17.Text.Replace("'", "''")
                Txtshrt18.Text = Txtshrt18.Text.Replace("'", "''")
                Txtshrt19.Text = Txtshrt19.Text.Replace("'", "''")
                Txtshrt20.Text = Txtshrt20.Text.Replace("'", "''")
                Txtshrt21.Text = Txtshrt21.Text.Replace("'", "''")
                Txtshrt22.Text = Txtshrt22.Text.Replace("'", "''")
                Txtshrt23.Text = Txtshrt23.Text.Replace("'", "''")
                Txtshrt24.Text = Txtshrt24.Text.Replace("'", "''")
                Txtshrt25.Text = Txtshrt25.Text.Replace("'", "''")
                Txtshrt26.Text = Txtshrt26.Text.Replace("'", "''")
                Txtshrt27.Text = Txtshrt27.Text.Replace("'", "''")
                Txtshrt28.Text = Txtshrt28.Text.Replace("'", "''")
                Txtshrt29.Text = Txtshrt29.Text.Replace("'", "''")
                Txtshrt30.Text = Txtshrt30.Text.Replace("'", "''")

                txtvenmat1.Text = txtvenmat1.Text.Replace("'", "''")
                txtvenmat2.Text = txtvenmat2.Text.Replace("'", "''")
                txtvenmat3.Text = txtvenmat3.Text.Replace("'", "''")
                txtvenmat4.Text = txtvenmat4.Text.Replace("'", "''")
                txtvenmat5.Text = txtvenmat5.Text.Replace("'", "''")
                txtvenmat6.Text = txtvenmat6.Text.Replace("'", "''")
                txtvenmat7.Text = txtvenmat7.Text.Replace("'", "''")
                txtvenmat8.Text = txtvenmat8.Text.Replace("'", "''")
                txtvenmat9.Text = txtvenmat9.Text.Replace("'", "''")
                txtvenmat10.Text = txtvenmat10.Text.Replace("'", "''")
                txtvenmat11.Text = txtvenmat11.Text.Replace("'", "''")
                txtvenmat12.Text = txtvenmat12.Text.Replace("'", "''")
                txtvenmat13.Text = txtvenmat13.Text.Replace("'", "''")
                txtvenmat14.Text = txtvenmat14.Text.Replace("'", "''")
                txtvenmat15.Text = txtvenmat15.Text.Replace("'", "''")
                txtvenmat16.Text = txtvenmat16.Text.Replace("'", "''")
                txtvenmat17.Text = txtvenmat17.Text.Replace("'", "''")
                txtvenmat18.Text = txtvenmat18.Text.Replace("'", "''")
                txtvenmat19.Text = txtvenmat19.Text.Replace("'", "''")
                txtvenmat20.Text = txtvenmat20.Text.Replace("'", "''")
                txtvenmat21.Text = txtvenmat21.Text.Replace("'", "''")
                txtvenmat22.Text = txtvenmat22.Text.Replace("'", "''")
                txtvenmat23.Text = txtvenmat23.Text.Replace("'", "''")
                txtvenmat24.Text = txtvenmat24.Text.Replace("'", "''")
                txtvenmat25.Text = txtvenmat25.Text.Replace("'", "''")
                txtvenmat26.Text = txtvenmat26.Text.Replace("'", "''")
                txtvenmat27.Text = txtvenmat27.Text.Replace("'", "''")
                txtvenmat28.Text = txtvenmat28.Text.Replace("'", "''")
                txtvenmat29.Text = txtvenmat29.Text.Replace("'", "''")
                txtvenmat30.Text = txtvenmat30.Text.Replace("'", "''")

                txttrackno1.Text = txttrackno1.Text.Replace("'", "''")
                txttrackno2.Text = txttrackno2.Text.Replace("'", "''")
                txttrackno3.Text = txttrackno3.Text.Replace("'", "''")
                txttrackno4.Text = txttrackno4.Text.Replace("'", "''")
                txttrackno5.Text = txttrackno5.Text.Replace("'", "''")
                txttrackno6.Text = txttrackno6.Text.Replace("'", "''")
                txttrackno7.Text = txttrackno7.Text.Replace("'", "''")
                txttrackno8.Text = txttrackno8.Text.Replace("'", "''")
                txttrackno9.Text = txttrackno9.Text.Replace("'", "''")
                txttrackno10.Text = txttrackno10.Text.Replace("'", "''")
                txttrackno11.Text = txttrackno11.Text.Replace("'", "''")
                txttrackno12.Text = txttrackno12.Text.Replace("'", "''")
                txttrackno13.Text = txttrackno13.Text.Replace("'", "''")
                txttrackno14.Text = txttrackno14.Text.Replace("'", "''")
                txttrackno15.Text = txttrackno15.Text.Replace("'", "''")
                txttrackno16.Text = txttrackno16.Text.Replace("'", "''")
                txttrackno17.Text = txttrackno17.Text.Replace("'", "''")
                txttrackno18.Text = txttrackno18.Text.Replace("'", "''")
                txttrackno19.Text = txttrackno19.Text.Replace("'", "''")
                txttrackno20.Text = txttrackno20.Text.Replace("'", "''")
                txttrackno21.Text = txttrackno21.Text.Replace("'", "''")
                txttrackno22.Text = txttrackno22.Text.Replace("'", "''")
                txttrackno23.Text = txttrackno23.Text.Replace("'", "''")
                txttrackno24.Text = txttrackno24.Text.Replace("'", "''")
                txttrackno25.Text = txttrackno25.Text.Replace("'", "''")
                txttrackno26.Text = txttrackno26.Text.Replace("'", "''")
                txttrackno27.Text = txttrackno27.Text.Replace("'", "''")
                txttrackno28.Text = txttrackno28.Text.Replace("'", "''")
                txttrackno29.Text = txttrackno29.Text.Replace("'", "''")
                txttrackno30.Text = txttrackno30.Text.Replace("'", "''")

                'opens the connection and inserts the required data
                'con.ConnectionString = "Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Database.mdf;Integrated Security=True;User Instance=True"
                If Txtshrt30.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl240.Text & "', '" & Txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & txtvenmat24.Text & "', '" & txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl250.Text & "', '" & Txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & txtvenmat25.Text & "', '" & txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl260.Text & "', '" & Txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & txtvenmat26.Text & "', '" & txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl270.Text & "', '" & Txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & txtvenmat27.Text & "', '" & txttrackno27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl280.Text & "', '" & Txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.SelectedValue & "', '" & s28 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl28.SelectedValue & "', '" & txtvenmat28.Text & "', '" & txttrackno28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl290.Text & "', '" & Txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.SelectedValue & "', '" & s29 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl29.SelectedValue & "', '" & txtvenmat29.Text & "', '" & txttrackno29.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl300.Text & "', '" & Txtshrt30.Text & "', '" & txtlng30.Text & "', '" & txtqty30.Text & "', '" & prcdec30 & "', '" & ddluom30.Text & "', '" & ddltax30.SelectedValue & "', '" & s30 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl30.SelectedValue & "', '" & txtvenmat30.Text & "', '" & txttrackno30.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.Text & "', '" & txtdate28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl290.Text & "', '" & txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.Text & "', '" & txtdate29.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl300.Text & "', '" & txtshrt30.Text & "', '" & txtlng30.Text & "', '" & txtqty30.Text & "', '" & prcdec30 & "', '" & ddluom30.Text & "', '" & ddltax30.Text & "', '" & txtdate30.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt29.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl240.Text & "', '" & Txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & txtvenmat24.Text & "', '" & txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl250.Text & "', '" & Txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & txtvenmat25.Text & "', '" & txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl260.Text & "', '" & Txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & txtvenmat26.Text & "', '" & txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl270.Text & "', '" & Txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & txtvenmat27.Text & "', '" & txttrackno27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl280.Text & "', '" & Txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.SelectedValue & "', '" & s28 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl28.SelectedValue & "', '" & txtvenmat28.Text & "', '" & txttrackno28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl290.Text & "', '" & Txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.SelectedValue & "', '" & s29 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl29.SelectedValue & "', '" & txtvenmat29.Text & "', '" & txttrackno29.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.Text & "', '" & txtdate28.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl290.Text & "', '" & txtshrt29.Text & "', '" & txtlng29.Text & "', '" & txtqty29.Text & "', '" & prcdec29 & "', '" & ddluom29.Text & "', '" & ddltax29.Text & "', '" & txtdate29.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt28.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl240.Text & "', '" & Txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & txtvenmat24.Text & "', '" & txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl250.Text & "', '" & Txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & txtvenmat25.Text & "', '" & txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl260.Text & "', '" & Txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & txtvenmat26.Text & "', '" & txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl270.Text & "', '" & Txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & txtvenmat27.Text & "', '" & txttrackno27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl280.Text & "', '" & Txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.SelectedValue & "', '" & s28 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl28.SelectedValue & "', '" & txtvenmat28.Text & "', '" & txttrackno28.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl280.Text & "', '" & txtshrt28.Text & "', '" & txtlng28.Text & "', '" & txtqty28.Text & "', '" & prcdec28 & "', '" & ddluom28.Text & "', '" & ddltax28.Text & "', '" & txtdate28.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt27.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl240.Text & "', '" & Txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & txtvenmat24.Text & "', '" & txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl250.Text & "', '" & Txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & txtvenmat25.Text & "', '" & txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl260.Text & "', '" & Txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & txtvenmat26.Text & "', '" & txttrackno26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl270.Text & "', '" & Txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.SelectedValue & "', '" & s27 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl27.SelectedValue & "', '" & txtvenmat27.Text & "', '" & txttrackno27.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl270.Text & "', '" & txtshrt27.Text & "', '" & txtlng27.Text & "', '" & txtqty27.Text & "', '" & prcdec27 & "', '" & ddluom27.Text & "', '" & ddltax27.Text & "', '" & txtdate27.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt26.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl240.Text & "', '" & Txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & txtvenmat24.Text & "', '" & txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl250.Text & "', '" & Txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & txtvenmat25.Text & "', '" & txttrackno25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl260.Text & "', '" & Txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.SelectedValue & "', '" & s26 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl26.SelectedValue & "', '" & txtvenmat26.Text & "', '" & txttrackno26.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl260.Text & "', '" & txtshrt26.Text & "', '" & txtlng26.Text & "', '" & txtqty26.Text & "', '" & prcdec26 & "', '" & ddluom26.Text & "', '" & ddltax26.Text & "', '" & txtdate26.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt25.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl240.Text & "', '" & Txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & txtvenmat24.Text & "', '" & txttrackno24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl250.Text & "', '" & Txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.SelectedValue & "', '" & s25 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl25.SelectedValue & "', '" & txtvenmat25.Text & "', '" & txttrackno25.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl250.Text & "', '" & txtshrt25.Text & "', '" & txtlng25.Text & "', '" & txtqty25.Text & "', '" & prcdec25 & "', '" & ddluom25.Text & "', '" & ddltax25.Text & "', '" & txtdate25.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt24.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl240.Text & "', '" & Txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.SelectedValue & "', '" & s24 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl24.SelectedValue & "', '" & txtvenmat24.Text & "', '" & txttrackno24.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl240.Text & "', '" & txtshrt24.Text & "', '" & txtlng24.Text & "', '" & txtqty24.Text & "', '" & prcdec24 & "', '" & ddluom24.Text & "', '" & ddltax24.Text & "', '" & txtdate24.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt23.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl230.Text & "', '" & Txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.SelectedValue & "', '" & s23 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl23.SelectedValue & "', '" & txtvenmat23.Text & "', '" & txttrackno23.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl230.Text & "', '" & txtshrt23.Text & "', '" & txtlng23.Text & "', '" & txtqty23.Text & "', '" & prcdec23 & "', '" & ddluom23.Text & "', '" & ddltax23.Text & "', '" & txtdate23.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt22.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl220.Text & "', '" & Txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.SelectedValue & "', '" & s22 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl22.SelectedValue & "', '" & txtvenmat22.Text & "', '" & txttrackno22.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl220.Text & "', '" & txtshrt22.Text & "', '" & txtlng22.Text & "', '" & txtqty22.Text & "', '" & prcdec22 & "', '" & ddluom22.Text & "', '" & ddltax22.Text & "', '" & txtdate22.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt21.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl210.Text & "', '" & Txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.SelectedValue & "', '" & s21 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl21.SelectedValue & "', '" & txtvenmat21.Text & "', '" & txttrackno21.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl210.Text & "', '" & txtshrt21.Text & "', '" & txtlng21.Text & "', '" & txtqty21.Text & "', '" & prcdec21 & "', '" & ddluom21.Text & "', '" & ddltax21.Text & "', '" & txtdate21.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt20.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl200.Text & "', '" & Txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.SelectedValue & "', '" & s20 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl20.SelectedValue & "', '" & txtvenmat20.Text & "', '" & txttrackno20.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl200.Text & "', '" & txtshrt20.Text & "', '" & txtlng20.Text & "', '" & txtqty20.Text & "', '" & prcdec20 & "', '" & ddluom20.Text & "', '" & ddltax20.Text & "', '" & txtdate20.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt19.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl190.Text & "', '" & Txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.SelectedValue & "', '" & s19 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl19.SelectedValue & "', '" & txtvenmat19.Text & "', '" & txttrackno19.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl190.Text & "', '" & txtshrt19.Text & "', '" & txtlng19.Text & "', '" & txtqty19.Text & "', '" & prcdec19 & "', '" & ddluom19.Text & "', '" & ddltax19.Text & "', '" & txtdate19.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt18.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl180.Text & "', '" & Txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.SelectedValue & "', '" & s18 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl18.SelectedValue & "', '" & txtvenmat18.Text & "', '" & txttrackno18.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl180.Text & "', '" & txtshrt18.Text & "', '" & txtlng18.Text & "', '" & txtqty18.Text & "', '" & prcdec18 & "', '" & ddluom18.Text & "', '" & ddltax18.Text & "', '" & txtdate18.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt17.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl170.Text & "', '" & Txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.SelectedValue & "', '" & s17 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl17.SelectedValue & "', '" & txtvenmat17.Text & "', '" & txttrackno17.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl170.Text & "', '" & txtshrt17.Text & "', '" & txtlng17.Text & "', '" & txtqty17.Text & "', '" & prcdec17 & "', '" & ddluom17.Text & "', '" & ddltax17.Text & "', '" & txtdate17.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt16.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl160.Text & "', '" & Txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.SelectedValue & "', '" & s16 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl16.SelectedValue & "', '" & txtvenmat16.Text & "', '" & txttrackno16.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl160.Text & "', '" & txtshrt16.Text & "', '" & txtlng16.Text & "', '" & txtqty16.Text & "', '" & prcdec16 & "', '" & ddluom16.Text & "', '" & ddltax16.Text & "', '" & txtdate16.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt15.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl150.Text & "', '" & Txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.SelectedValue & "', '" & s15 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl15.SelectedValue & "', '" & txtvenmat15.Text & "', '" & txttrackno15.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl150.Text & "', '" & txtshrt15.Text & "', '" & txtlng15.Text & "', '" & txtqty15.Text & "', '" & prcdec15 & "', '" & ddluom15.Text & "', '" & ddltax15.Text & "', '" & txtdate15.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt14.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl140.Text & "', '" & Txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.SelectedValue & "', '" & s14 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl14.SelectedValue & "', '" & txtvenmat14.Text & "', '" & txttrackno14.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl140.Text & "', '" & txtshrt14.Text & "', '" & txtlng14.Text & "', '" & txtqty14.Text & "', '" & prcdec14 & "', '" & ddluom14.Text & "', '" & ddltax14.Text & "', '" & txtdate14.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt13.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl130.Text & "', '" & Txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.SelectedValue & "', '" & s13 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl13.SelectedValue & "', '" & txtvenmat13.Text & "', '" & txttrackno13.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl130.Text & "', '" & txtshrt13.Text & "', '" & txtlng13.Text & "', '" & txtqty13.Text & "', '" & prcdec13 & "', '" & ddluom13.Text & "', '" & ddltax13.Text & "', '" & txtdate13.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt12.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl120.Text & "', '" & Txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.SelectedValue & "', '" & s12 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl12.SelectedValue & "', '" & txtvenmat12.Text & "', '" & txttrackno12.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl120.Text & "', '" & txtshrt12.Text & "', '" & txtlng12.Text & "', '" & txtqty12.Text & "', '" & prcdec12 & "', '" & ddluom12.Text & "', '" & ddltax12.Text & "', '" & txtdate12.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt11.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl110.Text & "', '" & Txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.SelectedValue & "', '" & s11 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl11.SelectedValue & "', '" & txtvenmat11.Text & "', '" & txttrackno11.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl110.Text & "', '" & txtshrt11.Text & "', '" & txtlng11.Text & "', '" & txtqty11.Text & "', '" & prcdec11 & "', '" & ddluom11.Text & "', '" & ddltax11.Text & "', '" & txtdate11.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt10.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl100.Text & "', '" & Txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.SelectedValue & "', '" & s10 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl10.SelectedValue & "', '" & txtvenmat10.Text & "', '" & txttrackno10.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl100.Text & "', '" & txtshrt10.Text & "', '" & txtlng10.Text & "', '" & txtqty10.Text & "', '" & prcdec10 & "', '" & ddluom10.Text & "', '" & ddltax10.Text & "', '" & txtdate10.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt9.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl90.Text & "', '" & Txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.SelectedValue & "', '" & s9 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl9.SelectedValue & "', '" & txtvenmat9.Text & "', '" & txttrackno9.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl90.Text & "', '" & txtshrt9.Text & "', '" & txtlng9.Text & "', '" & txtqty9.Text & "', '" & prcdec9 & "', '" & ddluom9.Text & "', '" & ddltax9.Text & "', '" & txtdate9.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt8.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl80.Text & "', '" & Txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.SelectedValue & "', '" & s8 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl8.SelectedValue & "', '" & txtvenmat8.Text & "', '" & txttrackno8.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl80.Text & "', '" & txtshrt8.Text & "', '" & txtlng8.Text & "', '" & txtqty8.Text & "', '" & prcdec8 & "', '" & ddluom8.Text & "', '" & ddltax8.Text & "', '" & txtdate8.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt7.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl70.Text & "', '" & Txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.SelectedValue & "', '" & s7 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl7.SelectedValue & "', '" & txtvenmat7.Text & "', '" & txttrackno7.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl70.Text & "', '" & txtshrt7.Text & "', '" & txtlng7.Text & "', '" & txtqty7.Text & "', '" & prcdec7 & "', '" & ddluom7.Text & "', '" & ddltax7.Text & "', '" & txtdate7.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt6.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl60.Text & "', '" & Txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.SelectedValue & "', '" & s6 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl6.SelectedValue & "', '" & txtvenmat6.Text & "', '" & txttrackno6.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl60.Text & "', '" & txtshrt6.Text & "', '" & txtlng6.Text & "', '" & txtqty6.Text & "', '" & prcdec6 & "', '" & ddluom6.Text & "', '" & ddltax6.Text & "', '" & txtdate6.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt5.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl50.Text & "', '" & Txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.SelectedValue & "', '" & s5 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl5.SelectedValue & "', '" & txtvenmat5.Text & "', '" & txttrackno5.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl50.Text & "', '" & txtshrt5.Text & "', '" & txtlng5.Text & "', '" & txtqty5.Text & "', '" & prcdec5 & "', '" & ddluom5.Text & "', '" & ddltax5.Text & "', '" & txtdate5.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt4.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl40.Text & "', '" & Txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.SelectedValue & "', '" & s4 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl4.SelectedValue & "', '" & txtvenmat4.Text & "', '" & txttrackno4.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl40.Text & "', '" & txtshrt4.Text & "', '" & txtlng4.Text & "', '" & txtqty4.Text & "', '" & prcdec4 & "', '" & ddluom4.Text & "', '" & ddltax4.Text & "', '" & txtdate4.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt3.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl30.Text & "', '" & Txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.SelectedValue & "', '" & s3 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl3.SelectedValue & "', '" & txtvenmat3.Text & "', '" & txttrackno3.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl30.Text & "', '" & txtshrt3.Text & "', '" & txtlng3.Text & "', '" & txtqty3.Text & "', '" & prcdec3 & "', '" & ddluom3.Text & "', '" & ddltax3.Text & "', '" & txtdate3.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                ElseIf Txtshrt2.Visible = True Then
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl20.Text & "', '" & Txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.SelectedValue & "', '" & s2 & "', '" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl2.SelectedValue & "', '" & txtvenmat2.Text & "', '" & txttrackno2.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & prcdec2 & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                Else
                    con.Open()
                    cmd.Connection = con
                    cmd.CommandText = "select top 1 seqkey from sapporeq order by seqkey desc"
                    Dim result As Object = cmd.ExecuteScalar
                    Lblresult.Text = String.Format(result) + 1
                    Session("RNO") = String.Format(result) + 1
                    cmd.CommandText = "INSERT INTO sapporeq (seqkey, vendor, ccenter, cpfr, purgroup, seqline, shorttext, longtext, unitqty, unitprc, uom, taxflag, dlvdate, CRTDT, STATUS, ACCTCAT, HDRTEXT, REQUSER, REQEMAIL, GLACCT, VENITEM, REFPART) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.SelectedValue & "', '" & ddlccenter.SelectedValue & "', '" & ddcpfr.SelectedValue & "', '" & lblgroup.Text & "', '" & lbl10.Text & "', '" & Txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.SelectedValue & "', '" & s1 & "','" & DateTime.Now.ToString("yyyyMMdd") & "', '" & Label2.Text & "', '" & txtacctcat.Text & "', '" & txthead.Text & "', '" & usrnm & "', '" & email & "', '" & ddlgl1.SelectedValue & "', '" & txtvenmat1.Text & "', '" & txttrackno1.Text & "')"
                    'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate, subdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.selectedvalue & "', '" & ddcpfr.Text & "', '" & lblgroup.text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & prcdec1 & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "','" & DateTime.Now & "')"
                    cmd.ExecuteNonQuery()
                    con.Close()
                End If

                Dim RNO As String = CType(Session.Item("RNO"), String)
                Dim uppath As String
                Dim upname As String
                uppath = "C:\inetpub\www-YCentral\data\poreq\" & RNO

                upname = Dir(uppath, vbDirectory)
                MkDir("C:\inetpub\www-YCentral\data\poreq\" & RNO)

                Dim up1 As String
                Dim up2 As String
                Dim up3 As String
                Dim up4 As String
                Dim up5 As String
                up1 = FileUpload1.PostedFile.FileName
                up2 = FileUpload2.PostedFile.FileName
                up3 = FileUpload3.PostedFile.FileName
                up4 = FileUpload4.PostedFile.FileName
                up5 = FileUpload5.PostedFile.FileName
                Dim a As String = System.IO.Path.GetFileName(up1)
                Dim b As String = System.IO.Path.GetFileName(up2)
                Dim c As String = System.IO.Path.GetFileName(up3)
                Dim d As String = System.IO.Path.GetFileName(up4)
                Dim f As String = System.IO.Path.GetFileName(up5)

                Try
                    FileUpload1.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + a)
                    FileUpload2.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + b)
                    FileUpload3.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + c)
                    FileUpload4.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + d)
                    FileUpload5.PostedFile.SaveAs("C:\inetpub\www-YCentral\data\poreq\" & RNO & "\" + f)
                Catch ex As Exception

                End Try

                Response.Redirect("default.aspx")
                'con.Open()
                'cmd.Connection = con
                'cmd.CommandText = "select top 1 seqno from purchreq order by seqno desc"
                'Dim result As Object = cmd.ExecuteScalar
                'lblresult.Text = String.Format(result) + 1
                'cmd.CommandText = "INSERT INTO purchreq (seqno, venno, ccenter, cpfrproj, grp, seqline, shttxt, lngtxt, qty, unitprice, uom, taxable, dlvdate) VALUES ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddcpfr.Text & "', '" & ddlgrp.Text & "', '" & Lbl10.Text & "', '" & txtshrt1.Text & "', '" & txtlng1.Text & "', '" & txtqty1.Text & "', '" & txtprice1.Text & "', '" & ddluom1.Text & "', '" & ddltax1.Text & "', '" & txtdate1.Text & "'), ('" & String.Format(result) + 1 & "', '" & ddlvendor.Text & "', '" & ddlccenter.Text & "', '" & ddcpfr.Text & "', '" & ddlgrp.Text & "', '" & lbl20.Text & "', '" & txtshrt2.Text & "', '" & txtlng2.Text & "', '" & txtqty2.Text & "', '" & txtprice2.Text & "', '" & ddluom2.Text & "', '" & ddltax2.Text & "', '" & txtdate2.Text & "')"
                'cmd.ExecuteNonQuery()
                'con.Close()
            Catch ex As Exception
                Page.RegisterClientScriptBlock("OnLoad", "<script>alert('Unit Price is too long')</script>")
            End Try
        End If

    End Sub

    Protected Sub ddcpfr_DataBound(sender As Object, e As System.EventArgs) Handles ddcpfr.DataBound
        ddcpfr.Items.Insert(0, New ListItem("", ""))
    End Sub

    Protected Sub BtnVenSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVenSearch.Click
        Panel31.Visible = False
        Panel32.Visible = True
        'Response.Redirect("~/Vendor_Search.aspx")
    End Sub
    Protected Sub GridView2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView2.SelectedIndexChanged
        ddlvendor.SelectedValue = gridview2.selectedvalue
        Panel32.visible = False
        Panel31.Visible = True


    End Sub

    Protected Sub BtnVSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVSearch.Click
        GridView2.Visible = True
    End Sub
    Protected Sub BtnVenSearchCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVenSearchCancel.Click
        Panel32.Visible = False
        Panel31.Visible = True
    End Sub

End Class
