﻿
Partial Class Status
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Dim FQDN As String = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name 'User.Identity.Name
        Dim usrnm As String = FQDN.Remove(0, 8)
        txtdate.Attributes.Add("readonly", "True")
        txtdate0.Attributes.Add("readonly", "True")
        SqlDataSource1.SelectCommand = "SELECT * FROM [SAPPOREQH]" 'WHERE requser = '" & usrnm & "'"
        'SqlDataSource1.SelectCommand = "SELECT * FROM [SAPPOREQ] WHERE requser = 'tdemuynck'"
    End Sub

    Protected Sub Button1_Click(sender As Object, e As System.EventArgs) Handles Button1.Click
        Dim FQDN As String = System.Web.HttpContext.Current.Request.LogonUserIdentity.Name 'User.Identity.Name
        Dim usrnm As String = FQDN.Remove(0, 8)
        SqlDataSource1.SelectCommand = "SELECT * FROM [SAPPOREQH] WHERE requser = '" & usrnm & "' and vendor = '" & DropDownList1.SelectedValue & "'"
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles GridView1.SelectedIndexChanged
        Label1.Text = GridView1.SelectedValue
        Session("HIDno") = GridView1.SelectedValue
        Response.Redirect("~/Hdisplay.aspx")
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Panel1.Visible = False
        Panel2.Visible = True
        If txtdate.Text <> "" Then
            Dim dlvdate1 As DateTime = txtdate.Text
            Dim s1 As String
            s1 = dlvdate1.ToString("yyyyMMdd")
            lbldate.Text = s1
        End If
        If txtdate0.Text <> "" Then
            Dim dlvdate0 As DateTime = txtdate0.Text
            Dim s2 As String
            s2 = dlvdate0.ToString("yyyyMMdd")
            lbldate0.Text = s2
        End If
        If GridView1.Rows.Count = 0 Then
            Label10.Visible = True
        Else
            Label10.Visible = False
        End If
        If txtcc.Text <> "" And GridView1.Rows.Count <> 0 Or txtcpfr.Text <> "" And GridView1.Rows.Count <> 0 Or txtven.Text <> "" And GridView1.Rows.Count <> 0 Or txtreqisitioner.Text <> "" And GridView1.Rows.Count <> 0 Then
            Btnexport.Visible = True
        Else
            Btnexport.Visible = False
        End If

    End Sub

    Protected Sub Button4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button4.Click
        txtdate.Text = ""
    End Sub

    Protected Sub GridView2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView2.SelectedIndexChanged
        txtven.Text = GridView2.SelectedValue
        Panel3.Visible = False
        Panel1.Visible = True


    End Sub

    Protected Sub BtnVSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVSearch.Click
        GridView2.Visible = True
    End Sub

    Protected Sub BtnVenSearchCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnVenSearchCancel.Click
        Panel3.Visible = False
        Panel1.Visible = True
    End Sub

    Protected Sub Button3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click
        Panel3.Visible = True
        Panel1.Visible = False

    End Sub

    Protected Sub Button5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button5.Click
        Response.Redirect("~/hstatus.aspx")

    End Sub

    Private Sub ExportToExcel(ByVal strFileName As String, ByVal dg As GridView)


        Response.Clear()
        Response.ContentType = "application/vnd.ms-excel"
        Response.AddHeader("content-disposition", "attachment;filename=" & strFileName)
        Response.Charset = ""
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Buffer = True
        Me.EnableViewState = False
        Dim oStringWriter As New System.IO.StringWriter
        Dim oHtmlTextWriter As New System.Web.UI.HtmlTextWriter(oStringWriter)

        dg.RenderControl(oHtmlTextWriter)

        Response.Write(oStringWriter.ToString())
        Response.End()


    End Sub

    Protected Sub Btnexport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btnexport.Click
        If Not txtcc.Text = "" Or txtcpfr.Text = "" Or txtven.Text = "" Or txtreqisitioner.Text = "" Then

        End If
        ExportToExcel("POHistory.xls", Me.GridView1)

    End Sub
    Public Overloads Overrides Sub VerifyRenderingInServerForm(ByVal control As System.Web.UI.Control)
        ' Verifies that the control is rendered 
        ' No code required here. 
    End Sub

End Class
