﻿namespace PurchaseRequisition.Models
{
    public class AjaxResponse
    {
        public string status { get; set; }
        public string message { get; set; }
        public string redirecturl { get; set; }
    }
}
