﻿$(document).ready(function () {

    $("#CPFRNO_wrapper").hide();

    $("input[custAttr=numberonly]").keypress(function (e) {
        if (e.which != 13 && e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57))
            return false;
    });

    function buildGLAccountOptions(GLACCTCAT="k") {
        var options = `<option value="" required>Select Account</option>`
        $.each(GLAccount_OBJ, function (i) {
            if(GLAccount_OBJ[i].GLACCTCAT == GLACCTCAT)
                options += `<option value="`+ GLAccount_OBJ[i].GLACCT+`">`+GLAccount_OBJ[i].Concat+`</option>`
        });
        return options;
    }

    $("#AddItemBtn").click(function () {

        var noItemsAvailable = $("#LineItems").find(".noItemsAvailable");
        if (noItemsAvailable != null)
            noItemsAvailable.remove();
        var itemHTML = `<tr>
                                    <td><input name="LineItemText" value="" /></td>
                                    <td><input name="Description" value="" style="width:150px" /></td>
                                    <td>
                                        <select class="GLAccount">
                                            `+ buildGLAccountOptions() +`
                                        </select>
                                    </td>
                                    <td><input name="QTY" value="" style="width:50px" /></td>
                                    <td><input name="UnitPrice" value="" style="width:50px" /></td>
                                    <td>
                                        <select name="UOM">
                                            <option value="EA">EA</option>
                                        </select>
                                    </td>
                                    <td><input name="Total" value="" style="width:80px" /></td>
                                    <td>
                                        <select name="Taxable">
                                            <option value="YES">YES</option>
                                            <option value="NO">NO</option>
                                        </select>
                                    </td>
                                    <td><input name="DeliveryDate" value="" style="width:80px" /></td>
                                    <td><input name="VendorMaterial" value="" style="width:80px" /></td>
                                    <td><input name="TrackingNumber" value="" style="width:80px" /></td>
                                    <td>
                                     <!--   <i class="fa fa-edit itemEditBtn"></i> -->
                                        <i class="fa fa-trash itemDeleteBtn"></i>
                                    </td>
                                </tr>`;
        $(itemHTML).appendTo("#LineItems")

    });

    $(document).on("click", ".itemDeleteBtn", function () {
        $(this).closest("tr").remove();
        if ($("#LineItems").children().length == 0) {
            var itemHTML = `<tr class="noItemsAvailable"><td colspan="12">
                No line items available
            </td></tr>`;
            $(itemHTML).appendTo("#LineItems")
        }
    })

    function BuildCFRNumberDDList(PURGROUP = "") {
        var options = `<option value="" required>Select CPFRNO</option>`
        $.each(CPFRNO_OBJ, function (i) {
            if (CPFRNO_OBJ[i].PURGROUP == PURGROUP || PURGROUP == "")
                options += `<option value="` + CPFRNO_OBJ[i].CPFRNO + `">` + CPFRNO_OBJ[i].PURGROUP + `</option>`
        });
        $("#CPFRNODDlist").html(options)
    }

    $("#PurchaseGroupDDlist").change(function () {
        var PurchGRPMRO = $(this).val();
        var GLAccountOptions = "";
        if (PurchGRPMRO == "" || PurchGRPMRO == "MRO") {
            GLAccountOptions = buildGLAccountOptions('k');
            if (PurchGRPMRO == "MRO") {
                $("#CPFRNO_wrapper").hide();
                $("#CPFRNODDlist").val("")
                $("#CostCenter_wrapper").show();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("K")
            }

        }
        else
        if (PurchGRPMRO == "IO4") {
            GLAccountOptions = buildGLAccountOptions('h');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("H")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("IO4")
            $("#CPFRNODDlist").val("")
        }
        else
        if (PurchGRPMRO == "IO6") {
            GLAccountOptions = buildGLAccountOptions('j');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("J")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("IO6")
            $("#CPFRNODDlist").val("")
        }
        else
        if (PurchGRPMRO == "IO5") {
            GLAccountOptions = buildGLAccountOptions('i');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("I")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("IO5")
            $("#CPFRNODDlist").val("")
        }
        else
        if (PurchGRPMRO == "REW") {
            GLAccountOptions = buildGLAccountOptions('r');

            $("#CostCenter_wrapper").hide();
            $("#CostCenterDDlist").val("")
            $("#txtacctcat").val("R")
            $("#CPFRNO_wrapper").show();
            BuildCFRNumberDDList("REW")
            $("#CPFRNODDlist").val("")
        }
        else {
            GLAccountOptions = buildGLAccountOptions('f');

            if (PurchGRPMRO == "IO1") {
                $("#CostCenter_wrapper").hide();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("F")
                $("#CPFRNO_wrapper").show();
                BuildCFRNumberDDList("IO1")
                $("#CPFRNODDlist").val("")
            }
            else
            if (PurchGRPMRO == "IO2") {
                $("#CostCenter_wrapper").hide();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("F")
                $("#CPFRNO_wrapper").show();
                BuildCFRNumberDDList("IO2")
                $("#CPFRNODDlist").val("")
            }
            else
            if (PurchGRPMRO == "IO3") {
                $("#CostCenter_wrapper").hide();
                $("#CostCenterDDlist").val("")
                $("#txtacctcat").val("F")
                $("#CPFRNO_wrapper").show();
                BuildCFRNumberDDList("IO3")
                $("#CPFRNODDlist").val("")
            }

        }

        $(document).find(".GLAccount").html(GLAccountOptions)



    });


    $("#SubmitRequistionBtn").click(function (evt) {
        evt.preventDefault();
        var PurchaseRequistionLineItemList = [];
        $("#LineItems").children().each(function () {
            PurchaseRequistionLineItemList.push(JSON.stringify({
                "LineItem": $(this).find(':nth-child(1) > input').val(),
                "Description": $(this).find(':nth-child(2) > input').val(),
                "GLAccount": $(this).find(':nth-child(3) > select').val(),
                "Quantity": $(this).find(':nth-child(4) > input').val(),
                "UnitPrice": $(this).find(':nth-child(5) > input').val(),
                "UOM": $(this).find(':nth-child(6) > select').val(),
                "Total": $(this).find(':nth-child(7) > input').val(),
                "Taxable": $(this).find(':nth-child(8) > select').val(),
                "DeliveryDate": $(this).find(':nth-child(9) > input').val(),
                "VendorMaterial": $(this).find(':nth-child(10) > input').val(),
                "TrackingNumber": $(this).find(':nth-child(11) > input').val(),
            }));
        });

        var PurchaseRequistion = {
            "purchaseGroup": $("#PurchaseGroupDDlist").val(),
            "costCenter": $("#CostCenterDDlist").val(),
            "vendor": $("#VendorDDlist").val(),
            "cPFRNO": $("#CPFRNODDlist").val(),
            "headerText": $("#HeaderText").val(),
            "acctCat": $("#txtacctcat").val(),
            "purchaseRequistionLineItems": PurchaseRequistionLineItemList
        }

        console.log(PurchaseRequistion)

        return $.ajax({
            type: "POST",
            url: "/Requisition/SubmitPurchaseRequisition",
            contentType: "application/json; charset=utf-8",
            dataType: 'json',
            data: JSON.stringify(PurchaseRequistion),
            success: function (data) {
                return data;
            },
            error: function (data) {
                alert("Some error occoured. Please try later");
            }
        });

        console.log()

    });









    /*
    $('button').click(function () {
        var value = $(this).val();
        var EmpId = $("#EmpId").val();
        var EmpType = $("#EmpType").val();
        if (value != "") {
            if (value == "temp" || value == "full") {
                $("#EmpType").val(value);
                $(".empTypeBtn").removeClass("btn-selected");
                $("#" + value + "Btn").addClass("btn-selected");
            }
            else
                if (value == "clr") {
                    EmpId = "";
                }
                else
                    if (value == "del") {
                        EmpId = EmpId.slice(0, -1)
                    }
                    else
                        if (value == "enter") {
                            if (EmpType == "" && EmpId == "") {
                                alert("Please enter valid data")
                            }
                            else
                                if (EmpType == "") {
                                    alert("Please select employee type (FULL/TEMP)")
                                }
                                else
                                    if (EmpId == "") {
                                        alert("Please enter employee id")
                                    }
                                    else {
                                        if (validateEmpId()) {
                                            isEmployeeIdExists(EmpId, EmpType).always(function (resData) {
                                                if (resData != null && resData.status == "1" && resData.redirecturl != "") {
                                                    window.location = resData.redirecturl;
                                                }
                                                else {
                                                    alert("Invalid Data")
                                                }
                                            });
                                        }
                                        else {
                                            alert("Invalid employee id");
                                            EmpId = "";
                                        }
                                    }
                        }
                        else {
                            EmpId += value;
                        }
            $("#EmpId").val(EmpId);
        }

    });

    */


});


function validateEmpId() {


    return true;
}

function isEmployeeIdExists(EmpId, EmpType) {
    var urlEmployeeExists = $("#CheckEmployeeExists").val();
    if (EmpId != "" && EmpType != "") {
        var parseData = {
            "EmpId": EmpId,
            "EmpType": EmpType
        };

        return $.ajax({
            type: "POST",
            url: urlEmployeeExists,
            contentType: "application/json",
            data: JSON.stringify(parseData),
            success: function (data) {
                return data;
            },
            error: function (data) {
                alert("Some error occoured. Please try later");
            }
        });
    }
    else {
        alert("Insufficient Employee data. Kindly enter Employee Id & Type");
    }
    return null;
    
}

