﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PurchaseRequisition.ViewModel
{
    public class PurchaseRequistionViewModel
    {
        public int PurchaseRequistionId { get; set; }
        public string PurchaseGroup { get; set; }
        public string CostCenter { get; set; }
        public string Vendor { get; set; }
        public string CPFRNO { get; set; }
        public string HeaderText { get; set; }
        public string AcctCat { get; set; }
    //    public string purchaseRequistionLineItems { get; set; }
        public List<string> purchaseRequistionLineItems { get; set; }
    }

    //public class PurchaseRequistionLineItem
    //{
    //    public PurchaseRequistionLineItemDetails[] PurchaseRequistionLineItemDetails { get; set; }
    //}

    public class PurchaseRequistionLineItem
    {
        public int PurchaseRequistionLineItemId { get; set; }
        public string LineItem { get; set; }
        public string Description { get; set; }
        public string GLAccount { get; set; }
        public float Quantity { get; set; }
        public float UnitPrice { get; set; }
        public string UOM { get; set; }
        public string Total { get; set; }
        public string Taxable { get; set; }
        public string DeliveryDate { get; set; }
        public string VendorMaterial { get; set; }
        public string TrackingNumber { get; set; }
    }
}
