﻿using System.Collections.Generic;
using System.Linq;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;

namespace PurchReqV2.Controllers
{
    /// <summary>
    /// Controller for the UserAdmin page.
    /// </summary>
    /// <seealso cref="PurchReqV2.Controllers.BaseController" />
    public class UserAdminController : BaseController
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private EntitiesDataContext _context;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="UserAdminController"/> class.
        /// </summary>
        /// <param name="user">The user.</param>
        public UserAdminController(string user)
            : base(user)
        {
            _context = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Gets the users.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns></returns>
        public List<PurchReq_User> GetUsers(string user = null)
        {
            var results = new List<PurchReq_User>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange
                    (entities.spPurchReq_GetUsers()
                    .Where(x => (user == null || (x.UserName.ToLower().Contains(user.ToLower()) || user.ToLower().Contains(x.UserName.ToLower())))).Select(result => new PurchReq_User { UserName = result.UserName, UserID = result.UserID, IsAdmin = result.IsAdmin, Active = result.Active, CreatedBy = result.CreatedBy, CreatedOn = result.CreatedOn }));
            }

            return results;
        }

        /// <summary>
        /// Upserts the user.
        /// </summary>
        /// <param name="u">The u.</param>
        /// <param name="delete">The delete.</param>
        public void UpsertUser(object u, bool? delete = null)
        {
            var user = u as PurchReq_User;
            if (user == null) return;

            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertUser(user.UserID, user.UserName, user.IsAdmin, user.Active, UserName, delete);
            }
        }

        /// <summary>
        /// Gets the Groups.
        /// </summary>
        /// <param name="group">The Group.</param>
        /// <returns></returns>
        public List<PurchReq_Group> GetGroups(string group = null)
        {
            var results = new List<PurchReq_Group>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(entities.spPurchReq_GetGroups().Where(x => (group == null || (x.ADGroup.ToLower().Contains(group.ToLower()) || group.ToLower().Contains(x.ADGroup.ToLower())))).Select(result => new PurchReq_Group { ADGroup = result.ADGroup, GroupID = result.GroupID, IsAdmin = result.IsAdmin, Active = result.Active, CreatedBy = result.CreatedBy, CreatedOn = result.CreatedOn }));
            }

            return results;
        }

        /// <summary>
        /// Upserts the group.
        /// </summary>
        /// <param name="u">The u.</param>
        /// <param name="delete">The delete.</param>
        public void UpsertGroup(object u, bool? delete = null)
        {
            var group = u as PurchReq_Group;
            if (group == null) return;

            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertGroup(group.GroupID, group.ADGroup, group.IsAdmin, group.Active, UserName, delete);
            }
        }

        /// <summary>
        /// Gets the user menu items.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <returns>List of UserMenuItems</returns>
        public List<PurchReq_UserMenuItem> GetUserMenuItems(string userName = null)
        {
            var results = new List<PurchReq_UserMenuItem>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllUserMenuItemDetails(null)
                        .Where(
                            x =>
                                (userName == null ||
                                 (x.UserName.ToLower().Contains(userName.ToLower()) ||
                                  userName.ToLower().Contains(x.UserName.ToLower()))))
                        .Select(
                            result =>
                                new PurchReq_UserMenuItem
                                {
                                    PurchReq_User =
                                        new PurchReq_User
                                        {
                                            UserID = result.UserID,
                                            UserName = result.UserName,
                                            Active = result.User_Active,
                                            IsAdmin = result.IsAdmin,
                                            CreatedOn = result.User_CreatedOn,
                                            CreatedBy = result.User_CreatedBy
                                        },
                                    UserMenuItemsID = result.UserMenuItemsID,
                                    UserID = result.UserID,
                                    MenuItemID = result.MenuItemID,
                                    PurchReq_MenuItem = new PurchReq_MenuItem
                                    {
                                        MenuItemID = result.MenuItemID,
                                        MenuItemParentID = result.MenuItemParentID,
                                        Text = result.Text,
                                        Url = result.Url,
                                        Description = result.Description,
                                        IsHeader = result.IsHeader,
                                        Active = result.MenuItem_Active,
                                        CreatedOn = result.MenuItem_CreatedOn,
                                        CreatedBy = result.MenuItem_CreatedBy
                                    },
                                    Active = result.UserMenuItem_Active,
                                    CreatedBy = result.UserMenuItem_CreatedBy,
                                    CreatedOn = result.UserMenuItem_CreatedOn
                                            
                                }));
            }

            return results;
        }

        /// <summary>
        /// Upserts the UserMenuItem.
        /// </summary>
        /// <param name="u">The u.</param>
        /// <param name="delete">The delete.</param>
        public void UpsertUserMenuItem(object u, bool? delete = null)
        {
            var userMenuItem = u as PurchReq_UserMenuItem;
            if (userMenuItem == null) return;

            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertUserMenuItem(userMenuItem.UserMenuItemsID, userMenuItem.MenuItemID, userMenuItem.UserID, userMenuItem.Active, UserName, delete);
            }
        }

        /// <summary>
        /// Gets the Group menu items.
        /// </summary>
        /// <param name="adGroup">Name of the Group.</param>
        /// <returns>List of GroupMenuItems</returns>
        public List<PurchReq_GroupMenuItem> GetGroupMenuItems(string adGroup = null)
        {
            var results = new List<PurchReq_GroupMenuItem>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllGroupMenuItemDetails(null)
                        .Where(
                            x =>
                                (adGroup == null ||
                                 (x.ADGroup.ToLower().Contains(adGroup.ToLower()) ||
                                  adGroup.ToLower().Contains(x.ADGroup.ToLower()))))
                        .Select(
                            result =>
                                new PurchReq_GroupMenuItem
                                {
                                    PurchReq_Group =
                                        new PurchReq_Group
                                        {
                                            GroupID = result.GroupID,
                                            ADGroup = result.ADGroup,
                                            Active = result.Group_Active,
                                            IsAdmin = result.IsAdmin,
                                            CreatedOn = result.Group_CreatedOn,
                                            CreatedBy = result.Group_CreatedBy
                                        },
                                    GroupMenuItemsID = result.GroupMenuItemsID,
                                    GroupID = result.GroupID,
                                    MenuItemID = result.MenuItemID,
                                    PurchReq_MenuItem = new PurchReq_MenuItem
                                    {
                                        MenuItemID = result.MenuItemID,
                                        MenuItemParentID = result.MenuItemParentID,
                                        Text = result.Text,
                                        Url = result.Url,
                                        Description = result.Description,
                                        IsHeader = result.IsHeader,
                                        Active = result.MenuItem_Active,
                                        CreatedOn = result.MenuItem_CreatedOn,
                                        CreatedBy = result.MenuItem_CreatedBy
                                    },
                                    Active = result.GroupMenuItem_Active,
                                    CreatedBy = result.GroupMenuItem_CreatedBy,
                                    CreatedOn =
                                        result.GroupMenuItem_CreatedOn
                                }));
            }

            return results;
        }

        /// <summary>
        /// Upserts the GroupMenuItem.
        /// </summary>
        /// <param name="u">The u.</param>
        /// <param name="delete">The delete.</param>
        public void UpsertGroupMenuItem(object u, bool? delete = null)
        {
            var groupMenuItem = u as PurchReq_GroupMenuItem;
            if (groupMenuItem == null) return;

            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertGroupMenuItem(groupMenuItem.GroupMenuItemsID, groupMenuItem.MenuItemID, groupMenuItem.GroupID, groupMenuItem.Active, UserName, delete);
            }
        }

        #endregion

        #region Private Methods

        #endregion

        #endregion
    }
}