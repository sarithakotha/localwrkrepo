﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web.UI.WebControls;
using PurchReqV2.Models;
using PurchReqV2.Utilities;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.IO;
using Group = PurchReqV2.Models.Group;
using MenuItem = PurchReqV2.Models.MenuItem;
using User = PurchReqV2.Models.User;

namespace PurchReqV2.Controllers
{
    /// <summary>
    /// Controller class
    /// </summary>
    public class BaseController
    {
        #region Variables

        #region Public Variables

        public LdapUser UserInfo
        {
            get
            {
                if (_user != null) return _user;
                _user = Ldap.GetUserInfo(_userName);

                return _user;
            }
            private set { _user = value; }
        }

        public string UserName
        {
            get
            {
                return _userName;
            }
            private set
            {
                _userName = value;
            }
        }

        #endregion

        #region Private Variables

        private LdapUser _user;
        private string _userName;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseController"/> class.
        /// </summary>
        /// <param name="user">The user.</param>
        public BaseController(string user)
        {
            _userName = user;
            _user = Ldap.GetUserInfo(_userName);
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Determines whether [is site under maintenance].
        /// </summary>
        /// <returns>Bool value indicating site maintenance status</returns>
        public bool IsSiteUnderMaintenance()
        {
            var sm = GetIsSiteUnderMaintenance();
            return sm.Active;
        }

        /// <summary>
        /// Gets the site maintenance information.
        /// </summary>
        /// <returns>Site Information details</returns>
        public SiteMaintenance GetSiteMaintenanceInfo()
        {
            return GetIsSiteUnderMaintenance();
        }

        /// <summary>
        /// Determines whether [is user admin].
        /// </summary>
        /// <returns>Bool Is Admin</returns>
        public bool IsUserAdmin()
        {
            if (_user == null)
                return false;

            var users = GetUsers();
            var groups = GetGroups();

            return _user.Groups.Any(@group => groups.Any(x => x.IsAdmin && String.Equals(x.AdGroup, @group, StringComparison.CurrentCultureIgnoreCase))) || users.Any(x => x.IsAdmin && String.Equals(x.UserName, _userName, StringComparison.CurrentCultureIgnoreCase));
        }

        /// <summary>
        /// Determines whether [is user authorized for site].
        /// </summary>
        /// <returns>Bool indicating access</returns>
        public bool IsUserAuthorizedToViewSite()
        {
            if (IsUserAdmin()) { return true; }

            var users = GetUsers();
            var groups = GetGroups();
            var ret = false;
            if (_user.Groups != null)
            {
                ret =
                    _user.Groups.Any(
                        @group =>
                            groups.Any(x => String.Equals(x.AdGroup, @group, StringComparison.CurrentCultureIgnoreCase))) ||
                    users.Any(x => String.Equals(x.UserName, _userName, StringComparison.CurrentCultureIgnoreCase));
            }
            return ret;
        }

        /// <summary>
        /// Determines whether [is user authorized for page] [the specified page identifier].
        /// </summary>
        /// <param name="pageId">The page identifier.</param>
        /// <returns>Bool indicating access</returns>
        public bool IsUserAuthorizedForPage(long pageId)
        {
            if (IsUserAdmin()) { return true; }

            var menuItems = GetUserParentMenuItems(_userName);
            menuItems.AddRange(GetUserChildrenMenuItems(_userName));

            if (_user.Groups != null)
            {
                if (_user.Groups.Any(@group => IsGroupAuthorizedForPage(@group, pageId)))
                {
                    return true;
                }
            }

            return menuItems.Any(x => x.MenuItemId == pageId) || menuItems.Any(x => x.MenuItemParentId == pageId);
        }

        /// <summary>
        /// Gets the menu items.
        /// </summary>
        /// <returns>All menu items</returns>
        public List<MenuItem> GetMenuItems()
        {
            var items = GetParentMenuItems();
            items.AddRange(GetChildrenMenuItems());

            return items;
        }

        /// <summary>
        /// Gets the menu items for the given user.
        /// </summary>
        /// <returns>All menu items</returns>
        public List<MenuItem> GetMenuItemsForUser()
        {
            var items = GetParentMenuItemsForUser();
            items.AddRange(GetChildrenMenuItemsForUser());

            return items;
        } 

        /// <summary>
        /// Determines whether [is group authorized for page] [the specified group].
        /// </summary>
        /// <param name="group">The group.</param>
        /// <param name="pageId">The page identifier.</param>
        /// <returns>Bool indicating access</returns>
        public bool IsGroupAuthorizedForPage(string group, long pageId)
        {
            var menuItems = GetParentMenuItemsForGroup(group);
            menuItems.AddRange(GetChildrenMenuItemsForGroup(group));
            return menuItems.Any(x => x.MenuItemId == pageId) || menuItems.Any(x => x.MenuItemParentId == pageId);
        }

        /// <summary>
        /// Gets the parent menu items for user.
        /// </summary>
        /// <returns>Parent menu items for user</returns>
        public List<MenuItem> GetParentMenuItemsForUser()
        {
            var menuItems = GetUserParentMenuItems(_userName);

            if (_user.Groups != null)
            {
                foreach (
                    var item in
                        _user.Groups.Select(GetParentMenuItemsForGroup)
                            .SelectMany(
                                items => items.Where(item => menuItems.All(x => x.MenuItemId != item.MenuItemId))))
                {
                    menuItems.Add(item);
                }
            }

            var returnable = menuItems.Distinct().ToList();
            return returnable.OrderBy(x => x.MenuItemParentId).ToList();
        }

        /// <summary>
        /// Gets the children menu items for user.
        /// </summary>
        /// <returns>Child menu items for user</returns>
        public List<MenuItem> GetChildrenMenuItemsForUser()
        {
            var menuItems = GetUserChildrenMenuItems(_userName);

            if (_user.Groups != null)
            {
                foreach (
                    var item in
                        _user.Groups.Select(GetChildrenMenuItemsForGroup)
                            .SelectMany(
                                items => items.Where(item => menuItems.All(x => x.MenuItemId != item.MenuItemId))))
                {
                    menuItems.Add(item);
                }
            }

            var returnable = menuItems.Distinct().ToList();
            return returnable.OrderBy(x => x.MenuItemParentId).ToList();
        }

        /// <summary>
        /// Gets all parent menu items.
        /// </summary>
        /// <returns></returns>
        public List<MenuItem> GetAllParentMenuItems()
        {
            var dependencies = new List<MenuItem>();
            var items = GetMenuItems();
            if(items.Any(x => x.IsHeader)) dependencies.AddRange(items.Where(x => x.IsHeader));

            return dependencies;
        }

        /// <summary>
        /// Gets the unauthorized parent menu items for user.
        /// </summary>
        /// <returns>'Dummy' version of unauthorized parent menu items</returns>
        public List<MenuItem> GetAllMenuItemDependencies()
        {
            var parentalDependencies = GetAllParentMenuItems();
            var userMenuItems = GetMenuItemsForUser();
            var dependencies = new List<MenuItem>();
            foreach (var umi in userMenuItems)
            {
                GetDependencies(dependencies, umi, parentalDependencies);
            }
            return dependencies.Where(p => userMenuItems.All(p2 => p2.MenuItemId != p.MenuItemId)).ToList();
        }

        /// <summary>
        /// Generates the excel document from grid view.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <param name="workSheetName">Name of the work sheet.</param>
        /// <returns></returns>
        public ExcelPackage GenerateExcelDocument<T>(List<T> data, string workSheetName)
        {
            var excel = new ExcelPackage();
            var table = new GridView {DataSource = data};
            table.DataBind();

            var workSheet = excel.Workbook.Worksheets.Add(string.IsNullOrEmpty(workSheetName) ? Config.ExcelDefaultWorksheetName : workSheetName);

            var totalCols = table.Rows[0].Cells.Count;
            var totalRows = table.Rows.Count;
            var headerRow = table.HeaderRow;
            const int indexOfWorksheet = 1;
            const int indexOfHeader = 1;

            for (var i = 1; i <= totalCols; i++)
            {
                workSheet.Cells[1, i].Value = headerRow.Cells[i - 1].Text;
            }
            for (var j = 1; j <= totalRows; j++)
            {
                for (var i = 1; i <= totalCols; i++)
                {
                    var product = data.ElementAt(j - 1);
                    workSheet.Cells[j + 1, i].Value = product.GetType().GetProperty(headerRow.Cells[i - 1].Text).GetValue(product, null);
                }
            }

            FormatHeaderRow(excel.Workbook.Worksheets[indexOfWorksheet].Row(indexOfHeader));

            return excel;
        }

        /// <summary>
        /// Reads the excel worksheet.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <param name="worksheetIndex">Index of the worksheet.</param>
        /// <returns></returns>
        public List<long> ReadNumericExcelWorksheet(Stream stream, int worksheetIndex)
        {
            List<long> returnable = new List<long>();
            using (ExcelPackage package = new ExcelPackage(stream))
            {
                var workSheet = package.Workbook.Worksheets[worksheetIndex];
                var colCount = workSheet.Dimension == null ? new ExcelAddressBase(1,1,1,1).End.Column : workSheet.Dimension.End.Column;
                var rowCount = workSheet.Dimension == null ? new ExcelAddressBase(1,1,1,1).End.Row : workSheet.Dimension.End.Row;

                for (int row = 1; row <= rowCount; row++)
                {
                    for (int col = 1; col <= colCount; col++)
                    {
                        long result = 0;
                        if (Int64.TryParse(string.IsNullOrEmpty((Convert.ToString(workSheet.Cells[row, col].Value))) ? "" : workSheet.Cells[row, col].Value.ToString().Trim(), out result))
                        {
                            returnable.Add(result);
                        }
                    }
                }
            }

            return returnable.Distinct().ToList();
        }


        /// <summary>
        /// Reads the numeric comma separated file.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <returns></returns>
        public List<long> ReadNumericDelimitedFile(Stream stream, char seperator)
        {
            List<long> returnable = new List<long>();
            using (var reader = new StreamReader(stream))
            {
                var allFileData = reader.ReadToEnd();
                var file = allFileData.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                foreach (var line in file)
                {
                    foreach (var index in line.Split(seperator))
                    {
                        long result = 0;
                        if (Int64.TryParse(index.Trim(), out result))
                        {
                            returnable.Add(result);
                        }
                    }
                }
            }

            return returnable.Distinct().ToList();
        }

        /// <summary>
        /// Determines whether [is date weekend or holiday].
        /// </summary>
        /// <returns>
        ///   <c>true</c> if [is date weekend or holiday]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsDateWeekendOrHoliday(DateTime date)
        {
            return (date.DayOfWeek == DayOfWeek.Saturday|| date.DayOfWeek == DayOfWeek.Sunday || date.IsFederalHoliday());
        }

        /// <summary>
        /// Gets the next possible delivery date.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns>The next valid possible date</returns>
        public DateTime GetNextNonHolidayOrWeekendDate(DateTime date)
        {
            if (!IsDateWeekendOrHoliday(date)) return date;

            var returnableDate = date;

            while (IsDateWeekendOrHoliday(returnableDate))
            {
                returnableDate = returnableDate.AddDays(1);
            }

            return returnableDate;
        }

        #endregion

        #region Private Methods

        private List<MenuItem> GetChildrenMenuItems()
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable();
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.MenuChildrenProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<MenuItem>().ToList();
                }
            }

            return new List<MenuItem>();
        }

        private List<MenuItem> GetParentMenuItems()
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable();
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.MenuParentsProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<MenuItem>().ToList();
                }
            }

            return new List<MenuItem>();
        }

        private List<User> GetUsers()
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable();
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.UsersProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<User>().ToList();
                }
            }

            return new List<User>();
        }

        private List<Group> GetGroups()
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable();
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.GroupsProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<Group>().ToList();
                }
            }

            return new List<Group>();
        }

        private List<MenuItem> GetUserParentMenuItems(string user)
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable {{"@User", user}};
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.UserParentMenuItemsProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<MenuItem>().ToList();
                }
            }

            return new List<MenuItem>();
        }

        private List<MenuItem> GetParentMenuItemsForGroup(string group)
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable { { "@ADGroup", group } };
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.GroupParentMenuItemsProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<MenuItem>().ToList();
                }
            }

            return new List<MenuItem>();
        }

        private List<MenuItem> GetUserChildrenMenuItems(string user)
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable { { "@User", user } };
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.UserChildrenMenuItemsProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<MenuItem>().ToList();
                }
            }

            return new List<MenuItem>();
        }

        private List<MenuItem> GetChildrenMenuItemsForGroup(string group)
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable { { "@ADGroup", group } };
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.GroupChildrenMenuItemsProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return dt.AsEnumerable<MenuItem>().ToList();
                }
            }

            return new List<MenuItem>();
        }

        private SiteMaintenance GetIsSiteUnderMaintenance()
        {
            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable();
                DataTable dt;
                var result = du.ExecuteDataTable(out dt, Config.SiteMaintenanceProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType != DlCommon.ResultType.Success) return new SiteMaintenance();
                var returned = dt.AsEnumerable<SiteMaintenance>().ToList();
                if (returned.Count > 0) return returned.First();
            }

            return new SiteMaintenance();
        }

        private void GetDependencies(List<MenuItem> dependencies, MenuItem child, List<MenuItem> allParentalItems)
        {
            foreach (var item in allParentalItems.Where(item => child.MenuItemParentId == item.MenuItemId && dependencies.All(x => x.MenuItemId != item.MenuItemId)))
            {
                dependencies.Add(new MenuItem{MenuItemId = item.MenuItemId, MenuItemParentId = item.MenuItemParentId, Text = item.Text, Url = "#", Description = null, IsHeader = item.IsHeader });
                GetDependencies(dependencies, item, allParentalItems);
            }
        }

        private ExcelRow FormatHeaderRow(ExcelRow row)
        {
            if (row == null) { return null; }
            var backgroundColor = new ColorConverter().ConvertFromString("#EC1C24");
            var backgroundColorToUse = (Color)(backgroundColor ?? Color.Crimson);
            row.Style.Font.Size = 18;
            row.Style.Font.Bold = true;
            row.Style.Fill.PatternType = ExcelFillStyle.Solid;
            row.Style.Font.Color.SetColor(Color.WhiteSmoke);
            row.Style.Font.Name = "Corbel";
            row.Style.Fill.BackgroundColor.SetColor(backgroundColorToUse);
            row.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
            row.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            return row;
        }
        #endregion
        #endregion
    }
}