﻿using System;
using System.Collections.Generic;
using System.Linq;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;

namespace PurchReqV2.Controllers
{
    /// <summary>
    /// Controller for the SiteAdmin page.
    /// </summary>
    /// <seealso cref="PurchReqV2.Controllers.BaseController" />
    public class SiteAdminController : BaseController
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private EntitiesDataContext _context;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SiteAdminController"/> class.
        /// </summary>
        /// <param name="user">The user.</param>
        public SiteAdminController(string user)
            : base(user)
        {
            _context = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Gets the menu items.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns>List of menu items</returns>
        public List<PurchReq_MenuItem> GetMenuItems(string text = null)
        {
            var results = new List<PurchReq_MenuItem>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllMenuItemDetails()
                        .Where(
                            x =>
                                (text == null ||
                                 (x.Text.ToLower().Contains(text.ToLower()) ||
                                  text.ToLower().Contains(x.Text.ToLower()))))
                        .Select(
                            result =>
                                new PurchReq_MenuItem
                                {
                                    MenuItemID = result.MenuItemID,
                                    MenuItemParentID = result.MenuItemParentID,
                                    Text = result.Text,
                                    Url = result.Url,
                                    Description = result.Description,
                                    IsHeader = result.IsHeader,
                                    Active = result.MenuItem_Active,
                                    CreatedOn = result.MenuItem_CreatedOn,
                                    CreatedBy = result.MenuItem_CreatedBy,
                                    PurchReq_MenuItem1 = new PurchReq_MenuItem
                                    {
                                        MenuItemID = result.MenuItemParent_MenuItemID != null ? result.MenuItemParent_MenuItemID.Value : 0,
                                        MenuItemParentID = result.MenuItemParent_MenuItemParentID,
                                        Text = result.MenuItemParent_Text,
                                        Url = result.MenuItemParent_Url,
                                        Description = result.MenuItemParent_Description,
                                        IsHeader = result.MenuItemParent_IsHeader ?? false,
                                        Active = result.MenuItemParent_Active ?? false,
                                        CreatedOn = result.MenuItemParent_CreatedOn ?? DateTime.Now,
                                        CreatedBy = result.MenuItemParent_CreatedBy
                                    }
                                }));
            }

            return results;
        }

        /// <summary>
        /// Gets the Configurations.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns>List of Configuration items</returns>
        public List<PurchReq_Configuration> GetConfigurations(string text = null)
        {
            var results = new List<PurchReq_Configuration>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllConfigurations()
                        .Where(
                            x =>
                                (text == null ||
                                 (x.ConfigName.ToLower().Contains(text.ToLower()) ||
                                  text.ToLower().Contains(x.ConfigName.ToLower()))))
                        .Select(
                            result =>
                                new PurchReq_Configuration
                                {
                                    ConfigID = result.ConfigID,
                                    Process = result.Process,
                                    ConfigName = result.ConfigName,
                                    ConfigValue = result.ConfigValue,
                                    DataTypeID = result.DataTypeID,
                                    Length = result.Length,
                                    Active = result.Active,
                                    ModifiedBy = result.ModifiedBy,
                                    ModifiedOn = result.ModifiedOn,
                                    PurchReq_DataType = new PurchReq_DataType
                                    {
                                        DataTypeID = result.DataTypeID,
                                        DataType1 = result.DataType,
                                        Description = result.DataTypeDescription
                                    }
                                }));
            }

            return results;
        }

        /// <summary>
        /// Gets the c data types.
        /// </summary>
        /// <returns>List of all active C (.NET) data types</returns>
        public List<PurchReq_DataType> GetCDataTypes()
        {
            var results = new List<PurchReq_DataType>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetDataTypes()
                        .Select(
                            result =>
                                new PurchReq_DataType
                                {
                                    DataTypeID = result.DataTypeID,
                                    DataType1 = result.DataType,
                                    Description = result.Description
                                }));
            }

            return results;
        }

        /// <summary>
        /// Upserts the MenuItem.
        /// </summary>
        /// <param name="u">The u.</param>
        /// <param name="delete">The delete.</param>
        public void UpsertMenuItem(object u, bool? delete = null)
        {
            var menuItem = u as PurchReq_MenuItem;
            if (menuItem == null) return;

            if (string.IsNullOrEmpty(menuItem.Url) || menuItem.MenuItemParentID == null ||
                menuItem.MenuItemParentID <= 0)
            {
                menuItem.IsHeader = true;
            }

            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertMenuItem(menuItem.MenuItemID, menuItem.MenuItemParentID, menuItem.Text, string.IsNullOrEmpty(menuItem.Url) ? null : menuItem.Url, menuItem.Description, menuItem.IsHeader, menuItem.Active, UserName, delete);
            }
        }

        /// <summary>
        /// Upserts the site maintenance.
        /// </summary>
        /// <param name="active">if set to <c>true</c> [active].</param>
        /// <param name="estimatedEndTime">The estimated end time.</param>
        /// <param name="user">The user.</param>
        public void UpsertSiteMaintenance(bool active, DateTime estimatedEndTime, string user)
        {
            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertSiteMaintenance(active, estimatedEndTime, user);
            }
        }

        /// <summary>
        /// Upserts the configuration.
        /// </summary>
        /// <param name="u">The u.</param>
        /// <param name="delete">The delete.</param>
        public void UpsertConfiguration(object u, bool? delete = null)
        {
            var configuration = u as PurchReq_Configuration;
            if (configuration == null) return;

            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertConfiguration(configuration.ConfigID, configuration.Process, configuration.ConfigName, configuration.ConfigValue, configuration.DataTypeID, configuration.Length, configuration.Active, UserName, delete);
            }
        }

        #endregion

        #region Private Methods

        #endregion

        #endregion
    }
}