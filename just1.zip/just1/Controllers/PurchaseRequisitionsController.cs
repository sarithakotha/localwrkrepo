﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using PurchReqV2.Models.Entities;
using PurchReqV2.Utilities;

namespace PurchReqV2.Controllers
{
    /// <summary>
    /// Controller for Purchase Requisitions page.
    /// </summary>
    /// <seealso cref="PurchReqV2.Controllers.BaseController" />
    public class PurchaseRequisitionsController : BaseController
    {
        #region Variables

        #region Public Variables

        #endregion

        #region Private Variables

        private EntitiesDataContext _context;

        #endregion

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PurchaseRequisitionsController"/> class.
        /// </summary>
        /// <param name="user">The user.</param>
        public PurchaseRequisitionsController(string user)
            : base(user)
        {
            _context = new EntitiesDataContext(Config.PurchReqV2ConnectionString);
        }

        #endregion

        #region Methods

        #region Public Methods

        /// <summary>
        /// Gets the next purchase requisition sequence.
        /// </summary>
        /// <returns></returns>
        public long GetNextPurchaseRequisitionSequence()
        {
            object nextSequence = 0;

            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable();
                
                var result = du.ExecuteScalar(out nextSequence, Config.NextSequenceProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return Convert.ToInt64(nextSequence);
                }
            }

            return Convert.ToInt64(nextSequence);
        }

        /// <summary>
        /// Gets the next purchase requisition staging sequence.
        /// </summary>
        /// <param name="sessionID">The session identifier.</param>
        /// <returns>Next staging sequence</returns>
        public long GetNextPurchaseRequisitionStagingSequence(string sessionID)
        {
            object nextSequence = 0;

            using (var du = new DataUtility(Config.PurchReqV2ConnectionString))
            {
                var ht = new Hashtable
                {
                    { "@SessionID", sessionID }
                };

                var result = du.ExecuteScalar(out nextSequence, Config.NextStagingSequenceProc, ht);

                if (result.Exception != null) { throw result.Exception; }

                if (result.ResultType == DlCommon.ResultType.Success)
                {
                    return Convert.ToInt64(nextSequence);
                }
            }

            return Convert.ToInt64(nextSequence);
        }

        /// <summary>
        /// Gets the staged purchase requisitions.
        /// </summary>
        /// <returns></returns>
        public List<PurchReq_PurchaseRequisitionStaging> GetStagedPurchaseRequisitions(string sessionId = null)
        {
            var results = new List<PurchReq_PurchaseRequisitionStaging>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllStagedPurchaseRequisitions(sessionId)
                        .Select(
                            result =>
                                new PurchReq_PurchaseRequisitionStaging
                                {
                                    SESSIONID = result.SESSIONID,
                                    SEQLINE = result.SEQLINE,
                                    STATUS = GetReadableStatus(result.STATUS),
                                    POREQ = result.POREQ,
                                    POREQDT = result.POREQDT,
                                    SAPPO = result.SAPPO,
                                    SAPPODT = result.SAPPODT,
                                    PURGROUP = result.PURGROUP,
                                    ACCTCAT = result.ACCTCAT,
                                    VENDOR = result.VENDOR,
                                    CCenter = result.CCenter,
                                    CPFR = result.CPFR,
                                    HDRTEXT = result.HDRTEXT.Trim(),
                                    LINESEQ = result.LINESEQ,
                                    LINESTS = result.LINESTS,
                                    SHORTTEXT = result.SHORTTEXT.Trim(),
                                    LONGTEXT = result.LONGTEXT.Trim(),
                                    VENITEM = result.VENITEM,
                                    REFPART = result.REFPART,
                                    UNITQTY = result.UNITQTY,
                                    UNITPRC = result.UNITPRC,
                                    TOTAL = result.TOTAL,
                                    UOM = result.UOM,
                                    GLACCT = result.GLACCT,
                                    TAXFLAG = result.TAXFLAG,
                                    DLVDATE = DateTime.ParseExact(result.DLVDATE, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"),
                                    REQUSER = result.REQUSER,
                                    REQEMAIL = result.REQEMAIL,
                                    CRTDT = DateTime.ParseExact(result.CRTDT, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"),
                                    ERRORDT = result.ERRORDT,
                                    ERRORDESC = result.ERRORDESC
                                })); 
            }

            return results;
        }

        /// <summary>
        /// Gets the purchase requisitions.
        /// </summary>
        /// <param name="requisitionUser">The requisition user.</param>
        /// <param name="vendor">The vendor.</param>
        /// <returns>List of historical purchase requisitions</returns>
        public List<PurchReq_PurchaseRequisition> GetPurchaseRequisitions(string requisitionUser = null, string vendor = null, string startDate = null, string sequence = null,
            string purchaseRequisition = null, string requisitioner = null, string costCenter = null, string cpfr = null, string trackingNumber = null, string status = null)
        {
            var results = new List<PurchReq_PurchaseRequisition>();
            string user = String.IsNullOrEmpty(requisitioner) ? requisitionUser : requisitioner;
            DateTime createDate;
            var date = DateTime.TryParse(startDate, out createDate) ? createDate : DateTime.Now;

            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                
                results.AddRange(
                    entities.spPurchReq_GetAllPurchaseRequisitions(GetUserNameWithoutDomain(user), vendor)
                .Where(x => (((sequence == null ||
                                 (x.SEQKEY.ToString(CultureInfo.InvariantCulture).Contains(sequence.ToString(CultureInfo.InvariantCulture)))))
                                 &&
                                 (startDate == null || (DateTime.ParseExact(x.CRTDT, "yyyyMMdd", CultureInfo.InvariantCulture) >= date))
                                 &&
                                 (vendor == null ||
                                 (x.VENDOR.ToString(CultureInfo.InvariantCulture).ToLower().Contains(vendor.ToString(CultureInfo.InvariantCulture).ToLower())))
                                 &&
                                 (purchaseRequisition == null ||
                                 (x.POREQ.ToString(CultureInfo.InvariantCulture).Contains(purchaseRequisition.ToString(CultureInfo.InvariantCulture))))
                                 &&
                                 (requisitioner == null ||
                                 (x.REQUSER.ToString(CultureInfo.InvariantCulture).ToLower().Contains(requisitioner.ToString(CultureInfo.InvariantCulture).ToLower())))
                                 &&
                                 (costCenter == null ||
                                 (x.CCenter.ToString(CultureInfo.InvariantCulture).Contains(costCenter.ToString(CultureInfo.InvariantCulture))))
                                 &&
                                 (cpfr == null ||
                                 (x.CPFR.ToString(CultureInfo.InvariantCulture).Contains(cpfr.ToString(CultureInfo.InvariantCulture))))
                                 &&
                                 (trackingNumber == null ||
                                 (x.REFPART.ToString(CultureInfo.InvariantCulture).ToLower().Contains(trackingNumber.ToString().ToLower())))
                                 &&
                                 (status == null ||
                                 (GetReadableStatus(x.STATUS).ToString(CultureInfo.InvariantCulture).ToLower().Contains(status.ToString(CultureInfo.InvariantCulture).ToLower()))))).Select(
                        result =>
                                new PurchReq_PurchaseRequisition
                                {
                                    SEQKEY = result.SEQKEY,
                                    SEQLINE = Convert.ToInt32(result.SEQLINE),
                                    STATUS = GetReadableStatus(result.STATUS),
                                    POREQ = result.POREQ,
                                    POREQDT = result.POREQDT,
                                    SAPPO = result.SAPPO,
                                    SAPPODT = result.SAPPODT,
                                    PURGROUP = result.PURGROUP,
                                    ACCTCAT = result.ACCTCAT,
                                    VENDOR = result.VENDOR,
                                    CCenter = result.CCenter,
                                    CPFR = result.CPFR,
                                    HDRTEXT = result.HDRTEXT,
                                    LINESEQ = result.LINESEQ,
                                    LINESTS = result.LINESTS,
                                    SHORTTEXT = result.SHORTTEXT,
                                    LONGTEXT = result.LONGTEXT,
                                    VENITEM = result.VENITEM,
                                    REFPART = result.REFPART,
                                    UNITQTY = result.UNITQTY,
                                    UNITPRC = result.UNITPRC,
                                    UOM = result.UOM,
                                    GLACCT = result.GLACCT,
                                    TAXFLAG = result.TAXFLAG,
                                    DLVDATE = DateTime.ParseExact(result.DLVDATE, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"),
                                    REQUSER = result.REQUSER,
                                    REQEMAIL = result.REQEMAIL,
                                    CRTDT = DateTime.ParseExact(result.CRTDT, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"),
                                    ERRORDT = result.ERRORDT,
                                    ERRORDESC = result.ERRORDESC
                                }));;
            }

            return results;
        }

        /// <summary>
        /// Gets the historical purchase requisitions.
        /// </summary>
        /// <param name="requisitionUser">The requisition user.</param>
        /// <param name="vendor">The vendor.</param>
        /// <returns>List of historical purchase requisitions</returns>
        public List<PurchReq_HistoricalPurchaseRequisition> GetHistoricalPurchaseRequisitions(string requisitionUser = null, string vendor = null, string startDate = null, string sequence = null,
            string purchaseRequisition = null, string requisitioner = null, string costCenter = null, string cpfr = null, string trackingNumber = null, string status = null)
        {
            var results = new List<PurchReq_HistoricalPurchaseRequisition>();
            string user = String.IsNullOrEmpty(requisitioner) ? requisitionUser : requisitioner;
            DateTime createDate;
            var date = DateTime.TryParse(startDate, out createDate) ? createDate : DateTime.Now;

            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {

                results.AddRange(
                    entities.spPurchReq_GetAllHistoricalPurchaseRequisitions(GetUserNameWithoutDomain(user), vendor)
                .Where(x => (((sequence == null ||
                                 (x.SEQKEY.ToString(CultureInfo.InvariantCulture).Contains(sequence.ToString(CultureInfo.InvariantCulture)))))
                                 &&
                                 (startDate == null || (DateTime.ParseExact(x.CRTDT, "yyyyMMdd", CultureInfo.InvariantCulture) >= date))
                                 &&
                                 (vendor == null ||
                                 (x.VENDOR.ToString(CultureInfo.InvariantCulture).ToLower().Contains(vendor.ToString(CultureInfo.InvariantCulture).ToLower())))
                                 &&
                                 (purchaseRequisition == null ||
                                 (x.POREQ.ToString(CultureInfo.InvariantCulture).Contains(purchaseRequisition.ToString(CultureInfo.InvariantCulture))))
                                 &&
                                 (requisitioner == null ||
                                 (x.REQUSER.ToString(CultureInfo.InvariantCulture).ToLower().Contains(requisitioner.ToString(CultureInfo.InvariantCulture).ToLower())))
                                 &&
                                 (costCenter == null ||
                                 (x.CCenter.ToString(CultureInfo.InvariantCulture).Contains(costCenter.ToString(CultureInfo.InvariantCulture))))
                                 &&
                                 (cpfr == null ||
                                 (x.CPFR.ToString(CultureInfo.InvariantCulture).Contains(cpfr.ToString(CultureInfo.InvariantCulture))))
                                 &&
                                 (trackingNumber == null ||
                                 (x.REFPART.ToLower().ToString(CultureInfo.InvariantCulture).Contains(trackingNumber.ToLower().ToString())))
                                 &&
                                 (status == null ||
                                 (GetReadableStatus(x.STATUS.ToString(CultureInfo.InvariantCulture)).ToLower().Contains(status.ToString(CultureInfo.InvariantCulture).ToLower())))
                                 )).Select(
                            result =>
                                new PurchReq_HistoricalPurchaseRequisition
                                {
                                    SEQKEY = result.SEQKEY,
                                    SEQLINE = result.SEQLINE,
                                    STATUS = GetReadableStatus(result.STATUS),
                                    POREQ = result.POREQ,
                                    POREQDT = result.POREQDT,
                                    SAPPO = result.SAPPO,
                                    SAPPODT = result.SAPPODT,
                                    PURGROUP = result.PURGROUP,
                                    ACCTCAT = result.ACCTCAT,
                                    VENDOR = result.VENDOR,
                                    CCenter = result.CCenter,
                                    CPFR = result.CPFR,
                                    HDRTEXT = result.HDRTEXT,
                                    LINESEQ = result.LINESEQ,
                                    LINESTS = result.LINESTS,
                                    SHORTTEXT = result.SHORTTEXT,
                                    LONGTEXT = result.LONGTEXT,
                                    VENITEM = result.VENITEM,
                                    REFPART = result.REFPART,
                                    UNITQTY = result.UNITQTY,
                                    UNITPRC = result.UNITPRC,
                                    UOM = result.UOM,
                                    GLACCT = result.GLACCT,
                                    TAXFLAG = result.TAXFLAG,
                                    DLVDATE = DateTime.ParseExact(result.DLVDATE, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"),
                                    REQUSER = result.REQUSER,
                                    REQEMAIL = result.REQEMAIL,
                                    CRTDT = DateTime.ParseExact(result.CRTDT, "yyyyMMdd", CultureInfo.InvariantCulture).ToString("MM/dd/yyyy"),
                                    ERRORDT = result.ERRORDT,
                                    ERRORDESC = result.ERRORDESC
                                }));
            }

            return results;
        }

        /// <summary>
        /// Gets all CPFRS.
        /// </summary>
        /// <param name="purGroup">The pur group.</param>
        /// <returns></returns>
        public List<PurchReq_Cpfr> GetAllCpfrs(string purGroup = null)
        {
            var results = new List<PurchReq_Cpfr>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllCpfrs()
                    .Where(x => x.PURGROUP == purGroup || string.IsNullOrEmpty(purGroup))
                    .Select(
                            result =>
                                new PurchReq_Cpfr
                                {
                                    ACCTCAT = result.ACCTCAT,
                                    PURGROUP = result.PURGROUP,
                                    CPFRNO = result.CPFRNO,
                                    CPFRDESC = result.CPFRDESC,
                                    CPFRSTS = result.CPFRSTS,
                                    LONGDESC = String.Format("{0} - {1} - {2} - {3}", result.CPFRNO, result.CPFRDESC, result.PURGROUP, result.ACCTCAT)
                                }));
            }

            return results;
        }

        /// <summary>
        /// Deletes the staged purchase requisitions by session identifier.
        /// </summary>
        /// <param name="sessionID">The session identifier.</param>
        /// <returns></returns>
        public bool DeleteStagedPurchaseRequisitionsBySessionID(string sessionID)
        {
            var result = 0;
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                result = entities.spPurchReq_DeleteStagedPurchaseRequisitions(sessionID);
            }

            return result == 1;
        }

        /// <summary>
        /// Gets all vendors.
        /// </summary>
        /// <returns>List of Vendors</returns>
        public List<PurchReq_Vendor> GetAllVendors()
        {
            var results = new List<PurchReq_Vendor>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllVendors()
                        .Select(
                            result =>
                                new PurchReq_Vendor
                                {
                                    SUPPCD = result.SUPPCD,
                                    SUPPNAME = result.SUPPNAME,
                                    SUPPSTS = result.SUPPSTS,
                                    LONGDESC = String.Format("{0} - {1}", result.SUPPNAME, result.SUPPCD)
                                }));
            }

            return results;
        }

        /// <summary>
        /// Gets all cost centers.
        /// </summary>
        /// <param name="purGroup">The pur group.</param>
        /// <returns>List of cost centers.</returns>
        public List<PurchReq_CostCenter> GetAllCostCenters(string purGroup = null)
        {
            var results = new List<PurchReq_CostCenter>();
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllCostCenters()
                    .Where(x => x.PURGROUP == purGroup || String.IsNullOrEmpty(purGroup))
                        .Select(
                            result =>
                                new PurchReq_CostCenter
                                {   
                                    ACCTCAT = result.ACCTCAT,
                                    PURGROUP = result.PURGROUP,
                                    CCNUMBER = result.CCNUMBER,
                                    CCNAME = result.CCNAME,
                                    CCVALFRDT = result.CCVALFRDT,
                                    CCVALTODT = result.CCVALTODT,
                                    LONGDESC = String.Format("{0} - {1} - {2} - {3}", result.CCNUMBER, result.CCNAME, result.PURGROUP, result.ACCTCAT)
                                }));
            }

            return results;
        }

        /// <summary>
        /// Gets all gl accounts.
        /// </summary>
        /// <returns></returns>
        public List<PurchReq_GLAccount> GetAllGlAccounts(string glAcctCat = null)
        {
            var results = new List<PurchReq_GLAccount>();
            var gl = new PurchReq_GLAccount();
            gl.SELECTOR = "Select a GL Account";
            results.Add(gl);
            using (var entities = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                results.AddRange(
                    entities.spPurchReq_GetAllGlAccounts()
                        .Where(x => x.GLACCTCAT == glAcctCat || String.IsNullOrEmpty(glAcctCat))
                        .Select(
                            result =>
                                new PurchReq_GLAccount
                                {
                                    GLACCTCAT = result.GLACCTCAT,
                                    GLACCT = result.GLACCT,
                                    GLDESC = result.GLDESC,
                                    GLVALFRDT = result.GLVALFRDT,
                                    GLVALTODT = result.GLVALTODT,
                                    LONGDESC = String.Format("{0} - {1} - {2}", result.GLACCT, result.GLDESC, result.GLACCTCAT)
                                }));
            }

            return results;
        }

        /// <summary>
        /// Upserts the purchase requisition staging.
        /// </summary>
        /// <param name="u">The u.</param>
        /// <param name="delete">The delete.</param>
        public void UpsertPurchaseRequisitionStaging(object u, bool? delete = null)
        {
            var purchaseRequisitionStaging = u as PurchReq_PurchaseRequisitionStaging;
            if (purchaseRequisitionStaging == null) return;

            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_UpsertStagedPurchaseRequisition
                    (purchaseRequisitionStaging.SESSIONID,
                    purchaseRequisitionStaging.SEQLINE,
                    purchaseRequisitionStaging.STATUS, 
                    purchaseRequisitionStaging.POREQ, 
                    purchaseRequisitionStaging.POREQDT, 
                    purchaseRequisitionStaging.SAPPO, 
                    purchaseRequisitionStaging.SAPPODT, 
                    purchaseRequisitionStaging.PURGROUP, 
                    purchaseRequisitionStaging.ACCTCAT, 
                    purchaseRequisitionStaging.VENDOR, 
                    purchaseRequisitionStaging.CCenter, 
                    purchaseRequisitionStaging.CPFR, 
                    purchaseRequisitionStaging.HDRTEXT, 
                    purchaseRequisitionStaging.LINESEQ, 
                    purchaseRequisitionStaging.LINESTS, 
                    purchaseRequisitionStaging.SHORTTEXT, 
                    purchaseRequisitionStaging.LONGTEXT, 
                    purchaseRequisitionStaging.VENITEM, 
                    purchaseRequisitionStaging.REFPART, 
                    purchaseRequisitionStaging.UNITQTY, 
                    purchaseRequisitionStaging.UNITPRC, 
                    purchaseRequisitionStaging.TOTAL, 
                    purchaseRequisitionStaging.UOM, 
                    purchaseRequisitionStaging.GLACCT, 
                    purchaseRequisitionStaging.TAXFLAG, 
                    DateTime.ParseExact(purchaseRequisitionStaging.DLVDATE, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd"), 
                    purchaseRequisitionStaging.REQUSER, 
                    purchaseRequisitionStaging.REQEMAIL,
                    DateTime.ParseExact(purchaseRequisitionStaging.CRTDT, "MM/dd/yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd"), 
                    purchaseRequisitionStaging.ERRORDT, 
                    purchaseRequisitionStaging.ERRORDESC, 
                    delete);
            }
        }

        /// <summary>
        /// Migrates the staging purchase requisition to production.
        /// </summary>
        /// <param name="sessionId">The session identifier.</param>
        public void MigrateStagingPurchaseRequisitionToProduction(string sessionId)
        {
            using (_context = new EntitiesDataContext(Config.PurchReqV2ConnectionString))
            {
                _context.spPurchReq_MigrateStagingPurchaseRequisitionToProduction(sessionId);
            }
        }

        /// <summary>
        /// Gets the user name without domain.
        /// </summary>
        /// <param name="connectedUser">The connected user.</param>
        /// <returns>User name</returns>
        public string GetUserNameWithoutDomain(string connectedUser)
        {
            if (string.IsNullOrEmpty(connectedUser)) return null;
            var userName = connectedUser;
            int pos = userName.IndexOf('\\');
            return pos != -1 ? userName.Substring(pos + 1) : userName;
        }

        /// <summary>
        /// Gets the gl type from pur group.
        /// </summary>
        /// <param name="purGroup">The pur group.</param>
        /// <returns>Gl Type</returns>
        public string GetGlTypeFromPurGroup(string purGroup)
        {
            var glType = "";

            switch (purGroup)
            {
                case "MRO":
                    glType = "K";
                    break;
                case "REW":
                    glType = "R";
                    break;
                case "IO4":
                    glType = "H";
                    break;
                case "IO5":
                    glType = "I";
                    break;
                case "IO6":
                    glType = "J";
                    break;
                default:
                    glType = "F";
                    break;
            }

            return glType;
        }

        /// <summary>
        /// Gets the readable status.
        /// </summary>
        /// <param name="statusCode">The status code.</param>
        /// <returns>Human-readable status</returns>
        public string GetReadableStatus(string statusCode)
        {
            switch (statusCode)
            {
                case "1":
                    return "Pending";
                case "X":
                    return "Transferred To SAP";
                case "2":
                    return "SAP Requisition Created";
                case "3":
                    return "PO Created In SAP";
                case "4":
                    return "Rejected By SAP";
                case "6":
                    return "An error occured during processing, see error message.";
                default:
                    return "An unknown status has been used on this record.  Investigate in SAP.";
            }
        }
            #endregion

            #region Private Methods

            #endregion

            #endregion
        }
}