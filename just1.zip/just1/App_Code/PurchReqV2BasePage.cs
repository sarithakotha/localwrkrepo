﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using PurchReqV2.Controllers;
using PurchReqV2.Models;
using PurchReqV2.Utilities;
using OfficeOpenXml;

namespace PurchReqV2
{
    /// <summary>
    /// Base page for the PurchReqV2 website.
    /// </summary>
    /// <seealso cref="System.Web.UI.Page" />
    public class PurchReqV2BasePage : System.Web.UI.Page
    {
        #region Variables

        #region Public Variables

        protected enum MessageType
        {
            Information = 0,
            Success = 1,
            Warning = 2,
            Error = 3
        }

        #endregion

        #region Private Variables

        private readonly BaseController _controller;

        #endregion

        #endregion

        #region Constructers

        /// <summary>
        /// Initializes a new instance of the <see cref="PurchReqV2BasePage"/> class.
        /// </summary>
        public PurchReqV2BasePage()
        {
            try
            {
                _controller = new BaseController(HttpContext.Current.User.Identity.Name);
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        #endregion

        #region Methods

        #region Public & Protected Methods

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Init" /> event to initialize the page.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs" /> that contains the event data.</param>
        protected override void OnInit(EventArgs e)
        {
            try
            {
                base.OnInit(e);
                var urls = _controller.GetMenuItems();
                StoreAllPages(urls);
                if (Config.UtilizePageLevelAccessRulesByAdUserOrGroup)
                {
                    Authenticate(GetCurrentPageId());
                    BuildMenuForAuthorizedUsers();
                    return;
                }

                BuildMenuForAllUsers();
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Determines whether [is site under maintenance].
        /// </summary>
        /// <returns>Bool status of site maintenance</returns>
        protected bool IsSiteUnderMaintenance()
        {
            return _controller.IsSiteUnderMaintenance();
        }

        /// <summary>
        /// Gets the site maintenance information.
        /// </summary>
        /// <returns>Site Maintenance object</returns>
        protected SiteMaintenance GetSiteMaintenanceInformation()
        {
            return _controller.GetSiteMaintenanceInfo();
        }

        /// <summary>
        /// Authenticates the user for site access.
        /// </summary>
        protected void Authenticate(long pageId)
        {
            try
            {
                if (_controller.IsUserAdmin())
                {
                    return;
                }
                if (IsSiteUnderMaintenance())
                {
                    Session[Config.SessionSiteMaintenance] = _controller.GetSiteMaintenanceInfo();
                    Response.Redirect(Config.SiteMaintenancePage);
                }
                if (!_controller.IsUserAuthorizedToViewSite())
                {
                    Response.Redirect(Config.FourZeroOnePage);
                }
                if (!_controller.IsUserAuthorizedForPage(pageId))
                {
                    Response.Redirect(Config.FourZeroOnePage);
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        /// <summary>
        /// Writes a notification to the screen.
        /// </summary>
        /// <param name="notification">Message for user</param>
        /// <param name="messageType">Type of message being displayed</param>
        protected void DisplayMessage(String notification, MessageType messageType)
        {
            try
            {
                if (Master == null)
                {
                    return;
                }

                var lblValidation = Master.FindControl("lblValidation") as Label;
                if (lblValidation == null)
                {
                    return;
                }

                lblValidation.Text = notification;
                lblValidation.Visible = true;

                switch (messageType)
                {
                    case MessageType.Information:
                        lblValidation.CssClass = "isa_info";
                        break;
                    case MessageType.Success:
                        lblValidation.CssClass = "isa_success";
                        break;
                    case MessageType.Warning:
                        lblValidation.CssClass = "isa_warning";
                        break;
                    case MessageType.Error:
                        lblValidation.CssClass = "isa_error";
                        break;
                }
            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }
        /*
                /// <summary>
                /// Logs the message.
                /// </summary>
                /// <param name="message">The message.</param>
                protected void LogMessage(string message)
                {
                    try
                    {
                        Logger.Log(message);
                    }
                    catch (Exception e)
                    {
                        HandleException(e);
                    }
                }
        ---skotha----*/
        /// <summary>
        /// Handles the exception.
        /// </summary>
        /// <param name="e">The e.</param>
        /// <param name="message">The message.</param>
        protected void HandleException(Exception e, string message = null)
        {
            if (e == null) { return; }
            if (e is ThreadAbortException) return;
            Application[Config.SessionException] = e;
            Application[Config.SessionStackTrace] = e.StackTrace;
            Application[Config.SessionErrorMessage] = message;
            Response.Redirect(Config.ErrorPage);
        }

        /// <summary>
        /// Downloads the excel workbook.
        /// </summary>
        /// <param name="excel">The excel.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <returns></returns>
        protected bool DownloadExcelWorkbook(ExcelPackage excel, string fileName)
        {
            try
            {
                using (var memoryStream = new MemoryStream())
                {
                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    Response.AddHeader("content-disposition",
                        "attachment;  filename=" +
                        (string.IsNullOrEmpty(fileName)
                            ? Config.ExcelDefaultFileName + Config.ExcelFileExtension
                            : fileName + Config.ExcelFileExtension));
                    excel.SaveAs(memoryStream);
                    memoryStream.WriteTo(Response.OutputStream);
                    Response.Flush();
                    Response.End();
                }

                return true;
            }
            catch (Exception ex)
            {
                HandleException(ex);
            }

            return false;
        }

        #endregion

        #region Private Methods

        private void StoreAllPages(List<Models.MenuItem> items)
        {
            foreach (var item in items)
            {
                if (string.IsNullOrEmpty(item.Url)) { continue; }
                var fullPath = new FileInfo(Server.MapPath(item.Url.Trim('/').ToLower()));
                if (string.IsNullOrEmpty(fullPath.FullName)) { continue; }

                Session[Path.GetFileNameWithoutExtension(fullPath.FullName)] = item.MenuItemId;
            }
        }

        private long GetCurrentPageId()
        {
            if (Master == null)
            {
                return -1;
            }

            var fileInfo = new FileInfo(Server.MapPath(Request.Path.Trim('/').ToLower()));
            var path = Session[Path.GetFileNameWithoutExtension(fileInfo.FullName)];
            if (path == null) return -1;

            try
            {
                return long.Parse(path.ToString());
            }
            catch (Exception)
            {
                return -1;
            }
        }

        private void BuildMenuForAllUsers()
        {
            try
            {
                if (Master == null)
                {
                    return;
                }

                var parents = _controller.GetAllParentMenuItems();
                var children = _controller.GetMenuItems();
                var dependencies = _controller.GetAllMenuItemDependencies();
                if (dependencies.Any(x => x.IsHeader && x.MenuItemParentId == null)) { parents.AddRange(dependencies.Where(x => x.IsHeader && x.MenuItemParentId == null)); }
                if (dependencies.Any(x => x.MenuItemParentId != null)) { children.AddRange(dependencies.Where(x => x.MenuItemParentId != null)); }
                var menuDiv = Extensions.FindControlRecursive(Master.Page, Config.MenuCss) as HtmlGenericControl;
                if (menuDiv == null)
                {
                    return;
                }

                menuDiv.Controls.Clear();

                var ul = new HtmlGenericControl("ul");
                foreach (var parent in parents.Where(x => x.IsHeader && x.MenuItemParentId == null))
                {
                    var li = new HtmlGenericControl("li");
                    var span = new HtmlGenericControl("span") { InnerText = parent.Text };
                    if (!string.IsNullOrEmpty(parent.Url))
                    {
                        var a = new HtmlAnchor { HRef = parent.Url };
                        a.Controls.Add(span);
                        li.Controls.Add(a);
                    }
                    else
                    {
                        var a = new HtmlAnchor { HRef = "#" };
                        a.Controls.Add(span);
                        li.Controls.Add(a);
                    }

                    var hasSubMenu = BuildSubMenus(li, parent, children);
                    if (hasSubMenu)
                    {
                        li.Attributes.Add("class", Config.SubMenuCss);
                    }
                    ul.Controls.Add(li);
                }

                menuDiv.Controls.Add(ul);

                if (ul.Controls.Count <= 0)
                {
                    DisplayMessage(
                        @"Hi there, " + _controller.UserInfo.Name +
                        "!  It appears you have been granted access to the website, but no access to any functions.  Please contact your supervisor.",
                        MessageType.Information);
                }

            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        private void BuildMenuForAuthorizedUsers()
        {
            try
            {
                if (Master == null)
                {
                    return;
                }

                var parents = _controller.GetParentMenuItemsForUser();
                var children = _controller.GetChildrenMenuItemsForUser();
                var dependencies =_controller.GetAllMenuItemDependencies();
                if (dependencies.Any(x => x.IsHeader && x.MenuItemParentId == null)) { parents.AddRange(dependencies.Where(x => x.IsHeader && x.MenuItemParentId == null));}
                if (dependencies.Any(x => x.MenuItemParentId != null)) { children.AddRange(dependencies.Where(x => x.MenuItemParentId != null));}
                var menuDiv = Extensions.FindControlRecursive(Master.Page, Config.MenuCss) as HtmlGenericControl;
                if (menuDiv == null)
                {
                    return;
                }

                menuDiv.Controls.Clear();

                var ul = new HtmlGenericControl("ul");
                foreach (var parent in parents.Where(x => x.IsHeader && x.MenuItemParentId == null))
                {
                    var li = new HtmlGenericControl("li");
                    var span = new HtmlGenericControl("span") { InnerText = parent.Text };
                    if (!string.IsNullOrEmpty(parent.Url))
                    {
                        var a = new HtmlAnchor { HRef = parent.Url };
                        a.Controls.Add(span);
                        li.Controls.Add(a);
                    }
                    else
                    {
                        var a = new HtmlAnchor { HRef = "#" };
                        a.Controls.Add(span);
                        li.Controls.Add(a);
                    }

                    var hasSubMenu = BuildSubMenus(li, parent, children);
                    if (hasSubMenu)
                    {
                        li.Attributes.Add("class", Config.SubMenuCss);
                    }
                    ul.Controls.Add(li);
                }

                menuDiv.Controls.Add(ul);

                if (ul.Controls.Count <= 0)
                {
                    DisplayMessage(
                        @"Hi there, " + _controller.UserInfo.Name +
                        "!  It appears you have been granted access to the website, but no access to any functions.  Please contact your supervisor.",
                        MessageType.Information);
                }

            }
            catch (Exception ee)
            {
                HandleException(ee);
            }
        }

        private bool BuildSubMenus(HtmlGenericControl head, Models.MenuItem parent, List<Models.MenuItem> items)
        {
            var count = 0;
            var ul = new HtmlGenericControl("ul");

            foreach (var item in items.OrderBy(x => x.MenuItemId))
            {
                if (item.MenuItemParentId == parent.MenuItemId)
                {
                    count++;
                    var li = new HtmlGenericControl("li");
                    var span = new HtmlGenericControl("span") { InnerText = item.Text };
                    if (!string.IsNullOrEmpty(item.Url))
                    {
                        var a = new HtmlAnchor { HRef = item.Url };
                        a.Controls.Add(span);
                        li.Controls.Add(a);
                    }
                    else
                    {
                        var a = new HtmlAnchor { HRef = "#" };
                        a.Controls.Add(span);
                        li.Controls.Add(a);
                    }

                    ul.Controls.Add(li);

                    var hasSubMenu = BuildSubMenus(li, item, items);
                    if (hasSubMenu) { li.Attributes.Add("class", Config.SubMenuCss); }
                }
            }

            if (ul.Controls.Count != 0)
            {
                var li = ul.Controls[ul.Controls.Count - 1] as HtmlGenericControl;
                head.Controls.Add(ul);
            }

            return count > 0;
        }

        #endregion

        #endregion
    }
}