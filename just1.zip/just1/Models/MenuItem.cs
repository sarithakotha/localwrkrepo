﻿namespace PurchReqV2.Models
{
    /// <summary>
    /// Represents a menu item
    /// </summary>
    public class MenuItem
    {
        #region Variables
        #region Public Variables

        public long MenuItemId { get; set; }
        public string Url { get; set; }
        public string Text { get; set; }
        public string Description { get; set; }
        public bool IsHeader { get; set; }
        public long? MenuItemParentId { get; set; }

        #endregion
        #region Private Variables

        #endregion
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuItem"/> class.
        /// </summary>
        public MenuItem()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MenuItem"/> class.
        /// </summary>
        /// <param name="menuItemId">The menu children identifier.</param>
        /// <param name="menuItemParentId">The parent menu identifier.</param>
        /// <param name="url">The URL.</param>
        /// <param name="text">The text.</param>
        public MenuItem(int menuItemId, int menuItemParentId, string url, string text)
        {
            MenuItemId = menuItemId;
            MenuItemParentId = menuItemParentId;
            Url = url;
            Text = text;
        }

        #endregion
    }
}