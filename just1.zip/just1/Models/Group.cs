﻿namespace PurchReqV2.Models
{
    public class Group
    {
        #region Variables
        #region Public Variables

        public long GroupId { get; set; }
        public string AdGroup { get; set; }
        public string Text { get; set; }
        public bool IsAdmin { get; set; }

        #endregion
        #region Private Variables


        #endregion
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="Group"/> class.
        /// </summary>
        public Group()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Group"/> class.
        /// </summary>
        /// <param name="groupId">The group access identifier.</param>
        /// <param name="adGroup">The ad group.</param>
        /// <param name="text">The text.</param>
        /// <param name="isAdmin">if set to <c>true</c> [is admin].</param>
        public Group(int groupId, string adGroup, string text, bool isAdmin) : this()
        {
            GroupId = groupId;
            AdGroup = adGroup;
            Text = text;
            IsAdmin = isAdmin;
        }

        #endregion
    }
}