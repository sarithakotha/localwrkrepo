﻿namespace PurchReqV2.Models
{
    /// <summary>
    /// Represents valid authorized users
    /// </summary>
    public class User
    {
        #region Variables
        #region Public Variables

        public long UserId { get; set; }
        public string UserName { get; set; }
        public bool IsAdmin { get; set; }

        #endregion
        #region Private Variables

        #endregion
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="User"/> class.
        /// </summary>
        public User()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="User"/> class.
        /// </summary>
        /// <param name="userId">The site access identifier.</param>
        /// <param name="user">The user.</param>
        /// <param name="admin">if set to <c>true</c> [admin].</param>
        public User(int userId, string user, bool admin) : this()
        {
            UserId = userId;
            UserName = user;
            IsAdmin = admin;
        }

        #endregion
    }
}