﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PurchReqV2.Models
{
    /// <summary>
    /// Represents a CPFR number from SAP.
    /// </summary>
    public class Cpfr
    {
        public string ACCTCAT { get; set; }
        public string PURGROUP { get; set; }
        public string CPFRNO { get; set; }
        public string CPFRDESC { get; set; }
        public string CPFRSTS { get; set; }
    }
}