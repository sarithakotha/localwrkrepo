namespace PurchReqV2.Models.Entities
{
    partial class EntitiesDataContext
    {
    }
}
