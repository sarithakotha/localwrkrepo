﻿using System;

namespace PurchReqV2.Models
{
    public class SiteMaintenance
    {
        #region Variables
        #region Public Variables

        public long SiteMaintenanceId { get; set; }
        public bool Active { get; set; }
        public DateTime EstimatedEndTime { get; set; }
        public string InitiatedBy { get; set; }
        public DateTime InitiatedOn { get; set; }
        public string FinishedBy { get; set; }
        public DateTime? FinishedOn { get; set; }

        #endregion
        #region Private Variables


        #endregion
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="SiteMaintenance"/> class.
        /// </summary>
        public SiteMaintenance()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SiteMaintenance"/> class.
        /// </summary>
        /// <param name="siteMaintenanceId">The site maintenance identifier.</param>
        /// <param name="active">if set to <c>true</c> [active].</param>
        /// <param name="estimatedEndDate">The estimated end date.</param>
        /// <param name="initiatedBy">The initiated by.</param>
        /// <param name="initiatedOn">The initiated on.</param>
        /// <param name="finishedBy">The finished by.</param>
        /// <param name="finishedOn">The finished on.</param>
        public SiteMaintenance(int siteMaintenanceId, bool active, DateTime estimatedEndDate, string initiatedBy, DateTime initiatedOn, string finishedBy = null, DateTime? finishedOn = null) : this()
        {
            SiteMaintenanceId = siteMaintenanceId;
            Active = active;
            EstimatedEndTime = estimatedEndDate;
            InitiatedBy = initiatedBy;
            InitiatedOn = initiatedOn;
            FinishedBy = finishedBy;
            FinishedOn = finishedOn;
        }

        #endregion
    }
}